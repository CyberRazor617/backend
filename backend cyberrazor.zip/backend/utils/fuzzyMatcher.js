/**
 * Fuzzy Q&A Matcher Utility
 * Provides intelligent question-answer matching using token overlap and Levenshtein distance
 */

const fs = require('fs');
const path = require('path');

class FuzzyMatcher {
  constructor() {
    this.qaMap = new Map();
    this.qaArray = [];
    this.loaded = false;
  }

  /**
   * Load Q&A data from train.json
   */
  async loadTrainingData(filePath = null) {
    try {
      const trainPath = filePath || path.join(__dirname, '../../mobile/train.json');
      
      if (!fs.existsSync(trainPath)) {
        console.warn(`[FuzzyMatcher] train.json not found at ${trainPath}`);
        return false;
      }

      const data = JSON.parse(fs.readFileSync(trainPath, 'utf8'));
      
      if (!data.faqs || !Array.isArray(data.faqs)) {
        console.warn('[FuzzyMatcher] Invalid train.json format');
        return false;
      }

      // Build normalized Q->A map and array
      this.qaMap.clear();
      this.qaArray = [];

      data.faqs.forEach(faq => {
        if (faq.question && faq.answer) {
          const normalizedQ = this.normalize(faq.question);
          this.qaMap.set(normalizedQ, faq.answer);
          this.qaArray.push({
            id: faq.id,
            question: faq.question,
            normalizedQuestion: normalizedQ,
            answer: faq.answer
          });
        }
      });

      this.loaded = true;
      console.log(`[FuzzyMatcher] Loaded ${this.qaMap.size} Q&A pairs from train.json`);
      return true;
    } catch (error) {
      console.error('[FuzzyMatcher] Error loading training data:', error);
      return false;
    }
  }

  /**
   * Normalize text for matching
   */
  normalize(text = '') {
    return String(text)
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Calculate Levenshtein distance between two strings
   */
  levenshtein(a = '', b = '') {
    const al = a.length;
    const bl = b.length;
    
    if (!al) return bl;
    if (!bl) return al;

    let prevRow = Array.from({ length: bl + 1 }, (_, j) => j);
    
    for (let i = 1; i <= al; i++) {
      let curRow = [i];
      for (let j = 1; j <= bl; j++) {
        const insertCost = curRow[j - 1] + 1;
        const deleteCost = prevRow[j] + 1;
        const replaceCost = prevRow[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1);
        curRow[j] = Math.min(insertCost, deleteCost, replaceCost);
      }
      prevRow = curRow;
    }
    
    return prevRow[bl];
  }

  /**
   * Calculate normalized Levenshtein distance (0 = identical, 1 = completely different)
   */
  normalizedLevenshtein(a = '', b = '') {
    if (!a && !b) return 0;
    const d = this.levenshtein(a, b);
    const max = Math.max(a.length || 0, b.length || 0);
    return max ? d / max : 0;
  }

  /**
   * Create token set from text
   */
  tokenSet(text = '') {
    return new Set((text || '').split(/\s+/).filter(Boolean));
  }

  /**
   * Calculate token overlap score (0 = no overlap, 1 = perfect overlap)
   */
  tokenOverlapScore(a = '', b = '') {
    const setA = this.tokenSet(a);
    const setB = this.tokenSet(b);
    
    if (setA.size === 0 || setB.size === 0) return 0;
    
    let intersection = 0;
    for (const token of setA) {
      if (setB.has(token)) intersection++;
    }
    
    return intersection / Math.max(setA.size, setB.size);
  }

  /**
   * Find best matching answer using fuzzy matching
   * @param {string} question - User's question
   * @param {number} threshold - Minimum score threshold (0-1)
   * @returns {object|null} - Match result with answer and metadata
   */
  findBestMatch(question, threshold = 0.55) {
    if (!this.loaded || !question) {
      return null;
    }

    const normalizedQ = this.normalize(question);

    // 1. Try exact match first (fastest)
    if (this.qaMap.has(normalizedQ)) {
      return {
        answer: this.qaMap.get(normalizedQ),
        matchType: 'exact',
        score: 1.0,
        confidence: 'high',
        matchedQuestion: question
      };
    }

    // 2. Fuzzy matching with all Q&A pairs
    let bestMatch = {
      answer: null,
      matchedQuestion: null,
      score: 0,
      overlap: 0,
      levDistance: 1,
      matchType: 'fuzzy'
    };

    for (const qa of this.qaArray) {
      const overlap = this.tokenOverlapScore(normalizedQ, qa.normalizedQuestion);
      const lev = this.normalizedLevenshtein(normalizedQ, qa.normalizedQuestion);
      
      // Combined score: 70% token overlap + 30% Levenshtein similarity
      const score = overlap * 0.7 + (1 - lev) * 0.3;
      
      if (score > bestMatch.score) {
        bestMatch = {
          answer: qa.answer,
          matchedQuestion: qa.question,
          score: score,
          overlap: overlap,
          levDistance: lev,
          matchType: 'fuzzy',
          id: qa.id
        };
      }
    }

    // Return match only if it meets threshold
    if (bestMatch.score >= threshold) {
      return {
        ...bestMatch,
        confidence: bestMatch.score >= 0.8 ? 'high' : bestMatch.score >= 0.65 ? 'medium' : 'low'
      };
    }

    return null;
  }

  /**
   * Find multiple matches for a question
   * @param {string} question - User's question
   * @param {number} topN - Number of top matches to return
   * @param {number} threshold - Minimum score threshold
   * @returns {array} - Array of match results
   */
  findTopMatches(question, topN = 3, threshold = 0.4) {
    if (!this.loaded || !question) {
      return [];
    }

    const normalizedQ = this.normalize(question);
    const matches = [];

    for (const qa of this.qaArray) {
      const overlap = this.tokenOverlapScore(normalizedQ, qa.normalizedQuestion);
      const lev = this.normalizedLevenshtein(normalizedQ, qa.normalizedQuestion);
      const score = overlap * 0.7 + (1 - lev) * 0.3;
      
      if (score >= threshold) {
        matches.push({
          answer: qa.answer,
          matchedQuestion: qa.question,
          score: score,
          overlap: overlap,
          levDistance: lev,
          id: qa.id,
          confidence: score >= 0.8 ? 'high' : score >= 0.65 ? 'medium' : 'low'
        });
      }
    }

    // Sort by score descending and return top N
    return matches
      .sort((a, b) => b.score - a.score)
      .slice(0, topN);
  }

  /**
   * Get statistics about loaded data
   */
  getStats() {
    return {
      loaded: this.loaded,
      totalQuestions: this.qaMap.size,
      avgQuestionLength: this.qaArray.reduce((sum, qa) => sum + qa.question.length, 0) / this.qaArray.length || 0,
      avgAnswerLength: this.qaArray.reduce((sum, qa) => sum + qa.answer.length, 0) / this.qaArray.length || 0
    };
  }
}

// Singleton instance
const fuzzyMatcher = new FuzzyMatcher();

module.exports = fuzzyMatcher;
