const Stripe = require('stripe');
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

class StripeService {
  /**
   * Create a checkout session for Pro subscription
   */
  async createCheckoutSession(userEmail, plan = 'pro', duration = 30) {
    try {
      // Determine price based on plan and duration
      const priceAmount = this.calculatePrice(plan, duration);

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: `CyberRazor ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan`,
                description: `${duration} days of premium cybersecurity protection`,
                images: ['https://cyberrazor.vercel.app/logo.png'],
              },
              unit_amount: priceAmount * 100, // Convert to cents
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        success_url: `${process.env.STRIPE_SUCCESS_URL}?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: process.env.STRIPE_CANCEL_URL,
        customer_email: userEmail,
        metadata: {
          plan: plan,
          duration: duration.toString(),
          email: userEmail,
        },
        billing_address_collection: 'required',
      });

      return {
        success: true,
        sessionId: session.id,
        url: session.url,
      };
    } catch (error) {
      console.error('Stripe checkout session creation error:', error);
      throw new Error(`Failed to create checkout session: ${error.message}`);
    }
  }

  /**
   * Create a subscription checkout session (recurring)
   */
  async createSubscriptionSession(userEmail, plan = 'pro') {
    try {
      // Create or get product
      const product = await this.getOrCreateProduct(plan);
      
      // Create or get price
      const price = await this.getOrCreatePrice(product.id, plan);

      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price: price.id,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${process.env.STRIPE_SUCCESS_URL}?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: process.env.STRIPE_CANCEL_URL,
        customer_email: userEmail,
        metadata: {
          plan: plan,
          email: userEmail,
        },
      });

      return {
        success: true,
        sessionId: session.id,
        url: session.url,
      };
    } catch (error) {
      console.error('Stripe subscription creation error:', error);
      throw new Error(`Failed to create subscription: ${error.message}`);
    }
  }

  /**
   * Retrieve checkout session details
   */
  async getSession(sessionId) {
    try {
      const session = await stripe.checkout.sessions.retrieve(sessionId);
      return session;
    } catch (error) {
      console.error('Error retrieving session:', error);
      throw new Error(`Failed to retrieve session: ${error.message}`);
    }
  }

  /**
   * Handle webhook events
   */
  async handleWebhook(payload, signature) {
    try {
      const event = stripe.webhooks.constructEvent(
        payload,
        signature,
        process.env.STRIPE_WEBHOOK_SECRET
      );

      return event;
    } catch (error) {
      console.error('Webhook signature verification failed:', error);
      throw new Error(`Webhook Error: ${error.message}`);
    }
  }

  /**
   * Create a refund
   */
  async createRefund(paymentIntentId, amount = null) {
    try {
      const refundData = {
        payment_intent: paymentIntentId,
      };

      if (amount) {
        refundData.amount = amount * 100; // Convert to cents
      }

      const refund = await stripe.refunds.create(refundData);

      return {
        success: true,
        refund: refund,
      };
    } catch (error) {
      console.error('Refund creation error:', error);
      throw new Error(`Failed to create refund: ${error.message}`);
    }
  }

  /**
   * Get or create a Stripe product
   */
  async getOrCreateProduct(plan) {
    try {
      const products = await stripe.products.list({
        active: true,
        limit: 100,
      });

      const productName = `CyberRazor ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan`;
      let product = products.data.find(p => p.name === productName);

      if (!product) {
        product = await stripe.products.create({
          name: productName,
          description: `CyberRazor ${plan} subscription with advanced AI-powered cybersecurity`,
          images: ['https://cyberrazor.vercel.app/logo.png'],
        });
      }

      return product;
    } catch (error) {
      console.error('Error getting/creating product:', error);
      throw new Error(`Product error: ${error.message}`);
    }
  }

  /**
   * Get or create a Stripe price
   */
  async getOrCreatePrice(productId, plan) {
    try {
      const prices = await stripe.prices.list({
        product: productId,
        active: true,
      });

      const priceAmount = this.getMonthlyPrice(plan);
      let price = prices.data.find(p => p.unit_amount === priceAmount * 100);

      if (!price) {
        price = await stripe.prices.create({
          product: productId,
          unit_amount: priceAmount * 100, // Convert to cents
          currency: 'usd',
          recurring: {
            interval: 'month',
          },
        });
      }

      return price;
    } catch (error) {
      console.error('Error getting/creating price:', error);
      throw new Error(`Price error: ${error.message}`);
    }
  }

  /**
   * Calculate price based on plan and duration
   */
  calculatePrice(plan, duration) {
    const monthlyPrices = {
      basic: 50,
      pro: 200,
      enterprise: 500,
    };

    const monthlyPrice = monthlyPrices[plan.toLowerCase()] || 100;
    const months = Math.ceil(duration / 30);
    
    return monthlyPrice * months;
  }

  /**
   * Get monthly price for plan
   */
  getMonthlyPrice(plan) {
    const prices = {
      basic: 50,
      pro: 200,
      enterprise: 500,
    };

    return prices[plan.toLowerCase()] || 200;
  }

  /**
   * Cancel a subscription
   */
  async cancelSubscription(subscriptionId) {
    try {
      const subscription = await stripe.subscriptions.update(subscriptionId, {
        cancel_at_period_end: true,
      });

      return {
        success: true,
        subscription: subscription,
      };
    } catch (error) {
      console.error('Subscription cancellation error:', error);
      throw new Error(`Failed to cancel subscription: ${error.message}`);
    }
  }

  /**
   * Get customer by email
   */
  async getCustomerByEmail(email) {
    try {
      const customers = await stripe.customers.list({
        email: email,
        limit: 1,
      });

      return customers.data[0] || null;
    } catch (error) {
      console.error('Error fetching customer:', error);
      return null;
    }
  }
}

module.exports = new StripeService();
