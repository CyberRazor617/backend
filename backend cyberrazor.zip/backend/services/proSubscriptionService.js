const crypto = require('crypto');
const nodemailer = require('nodemailer');
const AccessToken = require('../models/AccessToken');
const ProUser = require('../models/ProUser');

class ProSubscriptionService {
  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_SERVER || 'smtp.gmail.com',
      port: process.env.SMTP_PORT || 587,
      secure: false,
      auth: {
        user: process.env.SMTP_USERNAME,
        pass: process.env.SMTP_PASSWORD
      }
    });
  }

  /**
   * Generate a unique access token
   */
  generateAccessToken() {
    // Generate a 32-character alphanumeric token
    return crypto.randomBytes(16).toString('hex').toUpperCase();
  }

  /**
   * Create a new subscription and send access token via email
   */
  async createSubscription(email, plan = 'basic', durationDays = 30) {
    try {
      // Generate unique access token
      const token = this.generateAccessToken();

      // Calculate expiration date (30 days from now for token validity)
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);

      // Create access token record
      const accessToken = new AccessToken({
        token,
        email,
        subscriptionPlan: plan,
        subscriptionDuration: durationDays,
        expiresAt
      });

      await accessToken.save();

      // Send email with access token
      await this.sendAccessTokenEmail(email, token, plan, durationDays);

      return {
        success: true,
        message: 'Subscription created successfully. Access token sent to email.',
        token, // Only for testing, should not be returned in production
        email
      };
    } catch (error) {
      console.error('Error creating subscription:', error);
      throw error;
    }
  }

  /**
   * Send access token email to user
   */
  async sendAccessTokenEmail(email, token, plan, durationDays) {
    const portalUrl = 'https://cyberrazorpro.vercel.app';

    const mailOptions = {
      from: `"CyberRazor Pro" <${process.env.SMTP_USERNAME}>`,
      to: email,
      subject: '🔐 Your CyberRazor Pro Access Token',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            body {
              font-family: 'Arial', sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
            }
            .header {
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              color: white;
              padding: 30px;
              text-align: center;
              border-radius: 10px 10px 0 0;
            }
            .content {
              background: #f9f9f9;
              padding: 30px;
              border-radius: 0 0 10px 10px;
            }
            .token-box {
              background: white;
              border: 2px solid #667eea;
              border-radius: 8px;
              padding: 20px;
              margin: 20px 0;
              text-align: center;
            }
            .token {
              font-size: 24px;
              font-weight: bold;
              color: #667eea;
              letter-spacing: 2px;
              word-break: break-all;
            }
            .button {
              display: inline-block;
              background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
              color: white;
              padding: 15px 30px;
              text-decoration: none;
              border-radius: 5px;
              margin: 20px 0;
              font-weight: bold;
            }
            .info-box {
              background: #e3f2fd;
              border-left: 4px solid #2196f3;
              padding: 15px;
              margin: 20px 0;
            }
            .warning-box {
              background: #fff3e0;
              border-left: 4px solid #ff9800;
              padding: 15px;
              margin: 20px 0;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>🚀 Welcome to CyberRazor Pro!</h1>
            <p>Your subscription is now active</p>
          </div>
          <div class="content">
            <h2>Hello!</h2>
            <p>Thank you for subscribing to CyberRazor Pro - ${plan.charAt(0).toUpperCase() + plan.slice(1)} Plan</p>
            
            <div class="info-box">
              <strong>📦 Subscription Details:</strong>
              <ul>
                <li><strong>Plan:</strong> ${plan.charAt(0).toUpperCase() + plan.slice(1)}</li>
                <li><strong>Duration:</strong> ${durationDays} days</li>
                <li><strong>Features:</strong> AI File Scanning, AI Network Analysis, Complete CIA Audit</li>
              </ul>
            </div>

            <h3>🔑 Your Access Token:</h3>
            <div class="token-box">
              <div class="token">${token}</div>
            </div>

            <div class="warning-box">
              <strong>⚠️ Important:</strong>
              <ul>
                <li>This access token can only be used ONCE to activate your account</li>
                <li>Keep this token secure and do not share it with anyone</li>
                <li>The token will expire in 30 days if not used</li>
              </ul>
            </div>

            <h3>🌐 Get Started:</h3>
            <p>Click the button below to access the Pro Portal and activate your account:</p>
            <div style="text-align: center;">
              <a href="${portalUrl}" class="button">Access Pro Portal</a>
            </div>

            <h3>📋 How to Login:</h3>
            <ol>
              <li>Visit <a href="${portalUrl}">${portalUrl}</a></li>
              <li>Enter your access token: <strong>${token}</strong></li>
              <li>Set up your password</li>
              <li>Start using CyberRazor Pro features!</li>
            </ol>

            <div class="info-box">
              <strong>🛡️ Features Available:</strong>
              <ul>
                <li><strong>AI File Scanning:</strong> Real-time malware detection and analysis</li>
                <li><strong>AI Network Analysis:</strong> Advanced threat detection in network traffic</li>
                <li><strong>CIA Audit:</strong> Complete Confidentiality, Integrity, and Availability assessment</li>
                <li><strong>Real-time Logs:</strong> Monitor all security events in real-time</li>
              </ul>
            </div>

            <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>

            <p>Best regards,<br>
            <strong>The CyberRazor Team</strong></p>
          </div>
        </body>
        </html>
      `
    };

    try {
      await this.transporter.sendMail(mailOptions);
      console.log(`Access token email sent to: ${email}`);
      return true;
    } catch (error) {
      console.error('Error sending access token email:', error);
      throw error;
    }
  }

  /**
   * Validate and activate access token
   */
  async activateAccessToken(token, password) {
    try {
      // Find the access token
      const accessToken = await AccessToken.findOne({ token });

      if (!accessToken) {
        return {
          success: false,
          message: 'Invalid access token'
        };
      }

      if (accessToken.isUsed) {
        return {
          success: false,
          message: 'This access token has already been used'
        };
      }

      if (new Date() > accessToken.expiresAt) {
        return {
          success: false,
          message: 'This access token has expired'
        };
      }

      // Check if user already exists with this email
      let proUser = await ProUser.findOne({ email: accessToken.email });

      if (proUser) {
        return {
          success: false,
          message: 'An account with this email already exists'
        };
      }

      // Calculate subscription end date
      const subscriptionEndDate = new Date();
      subscriptionEndDate.setDate(subscriptionEndDate.getDate() + accessToken.subscriptionDuration);

      // Create new pro user
      proUser = new ProUser({
        email: accessToken.email,
        password: password,
        accessToken: token,
        accessTokenUsed: true,
        subscriptionPlan: accessToken.subscriptionPlan,
        subscriptionStatus: 'active',
        subscriptionEndDate: subscriptionEndDate
      });

      await proUser.save();

      // Mark token as used
      accessToken.isUsed = true;
      accessToken.usedAt = new Date();
      accessToken.usedBy = proUser._id;
      await accessToken.save();

      return {
        success: true,
        message: 'Account activated successfully',
        user: {
          id: proUser._id,
          email: proUser.email,
          plan: proUser.subscriptionPlan,
          subscriptionEndDate: proUser.subscriptionEndDate
        }
      };
    } catch (error) {
      console.error('Error activating access token:', error);
      throw error;
    }
  }

  /**
   * Authenticate pro user
   */
  async authenticateUser(accessToken, password) {
    try {
      const proUser = await ProUser.findOne({ accessToken });

      if (!proUser) {
        return {
          success: false,
          message: 'Invalid credentials'
        };
      }

      const isPasswordValid = await proUser.comparePassword(password);

      if (!isPasswordValid) {
        return {
          success: false,
          message: 'Invalid credentials'
        };
      }

      if (!proUser.isSubscriptionValid()) {
        return {
          success: false,
          message: 'Your subscription has expired. Please renew to continue.'
        };
      }

      // Update last login
      proUser.lastLogin = new Date();
      await proUser.save();

      return {
        success: true,
        message: 'Authentication successful',
        user: {
          id: proUser._id,
          email: proUser.email,
          plan: proUser.subscriptionPlan,
          subscriptionEndDate: proUser.subscriptionEndDate,
          lastLogin: proUser.lastLogin
        }
      };
    } catch (error) {
      console.error('Error authenticating user:', error);
      throw error;
    }
  }

  /**
   * Update user password
   */
  async updatePassword(userId, oldPassword, newPassword) {
    try {
      const proUser = await ProUser.findById(userId);

      if (!proUser) {
        return {
          success: false,
          message: 'User not found'
        };
      }

      const isPasswordValid = await proUser.comparePassword(oldPassword);

      if (!isPasswordValid) {
        return {
          success: false,
          message: 'Current password is incorrect'
        };
      }

      proUser.password = newPassword;
      await proUser.save();

      return {
        success: true,
        message: 'Password updated successfully'
      };
    } catch (error) {
      console.error('Error updating password:', error);
      throw error;
    }
  }
}

module.exports = new ProSubscriptionService();
