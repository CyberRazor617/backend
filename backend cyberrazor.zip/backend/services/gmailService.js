const { google } = require('googleapis');
const fs = require('fs').promises;
const path = require('path');
const { logger } = require('../config/logger');

class GmailService {
  constructor() {
    // OAuth2 credentials
    this.CLIENT_ID = '554902415806-6o4jtbo6lplcivs74sb97minupco2imb.apps.googleusercontent.com';
    this.CLIENT_SECRET = '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';
    this.REDIRECT_URI = 'http://localhost:3000/oauth2callback';
    this.SCOPES = ['https://www.googleapis.com/auth/gmail.send'];
    
    // Token file path
    this.TOKEN_PATH = path.join(__dirname, '..', 'config', 'gmail-token.json');
    
    // Initialize OAuth2 client
    this.oAuth2Client = new google.auth.OAuth2(
      this.CLIENT_ID,
      this.CLIENT_SECRET,
      this.REDIRECT_URI
    );
    
    // Try to load existing tokens, if not available, use a one-time setup
    this.initializeAuth();
  }

  /**
   * Initialize authentication - try to load tokens or provide setup instructions
   */
  async initializeAuth() {
    const hasTokens = await this.loadTokens();
    if (!hasTokens) {
      logger.warn('⚠️ Gmail API not configured. Please run setup once to authorize.');
      logger.info('🔗 Run: node setup-gmail-once.js to authorize Gmail API');
    }
  }

  /**
   * Load tokens from file if they exist
   */
  async loadTokens() {
    try {
      const tokenData = await fs.readFile(this.TOKEN_PATH, 'utf8');
      const tokens = JSON.parse(tokenData);
      this.oAuth2Client.setCredentials(tokens);
      logger.info('✅ Gmail tokens loaded successfully');
      return true;
    } catch (error) {
      logger.warn('⚠️ No existing Gmail tokens found, authorization required');
      return false;
    }
  }

  /**
   * Save tokens to file
   */
  async saveTokens(tokens) {
    try {
      // Ensure config directory exists
      const configDir = path.dirname(this.TOKEN_PATH);
      await fs.mkdir(configDir, { recursive: true });
      
      await fs.writeFile(this.TOKEN_PATH, JSON.stringify(tokens, null, 2));
      logger.info('✅ Gmail tokens saved successfully');
      return true;
    } catch (error) {
      logger.error('❌ Failed to save Gmail tokens:', error);
      return false;
    }
  }

  /**
   * Generate authorization URL for OAuth2 flow
   */
  getAuthUrl() {
    const authUrl = this.oAuth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: this.SCOPES,
      prompt: 'consent' // Force consent screen to get refresh token
    });
    
    logger.info('🔗 Gmail authorization URL generated');
    return authUrl;
  }

  /**
   * Exchange authorization code for tokens
   */
  async authorize(code) {
    try {
      const { tokens } = await this.oAuth2Client.getToken(code);
      this.oAuth2Client.setCredentials(tokens);
      
      // Save tokens for future use
      await this.saveTokens(tokens);
      
      logger.info('✅ Gmail authorization successful');
      return { success: true, tokens };
    } catch (error) {
      logger.error('❌ Gmail authorization failed:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Check if Gmail service is authorized
   */
  isAuthorized() {
    const credentials = this.oAuth2Client.credentials;
    return !!(credentials && credentials.access_token);
  }

  /**
   * Refresh access token if needed
   */
  async refreshTokenIfNeeded() {
    try {
      const credentials = this.oAuth2Client.credentials;
      
      if (!credentials || !credentials.refresh_token) {
        logger.warn('⚠️ No refresh token available, re-authorization required');
        return false;
      }

      // Check if token is expired (with 5 minute buffer)
      const now = new Date().getTime();
      const expiryTime = credentials.expiry_date;
      
      if (expiryTime && now >= (expiryTime - 5 * 60 * 1000)) {
        logger.info('🔄 Refreshing Gmail access token...');
        const { credentials: newCredentials } = await this.oAuth2Client.refreshAccessToken();
        this.oAuth2Client.setCredentials(newCredentials);
        await this.saveTokens(newCredentials);
        logger.info('✅ Gmail access token refreshed');
        return true;
      }
      
      return true;
    } catch (error) {
      logger.error('❌ Failed to refresh Gmail token:', error);
      return false;
    }
  }

  /**
   * Send email using Gmail API
   */
  async sendEmail(to, subject, body, isHTML = true) {
    try {
      // Check if authorized
      if (!this.isAuthorized()) {
        logger.error('❌ Gmail service not authorized');
        return { success: false, error: 'Gmail service not authorized. Please complete OAuth2 flow.' };
      }

      // Refresh token if needed
      const tokenValid = await this.refreshTokenIfNeeded();
      if (!tokenValid) {
        logger.error('❌ Gmail token refresh failed');
        return { success: false, error: 'Token refresh failed. Please re-authorize.' };
      }

      // Create Gmail API instance
      const gmail = google.gmail({ version: 'v1', auth: this.oAuth2Client });

      // Create email message
      const messageParts = [
        `From: "CyberRazor Contact" <cyberrazor0123@gmail.com>`,
        `To: ${to}`,
        `Subject: ${subject}`,
        'MIME-Version: 1.0',
        `Content-Type: ${isHTML ? 'text/html' : 'text/plain'}; charset=UTF-8`,
        '',
        body
      ];

      const message = messageParts.join('\n');

      // Encode message for Gmail API
      const encodedMessage = Buffer.from(message)
        .toString('base64')
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');

      // Send email
      const result = await gmail.users.messages.send({
        userId: 'me',
        requestBody: {
          raw: encodedMessage
        }
      });

      logger.info(`📧 Email sent successfully via Gmail API to: ${to}`);
      logger.debug('Gmail API response:', result.data);

      return { 
        success: true, 
        messageId: result.data.id,
        threadId: result.data.threadId
      };

    } catch (error) {
      logger.error('❌ Gmail API email sending failed:', error);
      return { 
        success: false, 
        error: error.message,
        details: error.response?.data || null
      };
    }
  }

  /**
   * Send approval email
   */
  async sendApprovalEmail(userEmail, username) {
    const subject = 'You got approved! 🚀';
    
    const htmlBody = `
      <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="text-align: center; margin-bottom: 30px;">
                  <h1 style="color: #2563eb; margin-bottom: 10px;">🛡️ CyberRazor</h1>
                  <h2 style="color: #1f2937; margin-bottom: 20px;">You got approved! 🚀</h2>
              </div>
              
              <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                  <p style="margin-bottom: 15px;">Dear <strong>${username}</strong>,</p>
                  
                  <p style="margin-bottom: 15px;">🎉 <strong>Great news! Your account has been approved!</strong></p>
                  
                  <p style="margin-bottom: 15px;">Now login to your user portal with your registered credentials.</p>
                  
                  <div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
                      <h3 style="color: #0369a1; margin-bottom: 15px;">🔗 Login to Your Portal</h3>
                      <a href="http://localhost:3000/login" 
                         style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 16px;">
                          Login to CyberRazor Portal
                      </a>
                      <p style="margin-top: 10px; color: #6b7280; font-size: 14px;">
                          Here is the link: <a href="http://localhost:3000/login" style="color: #667eea;">http://localhost:3000/login</a>
                      </p>
                  </div>
                  
                  <div style="background: #fef3c7; padding: 15px; border-radius: 6px; margin: 20px 0;">
                      <h3 style="color: #92400e; margin-bottom: 10px;">🎁 What's Next:</h3>
                      <ul style="margin: 0; padding-left: 20px;">
                          <li>Access your 7-day free trial with full features</li>
                          <li>Download your unique activation key</li>
                          <li>Set up your security agent</li>
                          <li>Start protecting your digital assets</li>
                      </ul>
                  </div>
                  
                  <p style="margin-bottom: 15px;">Welcome to the CyberRazor family! We're excited to help you secure your digital world.</p>
                  
                  <p style="margin-bottom: 0;">Best regards,<br>
                  <strong>The CyberRazor Team</strong></p>
              </div>
              
              <div style="text-align: center; color: #6b7280; font-size: 12px;">
                  <p>This is an automated message. Please do not reply to this email.</p>
              </div>
          </div>
      </body>
      </html>
    `;

    // Send email
    const result = await this.sendEmail(userEmail, subject, htmlBody, true);
    
    if (result.success) {
      logger.info(`📧 Approval email sent successfully to: ${userEmail}`);
    } else {
      logger.error(`❌ Failed to send approval email: ${result.error}`);
    }

    return result;
  }

  /**
   * Send appointment/contact form email
   */
  async sendAppointmentEmail(contactData) {
    const { name, email, company, phone, message, service } = contactData;
    const subject = '🚀 New Appointment Request - CyberRazor';
    const recipientEmail = 'cyberrazor0123@gmail.com';
    
    const htmlBody = `
      <html>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
          <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="text-align: center; margin-bottom: 30px;">
                  <h1 style="color: #2563eb; margin-bottom: 10px;">🛡️ CyberRazor</h1>
                  <h2 style="color: #1f2937; margin-bottom: 20px;">New Appointment Request</h2>
              </div>
              
              <div style="background: #f8f9fa; padding: 30px; border-radius: 8px; border: 1px solid #e9ecef;">
                  <h2 style="color: #333; margin-top: 0;">Contact Details</h2>
                  
                  <div style="background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                      <p style="margin: 0 0 10px 0;"><strong>👤 Name:</strong> ${name}</p>
                      <p style="margin: 0 0 10px 0;"><strong>📧 Email:</strong> <a href="mailto:${email}" style="color: #667eea;">${email}</a></p>
                      ${company ? `<p style="margin: 0 0 10px 0;"><strong>🏢 Company:</strong> ${company}</p>` : ''}
                      ${phone ? `<p style="margin: 0 0 10px 0;"><strong>📞 Phone:</strong> ${phone}</p>` : ''}
                      ${service ? `<p style="margin: 0;"><strong>🔧 Service Interest:</strong> ${service}</p>` : ''}
                  </div>
                  
                  <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                      <h3 style="color: #333; margin-top: 0;">Message</h3>
                      <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #667eea;">
                          ${message.replace(/\n/g, '<br>')}
                      </div>
                  </div>
                  
                  <div style="margin-top: 20px; padding: 15px; background: #e3f2fd; border-radius: 8px; border-left: 4px solid #2196f3;">
                      <p style="margin: 0; color: #1976d2; font-size: 14px;">
                          <strong>📅 Submitted:</strong> ${new Date().toLocaleString()}<br>
                          <strong>🌐 Source:</strong> CyberRazor Pricing Page - Contact Us
                      </p>
                  </div>
              </div>
              
              <div style="text-align: center; margin-top: 20px; color: #666; font-size: 12px;">
                  <p>This email was sent from the CyberRazor contact form.</p>
                  <p>© 2024 CyberRazor. All rights reserved.</p>
              </div>
          </div>
      </body>
      </html>
    `;

    // Send email
    const result = await this.sendEmail(recipientEmail, subject, htmlBody, true);
    
    if (result.success) {
      logger.info(`📧 Appointment email sent successfully to: ${recipientEmail}`);
    } else {
      logger.error(`❌ Failed to send appointment email: ${result.error}`);
    }

    return result;
  }

  /**
   * Get authorization status and instructions
   */
  getAuthStatus() {
    const isAuth = this.isAuthorized();
    const authUrl = this.getAuthUrl();
    
    return {
      authorized: isAuth,
      authUrl: isAuth ? null : authUrl,
      instructions: isAuth ? 
        'Gmail service is authorized and ready to send emails.' :
        'Gmail service requires authorization. Visit the authUrl to complete OAuth2 flow.'
    };
  }
}

// Create singleton instance
const gmailService = new GmailService();

module.exports = gmailService;
