const WebSocket = require('ws');
const { logger } = require('../config/logger');

class ProLogStreamService {
  constructor() {
    this.wss = null;
    this.clients = new Map(); // Map of userId -> WebSocket connection
    this.agentConnections = new Map(); // Map of agentId -> WebSocket connection
  }

  /**
   * Initialize WebSocket server
   */
  initialize(server) {
    this.wss = new WebSocket.Server({ 
      server,
      path: '/pro-logs'
    });

    this.wss.on('connection', (ws, req) => {
      this.handleConnection(ws, req);
    });

    logger.info('ProLogStreamService initialized');
  }

  /**
   * Handle new WebSocket connection
   */
  handleConnection(ws, req) {
    logger.info('New WebSocket connection established');

    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message);
        this.handleMessage(ws, data);
      } catch (error) {
        logger.error('Error parsing WebSocket message:', error);
        ws.send(JSON.stringify({ 
          type: 'error', 
          message: 'Invalid message format' 
        }));
      }
    });

    ws.on('close', () => {
      this.handleDisconnection(ws);
    });

    ws.on('error', (error) => {
      logger.error('WebSocket error:', error);
    });

    // Send welcome message
    ws.send(JSON.stringify({ 
      type: 'connected', 
      message: 'Connected to ProLogStreamService' 
    }));
  }

  /**
   * Handle incoming WebSocket messages
   */
  handleMessage(ws, data) {
    const { type, payload } = data;

    switch (type) {
      case 'register_client':
        this.registerClient(ws, payload);
        break;
      
      case 'register_agent':
        this.registerAgent(ws, payload);
        break;
      
      case 'log':
        this.broadcastLog(payload);
        break;
      
      case 'ping':
        ws.send(JSON.stringify({ type: 'pong' }));
        break;
      
      default:
        logger.warn(`Unknown message type: ${type}`);
    }
  }

  /**
   * Register a pro portal client (web browser)
   */
  registerClient(ws, payload) {
    const { userId, accessToken } = payload;

    if (!userId || !accessToken) {
      ws.send(JSON.stringify({ 
        type: 'error', 
        message: 'Missing userId or accessToken' 
      }));
      return;
    }

    // Store client connection
    this.clients.set(userId, ws);
    ws.userId = userId;
    ws.accessToken = accessToken;

    logger.info(`Pro portal client registered: ${userId}`);

    ws.send(JSON.stringify({ 
      type: 'registered', 
      message: 'Client registered successfully',
      userId 
    }));
  }

  /**
   * Register an agent (pro.py script)
   */
  registerAgent(ws, payload) {
    const { agentId, userId } = payload;

    if (!agentId) {
      ws.send(JSON.stringify({ 
        type: 'error', 
        message: 'Missing agentId' 
      }));
      return;
    }

    // Store agent connection
    this.agentConnections.set(agentId, ws);
    ws.agentId = agentId;
    ws.userId = userId;

    logger.info(`Agent registered: ${agentId}`);

    ws.send(JSON.stringify({ 
      type: 'registered', 
      message: 'Agent registered successfully',
      agentId 
    }));
  }

  /**
   * Broadcast log to all connected pro portal clients
   */
  broadcastLog(logData) {
    const message = JSON.stringify({
      type: 'log',
      payload: logData,
      timestamp: new Date().toISOString()
    });

    // Broadcast to all connected clients
    this.clients.forEach((clientWs, userId) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(message);
      } else {
        // Clean up disconnected clients
        this.clients.delete(userId);
      }
    });
  }

  /**
   * Send log to specific user
   */
  sendLogToUser(userId, logData) {
    const clientWs = this.clients.get(userId);

    if (clientWs && clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(JSON.stringify({
        type: 'log',
        payload: logData,
        timestamp: new Date().toISOString()
      }));
    }
  }

  /**
   * Handle client disconnection
   */
  handleDisconnection(ws) {
    if (ws.userId) {
      this.clients.delete(ws.userId);
      logger.info(`Pro portal client disconnected: ${ws.userId}`);
    }

    if (ws.agentId) {
      this.agentConnections.delete(ws.agentId);
      logger.info(`Agent disconnected: ${ws.agentId}`);
    }
  }

  /**
   * Get connected clients count
   */
  getConnectedClientsCount() {
    return this.clients.size;
  }

  /**
   * Get connected agents count
   */
  getConnectedAgentsCount() {
    return this.agentConnections.size;
  }
}

module.exports = new ProLogStreamService();
