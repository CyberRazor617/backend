const nodemailer = require('nodemailer');
const { logger } = require('../config/logger');
const gmailService = require('./gmailService');

// Create transporter
const createTransporter = () => {
  const smtpConfig = {
    host: process.env.SMTP_SERVER || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.SMTP_USERNAME,
      pass: process.env.SMTP_PASSWORD
    },
    tls: {
      rejectUnauthorized: false
    }
  };

  return nodemailer.createTransport(smtpConfig);
};

// Check if SMTP is configured
const isSMTPConfigured = () => {
  return !!(process.env.SMTP_USERNAME && process.env.SMTP_PASSWORD);
};

// Send email
const sendEmail = async (toEmail, subject, body, isHTML = true) => {
  if (!isSMTPConfigured()) {
    logger.warn('⚠️ Email not sent - SMTP not configured');
    return false;
  }

  try {
    const transporter = createTransporter();
    
    // Create message
    const mailOptions = {
      from: process.env.SMTP_USERNAME,
      to: toEmail,
      subject: subject,
      ...(isHTML ? { html: body } : { text: body })
    };

    // Send email
    const info = await transporter.sendMail(mailOptions);
    
    logger.info(`📧 Email sent successfully to: ${toEmail}`);
    logger.debug('Email details:', {
      messageId: info.messageId,
      response: info.response
    });
    
    return true;
    
  } catch (error) {
    logger.error(`❌ Email sending failed: ${error.message}`);
    logger.error('Email error details:', {
      to: toEmail,
      subject: subject,
      error: error.stack
    });
    return false;
  }
};

// Send welcome email (updated for pending status)
const sendWelcomeEmail = async (userEmail, username, activationKey) => {
  const subject = 'Welcome to CyberRazor - Account Request Submitted';
  
  const body = `
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #2563eb; margin-bottom: 10px;">🛡️ CyberRazor</h1>
                <h2 style="color: #1f2937; margin-bottom: 20px;">Thank you for signing up!</h2>
            </div>
            
            <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin-bottom: 15px;">Hello <strong>${username}</strong>,</p>
                
                <p style="margin-bottom: 15px;">Thank you for signing up with CyberRazor!</p>
                
                <p style="margin-bottom: 15px;">Your account request has been successfully submitted and is currently under review by our team. You will receive a confirmation email once your account has been approved. We appreciate your patience and look forward to securing your digital journey with us.</p>
                
                <div style="background: #e0f2fe; padding: 15px; border-radius: 6px; margin: 20px 0;">
                    <h3 style="color: #0369a1; margin-bottom: 10px;">📋 Account Details:</h3>
                    <ul style="margin: 0; padding-left: 20px;">
                        <li><strong>Username:</strong> ${username}</li>
                        <li><strong>Email:</strong> ${userEmail}</li>
                        <li><strong>Status:</strong> <span style="color: #f59e0b; font-weight: bold;">Pending Review</span></li>
                    </ul>
                </div>
                
                <p style="margin-bottom: 15px;">Once approved, you'll receive:</p>
                <ul style="margin-bottom: 15px; padding-left: 20px;">
                    <li>🔑 Your unique activation key for both web dashboard and agent activation</li>
                    <li>🚀 7-day free trial with full access to advanced features</li>
                    <li>🛡️ Industry-leading security protection for your digital assets</li>
                </ul>
                
                <p style="margin-bottom: 15px;">We're committed to providing you with the highest standards of security and protection.</p>
                
                <p style="margin-bottom: 0;">Best regards,<br>
                <strong>The CyberRazor Team</strong></p>
            </div>
            
            <div style="text-align: center; color: #6b7280; font-size: 12px;">
                <p>This is an automated message. Please do not reply to this email.</p>
            </div>
        </div>
    </body>
    </html>
  `;
  
  return await sendEmail(userEmail, subject, body, true);
};

// Send approval email with congratulations message
const sendApprovalEmail = async (userEmail, username) => {
  const subject = '🎉 Congratulations! Your CyberRazor Account is Approved';
  
  const body = `
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #2563eb; margin-bottom: 10px;">🛡️ CyberRazor</h1>
                <h2 style="color: #10b981; margin-bottom: 20px;">🎉 Congratulations!</h2>
            </div>
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
                <h2 style="color: white; margin: 0; font-size: 28px;">Your Account Has Been Approved! 🚀</h2>
            </div>
            
            <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #10b981;">
                <p style="margin-bottom: 15px;">Dear <strong>${username}</strong>,</p>
                
                <p style="margin-bottom: 15px; font-size: 18px; color: #059669;">
                    <strong>🎊 Great news! Your CyberRazor account has been approved by our admin team!</strong>
                </p>
                
                <p style="margin-bottom: 15px;">
                    You can now access your user portal and start protecting your digital assets with our advanced security solutions.
                </p>
                
                <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <h3 style="color: #0369a1; margin-bottom: 15px;">🔗 Access Your Portal</h3>
                    <a href="https://cyberrazor.vercel.app/login" 
                       style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 18px; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);">
                        Login to CyberRazor Portal
                    </a>
                </div>
                
                <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #92400e; margin-bottom: 15px; text-align: center;">🎁 What You Get:</h3>
                    <ul style="margin: 0; padding-left: 20px; color: #78350f;">
                        <li style="margin-bottom: 10px;"><strong>7-Day Free Trial</strong> - Full access to all premium features</li>
                        <li style="margin-bottom: 10px;"><strong>Unique Activation Key</strong> - For web dashboard and agent activation</li>
                        <li style="margin-bottom: 10px;"><strong>Real-time Threat Monitoring</strong> - 24/7 security protection</li>
                        <li style="margin-bottom: 10px;"><strong>AI-Powered Analysis</strong> - Advanced threat detection</li>
                        <li style="margin-bottom: 10px;"><strong>Comprehensive Dashboard</strong> - Monitor all your security metrics</li>
                    </ul>
                </div>
                
                <div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #1e40af; margin-bottom: 15px; text-align: center;">🚀 Next Steps:</h3>
                    <ol style="margin: 0; padding-left: 20px; color: #1e3a8a;">
                        <li style="margin-bottom: 10px;">Login to your portal using your registered credentials</li>
                        <li style="margin-bottom: 10px;">Download your unique activation key from the dashboard</li>
                        <li style="margin-bottom: 10px;">Install the CyberRazor security agent on your devices</li>
                        <li style="margin-bottom: 10px;">Start monitoring and protecting your digital assets</li>
                    </ol>
                </div>
                
                <p style="margin-bottom: 15px; font-size: 16px;">
                    <strong>Welcome to the CyberRazor family!</strong> We're excited to help you secure your digital world with cutting-edge cybersecurity technology.
                </p>
                
                <p style="margin-bottom: 0;">
                    Best regards,<br>
                    <strong>The CyberRazor Team</strong><br>
                    <span style="color: #6b7280; font-size: 14px;">Your Trusted Security Partner</span>
                </p>
            </div>
            
            <div style="text-align: center; color: #6b7280; font-size: 12px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                <p>This is an automated message. Please do not reply to this email.</p>
                <p style="margin-top: 10px;">© 2024 CyberRazor. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
  `;
  
  return await sendEmail(userEmail, subject, body, true);
};

// Send rejection email
const sendRejectionEmail = async (userEmail, username, rejectionReason) => {
  const subject = 'CyberRazor - Account Application Update';
  
  const body = `
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #2563eb; margin-bottom: 10px;">🛡️ CyberRazor</h1>
                <h2 style="color: #1f2937; margin-bottom: 20px;">Account Application Update</h2>
            </div>
            
            <div style="background: #fef2f2; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin-bottom: 15px;">Dear <strong>${username}</strong>,</p>
                
                <p style="margin-bottom: 15px;">Thank you for your interest in CyberRazor. After careful review of your application, we regret to inform you that we are unable to approve your account at this time.</p>
                
                <div style="background: #fee2e2; padding: 15px; border-radius: 6px; margin: 20px 0;">
                    <h3 style="color: #991b1b; margin-bottom: 10px;">Reason for Rejection:</h3>
                    <p style="margin-bottom: 0; color: #7f1d1d;">${rejectionReason}</p>
                </div>
                
                <p style="margin-bottom: 15px;">If you believe this decision was made in error or if you would like to provide additional information, please contact our support team.</p>
                
                <p style="margin-bottom: 0;">Best regards,<br>
                <strong>The CyberRazor Team</strong></p>
            </div>
            
            <div style="text-align: center; color: #6b7280; font-size: 12px;">
                <p>This is an automated message. Please do not reply to this email.</p>
            </div>
        </div>
    </body>
    </html>
  `;
  
  return await sendEmail(userEmail, subject, body, true);
};

// Send password reset email
const sendPasswordResetEmail = async (userEmail, resetToken) => {
  const subject = 'CyberRazor - Password Reset Request';
  
  const body = `
    <html>
    <body>
        <h2>Password Reset Request 🔐</h2>
        <p>Hello,</p>
        <p>You have requested to reset your password for your CyberRazor account.</p>
        
        <p><strong>Reset Token:</strong> ${resetToken}</p>
        
        <p>If you did not request this password reset, please ignore this email.</p>
        
        <p>This token will expire in 1 hour for security reasons.</p>
        
        <p>Best regards,<br>
        The CyberRazor Team</p>
    </body>
    </html>
  `;
  
  return await sendEmail(userEmail, subject, body, true);
};

// Send threat alert email
const sendThreatAlertEmail = async (userEmail, threatDetails) => {
  const subject = '🚨 CyberRazor - Security Threat Detected';
  
  const body = `
    <html>
    <body>
        <h2>Security Threat Detected! 🚨</h2>
        <p>Hello,</p>
        <p>A security threat has been detected on your system:</p>
        
        <h3>Threat Details:</h3>
        <ul>
            <li><strong>File:</strong> ${threatDetails.file_path}</li>
            <li><strong>Type:</strong> ${threatDetails.threat_type}</li>
            <li><strong>Severity:</strong> ${threatDetails.severity}</li>
            <li><strong>Confidence:</strong> ${threatDetails.confidence_score}</li>
            <li><strong>Action:</strong> ${threatDetails.action_taken}</li>
        </ul>
        
        <p><strong>AI Verdict:</strong> ${threatDetails.ai_verdict || 'N/A'}</p>
        <p><strong>AI Confidence:</strong> ${threatDetails.ai_confidence || 'N/A'}</p>
        
        <p>Please review this threat in your CyberRazor dashboard and take appropriate action.</p>
        
        <p>Best regards,<br>
        The CyberRazor Security Team</p>
    </body>
    </html>
  `;
  
  return await sendEmail(userEmail, subject, body, true);
};

// Send system status email
const sendSystemStatusEmail = async (userEmail, statusDetails) => {
  const subject = '📊 CyberRazor - System Status Report';
  
  const body = `
    <html>
    <body>
        <h2>System Status Report 📊</h2>
        <p>Hello,</p>
        <p>Here's your CyberRazor system status report:</p>
        
        <h3>System Overview:</h3>
        <ul>
            <li><strong>Total Devices:</strong> ${statusDetails.totalDevices}</li>
            <li><strong>Active Threats:</strong> ${statusDetails.activeThreats}</li>
            <li><strong>Scans Completed:</strong> ${statusDetails.scansCompleted}</li>
            <li><strong>System Status:</strong> ${statusDetails.systemStatus}</li>
        </ul>
        
        <p>Your system is being monitored 24/7 for security threats.</p>
        
        <p>Best regards,<br>
        The CyberRazor Team</p>
    </body>
    </html>
  `;
  
  return await sendEmail(userEmail, subject, body, true);
};

// Test email configuration
const testEmailConfiguration = async () => {
  if (!isSMTPConfigured()) {
    return {
      success: false,
      message: 'SMTP not configured',
      details: 'SMTP_USERNAME and SMTP_PASSWORD environment variables are required'
    };
  }

  try {
    const transporter = createTransporter();
    
    // Verify connection
    await transporter.verify();
    
    return {
      success: true,
      message: 'SMTP configuration is valid',
      details: {
        host: process.env.SMTP_SERVER,
        port: process.env.SMTP_PORT,
        username: process.env.SMTP_USERNAME
      }
    };
    
  } catch (error) {
    return {
      success: false,
      message: 'SMTP configuration test failed',
      details: error.message
    };
  }
};

module.exports = {
  sendEmail,
  sendWelcomeEmail,
  sendApprovalEmail,
  sendRejectionEmail,
  sendPasswordResetEmail,
  sendThreatAlertEmail,
  sendSystemStatusEmail,
  testEmailConfiguration,
  isSMTPConfigured
};
