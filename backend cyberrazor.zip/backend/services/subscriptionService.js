const { logger } = require('../config/logger');
const User = require('../models/User');

// Check and transition expired trials to free tier
const checkAndTransitionExpiredTrials = async () => {
  try {
    logger.info('🔄 Checking for expired trials...');
    
    const now = new Date();
    const expiredTrials = await User.find({
      subscription_plan: 'trial',
      trial_end_date: { $lt: now }
    });
    
    if (expiredTrials.length === 0) {
      logger.info('✅ No expired trials found');
      return { processed: 0, transitions: 0 };
    }
    
    logger.info(`📊 Found ${expiredTrials.length} expired trials`);
    
    let transitions = 0;
    for (const user of expiredTrials) {
      try {
        await user.transitionToFreeTier();
        transitions++;
        logger.info(`✅ User ${user.email} transitioned from trial to free tier`);
      } catch (error) {
        logger.error(`❌ Failed to transition user ${user.email}: ${error.message}`);
      }
    }
    
    logger.info(`✅ Processed ${expiredTrials.length} users, ${transitions} transitions completed`);
    return { processed: expiredTrials.length, transitions };
    
  } catch (error) {
    logger.error('❌ Error checking expired trials:', error);
    throw error;
  }
};

// Get trial statistics
const getTrialStats = async () => {
  try {
    const now = new Date();
    
    const stats = await User.aggregate([
      {
        $group: {
          _id: '$subscription_plan',
          count: { $sum: 1 },
          activeTrials: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $eq: ['$subscription_plan', 'trial'] },
                    { $gt: ['$trial_end_date', now] }
                  ]
                },
                1,
                0
              ]
            }
          },
          expiredTrials: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $eq: ['$subscription_plan', 'trial'] },
                    { $lt: ['$trial_end_date', now] }
                  ]
                },
                1,
                0
              ]
            }
          }
        }
      }
    ]);
    
    const result = {
      trial: { count: 0, active: 0, expired: 0 },
      free: { count: 0 },
      pro: { count: 0 },
      enterprise: { count: 0 }
    };
    
    stats.forEach(stat => {
      if (stat._id === 'trial') {
        result.trial.count = stat.count;
        result.trial.active = stat.activeTrials;
        result.trial.expired = stat.expiredTrials;
      } else if (stat._id) {
        result[stat._id] = { count: stat.count };
      }
    });
    
    return result;
    
  } catch (error) {
    logger.error('❌ Error getting trial stats:', error);
    throw error;
  }
};

// Get users with expiring trials (within next X days)
const getExpiringTrials = async (days = 3) => {
  try {
    const now = new Date();
    const futureDate = new Date(now.getTime() + (days * 24 * 60 * 60 * 1000));
    
    const expiringTrials = await User.find({
      subscription_plan: 'trial',
      trial_end_date: {
        $gte: now,
        $lte: futureDate
      }
    }).select('username email trial_end_date created_at');
    
    return expiringTrials;
    
  } catch (error) {
    logger.error('❌ Error getting expiring trials:', error);
    throw error;
  }
};

// Manually transition a user to free tier
const transitionUserToFreeTier = async (userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    if (user.subscription_plan !== 'trial') {
      throw new Error('User is not on trial plan');
    }
    
    await user.transitionToFreeTier();
    logger.info(`✅ User ${user.email} manually transitioned to free tier`);
    
    return {
      success: true,
      user: {
        id: user._id.toString(),
        email: user.email,
        username: user.username,
        subscription_plan: user.subscription_plan,
        trial_end_date: user.trial_end_date
      }
    };
    
  } catch (error) {
    logger.error(`❌ Error transitioning user ${userId}:`, error);
    throw error;
  }
};

// Extend user trial
const extendUserTrial = async (userId, additionalDays = 7) => {
  try {
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    if (user.subscription_plan !== 'trial') {
      throw new Error('User is not on trial plan');
    }
    
    const newEndDate = new Date(user.trial_end_date.getTime() + (additionalDays * 24 * 60 * 60 * 1000));
    user.trial_end_date = newEndDate;
    await user.save();
    
    logger.info(`✅ User ${user.email} trial extended by ${additionalDays} days`);
    
    return {
      success: true,
      user: {
        id: user._id.toString(),
        email: user.email,
        username: user.username,
        subscription_plan: user.subscription_plan,
        trial_end_date: user.trial_end_date
      }
    };
    
  } catch (error) {
    logger.error(`❌ Error extending trial for user ${userId}:`, error);
    throw error;
  }
};

// Upgrade user to pro plan
const upgradeUserToPro = async (userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    user.subscription_plan = 'pro';
    user.subscription_status = 'active';
    user.subscription_end_date = new Date(Date.now() + (30 * 24 * 60 * 60 * 1000)); // 30 days
    await user.save();
    
    logger.info(`✅ User ${user.email} upgraded to pro plan`);
    
    return {
      success: true,
      user: {
        id: user._id.toString(),
        email: user.email,
        username: user.username,
        subscription_plan: user.subscription_plan,
        subscription_end_date: user.subscription_end_date
      }
    };
    
  } catch (error) {
    logger.error(`❌ Error upgrading user ${userId} to pro:`, error);
    throw error;
  }
};

// Downgrade user to free plan
const downgradeUserToFree = async (userId) => {
  try {
    const user = await User.findById(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    user.subscription_plan = 'free';
    user.subscription_status = 'active';
    user.subscription_end_date = null;
    await user.save();
    
    logger.info(`✅ User ${user.email} downgraded to free plan`);
    
    return {
      success: true,
      user: {
        id: user._id.toString(),
        email: user.email,
        username: user.username,
        subscription_plan: user.subscription_plan
      }
    };
    
  } catch (error) {
    logger.error(`❌ Error downgrading user ${userId} to free:`, error);
    throw error;
  }
};

module.exports = {
  checkAndTransitionExpiredTrials,
  getTrialStats,
  getExpiringTrials,
  transitionUserToFreeTier,
  extendUserTrial,
  upgradeUserToPro,
  downgradeUserToFree
};
