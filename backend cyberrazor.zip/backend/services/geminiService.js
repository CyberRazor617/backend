const { GoogleGenerativeAI } = require('@google/generative-ai');
const { logger } = require('../config/logger');
const fs = require('fs').promises;
const path = require('path');

class GeminiService {
  constructor() {
    this.apiKey = process.env.GEMINI_API_KEY;
    this.genAI = null;
    this.model = null;
    this.isInitialized = false;
    
    this.initialize();
  }

  initialize() {
    if (!this.apiKey) {
      logger.warn('⚠️ Gemini AI not configured - GEMINI_API_KEY not set');
      return;
    }

    try {
      this.genAI = new GoogleGenerativeAI(this.apiKey);
      this.model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });
      this.isInitialized = true;
      logger.info('✅ Gemini AI service initialized successfully');
    } catch (error) {
      logger.error('❌ Failed to initialize Gemini AI service:', error);
      this.isInitialized = false;
    }
  }

  // Check if service is available
  isAvailable() {
    return this.isInitialized && this.model !== null;
  }

  // Analyze file content for threats
  async analyzeFileContent(filePath, fileContent, fileType) {
    if (!this.isAvailable()) {
      throw new Error('Gemini AI service not available');
    }

    try {
      const prompt = this.buildThreatAnalysisPrompt(filePath, fileContent, fileType);
      
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      return this.parseThreatAnalysisResponse(text);
      
    } catch (error) {
      logger.error(`❌ Gemini AI analysis failed for ${filePath}:`, error);
      throw new Error(`AI analysis failed: ${error.message}`);
    }
  }

  // Build threat analysis prompt
  buildThreatAnalysisPrompt(filePath, fileContent, fileType) {
    const filename = path.basename(filePath);
    
    return `
You are a cybersecurity expert analyzing a file for potential threats. Please analyze the following file and provide a detailed security assessment.

File Information:
- Path: ${filePath}
- Filename: ${filename}
- Type: ${fileType}
- Content Length: ${fileContent.length} characters

Please analyze this file for:
1. Malicious code or patterns
2. Suspicious behavior indicators
3. Potential security threats
4. Risk level assessment

Provide your analysis in the following JSON format:
{
  "verdict": "Safe|Suspicious|Threat Detected|Unknown",
  "confidence": "XX%",
  "threat_type": "malware|suspicious|phishing|ransomware|trojan|backdoor|keylogger|other|none",
  "severity": "low|medium|high|critical",
  "risk_score": 0.0-1.0,
  "details": "Detailed explanation of findings",
  "recommendations": "Security recommendations",
  "indicators": ["list", "of", "suspicious", "indicators"],
  "false_positive_risk": "low|medium|high"
}

File Content:
${fileContent.substring(0, 10000)}${fileContent.length > 10000 ? '\n\n[Content truncated for analysis]' : ''}

Please provide only the JSON response, no additional text.
    `;
  }

  // Parse AI response
  parseThreatAnalysisResponse(response) {
    try {
      // Extract JSON from response
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON response found in AI output');
      }

      const parsed = JSON.parse(jsonMatch[0]);
      
      // Validate required fields
      const requiredFields = ['verdict', 'confidence', 'threat_type', 'severity', 'risk_score'];
      for (const field of requiredFields) {
        if (!parsed[field]) {
          throw new Error(`Missing required field: ${field}`);
        }
      }

      return {
        ai_verdict: parsed.verdict,
        ai_confidence: parsed.confidence,
        threat_type: parsed.threat_type,
        severity: parsed.severity,
        confidence_score: parsed.risk_score,
        ai_reason: parsed.details,
        recommendations: parsed.recommendations,
        indicators: parsed.indicators || [],
        false_positive_risk: parsed.false_positive_risk || 'medium'
      };

    } catch (error) {
      logger.error('❌ Failed to parse Gemini AI response:', error);
      logger.debug('Raw response:', response);
      
      // Return fallback analysis
      return {
        ai_verdict: 'Unknown',
        ai_confidence: '50%',
        threat_type: 'other',
        severity: 'medium',
        confidence_score: 0.5,
        ai_reason: 'AI analysis failed, manual review recommended',
        recommendations: 'Review file manually for security assessment',
        indicators: [],
        false_positive_risk: 'high'
      };
    }
  }

  // Analyze file metadata
  async analyzeFileMetadata(filePath, fileStats) {
    if (!this.isAvailable()) {
      throw new Error('Gemini AI service not available');
    }

    try {
      const prompt = `
You are a cybersecurity expert analyzing file metadata for potential threats. Please assess the following file metadata:

File Path: ${filePath}
File Size: ${fileStats.size} bytes
File Type: ${path.extname(filePath)}
Created: ${fileStats.birthtime}
Modified: ${fileStats.mtime}
Permissions: ${fileStats.mode}

Please analyze this metadata for:
1. Suspicious file characteristics
2. Potential security risks
3. Unusual patterns

Provide your analysis in JSON format:
{
  "risk_level": "low|medium|high",
  "suspicious_indicators": ["list", "of", "indicators"],
  "recommendations": "Security recommendations",
  "needs_deeper_analysis": true|false
}
      `;

      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      return this.parseMetadataAnalysisResponse(text);
      
    } catch (error) {
      logger.error(`❌ Gemini AI metadata analysis failed for ${filePath}:`, error);
      throw new Error(`AI metadata analysis failed: ${error.message}`);
    }
  }

  // Parse metadata analysis response
  parseMetadataAnalysisResponse(response) {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON response found in metadata analysis');
      }

      const parsed = JSON.parse(jsonMatch[0]);
      
      return {
        risk_level: parsed.risk_level || 'low',
        suspicious_indicators: parsed.suspicious_indicators || [],
        recommendations: parsed.recommendations || 'No specific recommendations',
        needs_deeper_analysis: parsed.needs_deeper_analysis || false
      };

    } catch (error) {
      logger.error('❌ Failed to parse metadata analysis response:', error);
      return {
        risk_level: 'low',
        suspicious_indicators: [],
        recommendations: 'Metadata analysis failed',
        needs_deeper_analysis: true
      };
    }
  }

  // Batch analyze multiple files
  async batchAnalyzeFiles(files) {
    if (!this.isAvailable()) {
      throw new Error('Gemini AI service not available');
    }

    const results = [];
    
    for (const file of files) {
      try {
        const analysis = await this.analyzeFileContent(
          file.path, 
          file.content, 
          file.type
        );
        
        results.push({
          file_path: file.path,
          analysis: analysis,
          success: true
        });
        
        // Add delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 100));
        
      } catch (error) {
        logger.error(`❌ Batch analysis failed for ${file.path}:`, error);
        results.push({
          file_path: file.path,
          analysis: null,
          success: false,
          error: error.message
        });
      }
    }
    
    return results;
  }

  // Get service status
  getStatus() {
    return {
      available: this.isAvailable(),
      initialized: this.isInitialized,
      api_key_configured: !!this.apiKey,
      model: this.model ? 'gemini-pro' : null
    };
  }

  // Test service connectivity
  async testConnection() {
    if (!this.isAvailable()) {
      return {
        success: false,
        message: 'Service not initialized',
        details: 'Check GEMINI_API_KEY configuration'
      };
    }

    try {
      const testPrompt = 'Hello, please respond with "OK" if you can read this message.';
      const result = await this.model.generateContent(testPrompt);
      const response = await result.response;
      const text = response.text();
      
      if (text.toLowerCase().includes('ok')) {
        return {
          success: true,
          message: 'Gemini AI service is responding correctly',
          details: 'Test prompt processed successfully'
        };
      } else {
        return {
          success: false,
          message: 'Unexpected response from Gemini AI',
          details: `Expected "OK", got: ${text.substring(0, 100)}`
        };
      }
      
    } catch (error) {
      return {
        success: false,
        message: 'Gemini AI service test failed',
        details: error.message
      };
    }
  }
}

// Create singleton instance
const geminiService = new GeminiService();

module.exports = geminiService;
