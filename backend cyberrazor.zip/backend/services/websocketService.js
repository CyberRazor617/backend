const WebSocket = require('ws');
const { logger } = require('../config/logger');
const jwt = require('jsonwebtoken');

class WebSocketService {
  constructor(server) {
    this.wss = new WebSocket.Server({ 
      server,
      path: '/ws',
      verifyClient: this.verifyClient.bind(this)
    });
    
    this.clients = new Map(); // Map of user email to WebSocket connections
    this.rooms = new Map(); // Map of room names to Set of WebSocket connections
    
    this.setupEventHandlers();
    logger.info('WebSocket service initialized');
  }

  verifyClient(info) {
    try {
      const url = new URL(info.req.url, `http://${info.req.headers.host}`);
      const token = url.searchParams.get('token');
      
      if (!token) {
        logger.warn('WebSocket connection attempt without token');
        return false;
      }

      // Verify JWT token
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
      info.req.user = decoded;
      return true;
    } catch (error) {
      logger.warn(`WebSocket authentication failed: ${error.message}`);
      return false;
    }
  }

  setupEventHandlers() {
    this.wss.on('connection', (ws, req) => {
      const user = req.user;
      const userEmail = user.email;
      
      logger.info(`WebSocket connection established for user: ${userEmail}`);
      
      // Store client connection
      if (!this.clients.has(userEmail)) {
        this.clients.set(userEmail, new Set());
      }
      this.clients.get(userEmail).add(ws);
      
      // Join user to their personal room
      this.joinRoom(ws, `user:${userEmail}`);
      
      // Join admin users to admin room
      if (user.is_admin) {
        this.joinRoom(ws, 'admin');
      }
      
      // Send welcome message
      this.sendToClient(ws, {
        type: 'connection_established',
        message: 'Connected to CyberRazor real-time updates',
        timestamp: new Date().toISOString()
      });

      ws.on('message', (message) => {
        try {
          const data = JSON.parse(message);
          this.handleMessage(ws, data, user);
        } catch (error) {
          logger.error(`Error parsing WebSocket message: ${error.message}`);
          this.sendToClient(ws, {
            type: 'error',
            message: 'Invalid message format',
            timestamp: new Date().toISOString()
          });
        }
      });

      ws.on('close', () => {
        logger.info(`WebSocket connection closed for user: ${userEmail}`);
        this.removeClient(ws, userEmail);
      });

      ws.on('error', (error) => {
        logger.error(`WebSocket error for user ${userEmail}: ${error.message}`);
        this.removeClient(ws, userEmail);
      });
    });
  }

  handleMessage(ws, data, user) {
    const { type, payload } = data;
    
    switch (type) {
      case 'ping':
        this.sendToClient(ws, { type: 'pong', timestamp: new Date().toISOString() });
        break;
        
      case 'join_room':
        if (payload.room) {
          this.joinRoom(ws, payload.room);
        }
        break;
        
      case 'leave_room':
        if (payload.room) {
          this.leaveRoom(ws, payload.room);
        }
        break;
        
      case 'subscribe_logs':
        this.joinRoom(ws, 'logs');
        this.sendToClient(ws, {
          type: 'subscription_confirmed',
          message: 'Subscribed to real-time logs',
          timestamp: new Date().toISOString()
        });
        break;
        
      case 'unsubscribe_logs':
        this.leaveRoom(ws, 'logs');
        this.sendToClient(ws, {
          type: 'unsubscription_confirmed',
          message: 'Unsubscribed from real-time logs',
          timestamp: new Date().toISOString()
        });
        break;
        
      default:
        logger.warn(`Unknown WebSocket message type: ${type}`);
    }
  }

  joinRoom(ws, roomName) {
    if (!this.rooms.has(roomName)) {
      this.rooms.set(roomName, new Set());
    }
    this.rooms.get(roomName).add(ws);
    ws.currentRooms = ws.currentRooms || new Set();
    ws.currentRooms.add(roomName);
  }

  leaveRoom(ws, roomName) {
    if (this.rooms.has(roomName)) {
      this.rooms.get(roomName).delete(ws);
      if (this.rooms.get(roomName).size === 0) {
        this.rooms.delete(roomName);
      }
    }
    if (ws.currentRooms) {
      ws.currentRooms.delete(roomName);
    }
  }

  removeClient(ws, userEmail) {
    // Remove from user's client set
    if (this.clients.has(userEmail)) {
      this.clients.get(userEmail).delete(ws);
      if (this.clients.get(userEmail).size === 0) {
        this.clients.delete(userEmail);
      }
    }
    
    // Remove from all rooms
    if (ws.currentRooms) {
      ws.currentRooms.forEach(roomName => {
        this.leaveRoom(ws, roomName);
      });
    }
  }

  sendToClient(ws, data) {
    if (ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify(data));
      } catch (error) {
        logger.error(`Error sending WebSocket message: ${error.message}`);
      }
    }
  }

  sendToUser(userEmail, data) {
    if (this.clients.has(userEmail)) {
      this.clients.get(userEmail).forEach(ws => {
        this.sendToClient(ws, data);
      });
    }
  }

  sendToRoom(roomName, data) {
    if (this.rooms.has(roomName)) {
      this.rooms.get(roomName).forEach(ws => {
        this.sendToClient(ws, data);
      });
    }
  }

  broadcastToAll(data) {
    this.wss.clients.forEach(ws => {
      this.sendToClient(ws, data);
    });
  }

  // Log broadcasting methods
  broadcastScanLog(logData) {
    const message = {
      type: 'scan_log',
      data: logData,
      timestamp: new Date().toISOString()
    };
    
    // Send to specific user
    if (logData.user_email) {
      this.sendToUser(logData.user_email, message);
    }
    
    // Send to logs room (all subscribers)
    this.sendToRoom('logs', message);
    
    // Send to admin room
    this.sendToRoom('admin', message);
  }

  broadcastNetworkLog(logData) {
    const message = {
      type: 'network_log',
      data: logData,
      timestamp: new Date().toISOString()
    };
    
    // Send to specific user
    if (logData.user_email) {
      this.sendToUser(logData.user_email, message);
    }
    
    // Send to logs room (all subscribers)
    this.sendToRoom('logs', message);
    
    // Send to admin room
    this.sendToRoom('admin', message);
  }

  broadcastCIAAuditLog(logData) {
    const message = {
      type: 'cia_audit_log',
      data: logData,
      timestamp: new Date().toISOString()
    };
    
    // Send to specific user
    if (logData.user_email) {
      this.sendToUser(logData.user_email, message);
    }
    
    // Send to logs room (all subscribers)
    this.sendToRoom('logs', message);
    
    // Send to admin room
    this.sendToRoom('admin', message);
  }

  broadcastAgentLog(logData) {
    const message = {
      type: 'agent_log',
      data: logData,
      timestamp: new Date().toISOString()
    };
    
    // Send to specific user
    if (logData.user_email) {
      this.sendToUser(logData.user_email, message);
    }
    
    // Send to logs room (all subscribers)
    this.sendToRoom('logs', message);
    
    // Send to admin room
    this.sendToRoom('admin', message);
  }

  broadcastThreatAlert(threatData) {
    const message = {
      type: 'threat_alert',
      data: threatData,
      timestamp: new Date().toISOString()
    };
    
    // Send to specific user
    if (threatData.user_email) {
      this.sendToUser(threatData.user_email, message);
    }
    
    // Send to admin room
    this.sendToRoom('admin', message);
    
    // Send to all users for critical threats
    if (threatData.severity === 'critical') {
      this.broadcastToAll(message);
    }
  }

  broadcastSystemAlert(alertData) {
    const message = {
      type: 'system_alert',
      data: alertData,
      timestamp: new Date().toISOString()
    };
    
    // Send to admin room
    this.sendToRoom('admin', message);
    
    // Send to all users for critical system alerts
    if (alertData.severity === 'critical') {
      this.broadcastToAll(message);
    }
  }

  broadcastActivityUpdate(activityData) {
    const message = {
      type: 'activity_update',
      data: activityData,
      timestamp: new Date().toISOString()
    };
    
    // Send to admin room for all activities
    this.sendToRoom('admin', message);
    
    // Send to superadmin room for admin management activities
    if (['admin_created', 'admin_updated', 'admin_deleted', 'admin_status_toggled'].includes(activityData.type)) {
      this.sendToRoom('superadmin', message);
    }
    
    // Send to specific user if it's their activity
    if (activityData.performedByEmail && activityData.performedByEmail !== 'system') {
      this.sendToUser(activityData.performedByEmail, message);
    }
  }

  // User approval/rejection notifications
  broadcastUserApproval(userData, adminEmail) {
    const message = {
      type: 'user_approved',
      data: {
        user: userData,
        approved_by: adminEmail,
        timestamp: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    };
    
    // Send to the approved user
    this.sendToUser(userData.email, message);
    
    // Send to admin room for admin dashboard updates
    this.sendToRoom('admin', message);
    
    // Send to superadmin room
    this.sendToRoom('superadmin', message);
  }

  broadcastUserRejection(userData, adminEmail, rejectionReason) {
    const message = {
      type: 'user_rejected',
      data: {
        user: userData,
        rejected_by: adminEmail,
        rejection_reason: rejectionReason,
        timestamp: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    };
    
    // Send to the rejected user
    this.sendToUser(userData.email, message);
    
    // Send to admin room for admin dashboard updates
    this.sendToRoom('admin', message);
    
    // Send to superadmin room
    this.sendToRoom('superadmin', message);
  }

  broadcastPendingUserUpdate(userData) {
    const message = {
      type: 'pending_user_update',
      data: {
        user: userData,
        timestamp: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    };
    
    // Send to admin room for real-time pending users list updates
    this.sendToRoom('admin', message);
    
    // Send to superadmin room
    this.sendToRoom('superadmin', message);
  }

  broadcastAlertToUser(userId, alertData) {
    const message = {
      type: 'realtime_alert',
      data: alertData,
      timestamp: new Date().toISOString()
    };
    
    // Find user by ID and send alert
    this.clients.forEach((connections, userEmail) => {
      // For now, we'll use email as identifier since we have that in the WebSocket
      // In a full implementation, you'd want to store user ID mapping
      connections.forEach(ws => {
        this.sendToClient(ws, message);
      });
    });
    
    // Also send to admin room for monitoring
    this.sendToRoom('admin', message);
  }

  getStats() {
    return {
      totalConnections: this.wss.clients.size,
      totalUsers: this.clients.size,
      totalRooms: this.rooms.size,
      roomStats: Array.from(this.rooms.entries()).map(([name, clients]) => ({
        room: name,
        connections: clients.size
      }))
    };
  }
}

module.exports = WebSocketService;
