const mongoose = require('mongoose');

const ActivitySchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    enum: [
      'admin_created',
      'admin_updated', 
      'admin_deleted',
      'admin_status_toggled',
      'bug_created',
      'bug_updated',
      'bug_deleted',
      'bug_assigned',
      'bug_resolved',
      'user_registered',
      'user_approved',
      'user_rejected',
      'user_deleted',
      'system_alert',
      'threat_detected',
      'scan_completed',
      'login_success',
      'login_failed',
      'password_changed',
      'settings_updated'
    ]
  },
  action: {
    type: String,
    required: true,
    maxlength: [200, 'Action description cannot exceed 200 characters']
  },
  description: {
    type: String,
    maxlength: [500, 'Description cannot exceed 500 characters']
  },
  performedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  performedByEmail: {
    type: String,
    required: true
  },
  targetId: {
    type: mongoose.Schema.Types.ObjectId,
    required: false
  },
  targetType: {
    type: String,
    enum: ['user', 'admin', 'bug', 'system', 'threat', 'scan'],
    required: false
  },
  targetName: {
    type: String,
    maxlength: [100, 'Target name cannot exceed 100 characters']
  },
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium'
  },
  category: {
    type: String,
    enum: ['user_management', 'bug_management', 'system', 'security', 'authentication'],
    required: true
  },
  ipAddress: {
    type: String,
    required: false
  },
  userAgent: {
    type: String,
    required: false
  },
  timestamp: {
    type: Date,
    default: Date.now,
    required: true
  }
}, {
  timestamps: true
});

// Indexes for better query performance
ActivitySchema.index({ type: 1 });
ActivitySchema.index({ performedBy: 1 });
ActivitySchema.index({ targetId: 1 });
ActivitySchema.index({ category: 1 });
ActivitySchema.index({ severity: 1 });
ActivitySchema.index({ timestamp: -1 });
ActivitySchema.index({ performedByEmail: 1 });

// Compound indexes for common queries
ActivitySchema.index({ category: 1, timestamp: -1 });
ActivitySchema.index({ type: 1, timestamp: -1 });
ActivitySchema.index({ severity: 1, timestamp: -1 });

// Static method to create activity
ActivitySchema.statics.createActivity = function(activityData) {
  return this.create(activityData);
};

// Static method to get recent activities
ActivitySchema.statics.getRecentActivities = function(limit = 50, category = null, type = null) {
  const filter = {};
  if (category) filter.category = category;
  if (type) filter.type = type;
  
  return this.find(filter)
    .populate('performedBy', 'username email role')
    .sort({ timestamp: -1 })
    .limit(limit);
};

// Static method to get activities by user
ActivitySchema.statics.getActivitiesByUser = function(userId, limit = 50) {
  return this.find({ performedBy: userId })
    .populate('performedBy', 'username email role')
    .sort({ timestamp: -1 })
    .limit(limit);
};

// Static method to get activities by target
ActivitySchema.statics.getActivitiesByTarget = function(targetId, targetType, limit = 50) {
  return this.find({ targetId, targetType })
    .populate('performedBy', 'username email role')
    .sort({ timestamp: -1 })
    .limit(limit);
};

// Static method to get activity statistics
ActivitySchema.statics.getActivityStats = function(timeframe = '24h') {
  let startDate;
  const now = new Date();
  
  switch (timeframe) {
    case '1h':
      startDate = new Date(now.getTime() - 60 * 60 * 1000);
      break;
    case '24h':
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      break;
    case '7d':
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      break;
    case '30d':
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      break;
    default:
      startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  }

  return this.aggregate([
    {
      $match: {
        timestamp: { $gte: startDate }
      }
    },
    {
      $group: {
        _id: '$type',
        count: { $sum: 1 },
        lastActivity: { $max: '$timestamp' }
      }
    },
    {
      $sort: { count: -1 }
    }
  ]);
};

// Static method to get activity trends
ActivitySchema.statics.getActivityTrends = function(days = 7) {
  const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  
  return this.aggregate([
    {
      $match: {
        timestamp: { $gte: startDate }
      }
    },
    {
      $group: {
        _id: {
          date: { $dateToString: { format: '%Y-%m-%d', date: '$timestamp' } },
          type: '$type'
        },
        count: { $sum: 1 }
      }
    },
    {
      $group: {
        _id: '$_id.date',
        activities: {
          $push: {
            type: '$_id.type',
            count: '$count'
          }
        },
        total: { $sum: '$count' }
      }
    },
    {
      $sort: { '_id': 1 }
    }
  ]);
};

// Instance method to format for display
ActivitySchema.methods.formatForDisplay = function() {
  return {
    id: this._id,
    type: this.type,
    action: this.action,
    description: this.description,
    performedBy: this.performedBy,
    performedByEmail: this.performedByEmail,
    targetId: this.targetId,
    targetType: this.targetType,
    targetName: this.targetName,
    severity: this.severity,
    category: this.category,
    timestamp: this.timestamp,
    timeAgo: this.getTimeAgo(),
    metadata: this.metadata
  };
};

// Instance method to get time ago string
ActivitySchema.methods.getTimeAgo = function() {
  const now = new Date();
  const diff = now - this.timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) {
    return `${days} day${days > 1 ? 's' : ''} ago`;
  } else if (hours > 0) {
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  } else if (minutes > 0) {
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  } else {
    return 'Just now';
  }
};

module.exports = mongoose.model('Activity', ActivitySchema);
