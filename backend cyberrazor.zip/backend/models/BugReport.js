const mongoose = require('mongoose');

const BugReportSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true,
    maxlength: [200, 'Title cannot exceed 200 characters']
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    trim: true,
    maxlength: [2000, 'Description cannot exceed 2000 characters']
  },
  status: {
    type: String,
    enum: ['open', 'in-progress', 'resolved', 'closed'],
    default: 'open',
    required: true
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'medium',
    required: true
  },
  reportedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'Reported by is required']
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: false
  },
  tags: [{
    type: String,
    trim: true,
    lowercase: true
  }]
}, {
  timestamps: true
});

// Indexes for better query performance
BugReportSchema.index({ status: 1 });
BugReportSchema.index({ priority: 1 });
BugReportSchema.index({ reportedBy: 1 });
BugReportSchema.index({ assignedTo: 1 });
BugReportSchema.index({ createdAt: -1 });
BugReportSchema.index({ tags: 1 });

// Static method to find bugs by status
BugReportSchema.statics.findByStatus = function(status) {
  return this.find({ status });
};

// Static method to find bugs by priority
BugReportSchema.statics.findByPriority = function(priority) {
  return this.find({ priority });
};

// Static method to find bugs assigned to a user
BugReportSchema.statics.findAssignedTo = function(userId) {
  return this.find({ assignedTo: userId });
};

// Static method to get bug statistics
BugReportSchema.statics.getStats = function() {
  return this.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);
};

module.exports = mongoose.model('BugReport', BugReportSchema);
