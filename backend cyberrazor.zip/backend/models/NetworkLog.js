const mongoose = require('mongoose');

const networkLogSchema = new mongoose.Schema({
  user_email: {
    type: String,
    required: [true, 'User email is required'],
    index: true
  },
  device_id: {
    type: String,
    required: [true, 'Device ID is required'],
    index: true
  },
  event_type: {
    type: String,
    required: [true, 'Event type is required'],
    enum: ['connection', 'disconnection', 'suspicious_activity', 'port_scan', 'data_transfer', 'protocol_analysis']
  },
  source_ip: {
    type: String,
    required: [true, 'Source IP is required']
  },
  destination_ip: {
    type: String,
    required: [true, 'Destination IP is required']
  },
  source_port: {
    type: Number,
    required: [true, 'Source port is required']
  },
  destination_port: {
    type: Number,
    required: [true, 'Destination port is required']
  },
  protocol: {
    type: String,
    required: [true, 'Protocol is required'],
    enum: ['TCP', 'UDP', 'ICMP', 'HTTP', 'HTTPS', 'FTP', 'SSH', 'DNS', 'SMTP', 'OTHER']
  },
  connection_status: {
    type: String,
    enum: ['established', 'listening', 'time_wait', 'close_wait', 'syn_sent', 'syn_received', 'fin_wait'],
    default: 'established'
  },
  data_size: {
    type: Number,
    default: 0
  },
  duration: {
    type: Number,
    default: 0
  },
  threat_level: {
    type: String,
    enum: ['none', 'low', 'medium', 'high', 'critical'],
    default: 'none'
  },
  is_suspicious: {
    type: Boolean,
    default: false
  },
  suspicious_reason: {
    type: String,
    default: null
  },
  action_taken: {
    type: String,
    enum: ['allowed', 'blocked', 'monitored', 'quarantined', 'logged'],
    default: 'logged'
  },
  user_response: {
    type: String,
    enum: ['allow', 'block', 'ignore', 'investigate'],
    default: null
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  extra_data: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  created_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for connection age
networkLogSchema.virtual('age').get(function() {
  return Date.now() - this.timestamp.getTime();
});

// Virtual for is threat
networkLogSchema.virtual('isThreat').get(function() {
  return this.is_suspicious || this.threat_level !== 'none';
});

// Pre-save middleware to update timestamp
networkLogSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

// Static method to find by user
networkLogSchema.statics.findByUser = function(userEmail) {
  return this.find({ user_email: userEmail }).sort({ timestamp: -1 });
};

// Static method to find by device
networkLogSchema.statics.findByDevice = function(deviceId) {
  return this.find({ device_id: deviceId }).sort({ timestamp: -1 });
};

// Static method to find suspicious activity
networkLogSchema.statics.findSuspicious = function(userEmail = null) {
  const query = { is_suspicious: true };
  if (userEmail) query.user_email = userEmail;
  return this.find(query).sort({ timestamp: -1 });
};

// Static method to get network statistics
networkLogSchema.statics.getStatistics = async function(userEmail = null) {
  const query = userEmail ? { user_email: userEmail } : {};
  
  const stats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: null,
        total: { $sum: 1 },
        byEventType: {
          $push: {
            type: '$event_type',
            count: 1
          }
        },
        byProtocol: {
          $push: {
            protocol: '$protocol',
            count: 1
          }
        },
        byThreatLevel: {
          $push: {
            level: '$threat_level',
            count: 1
          }
        },
        suspiciousCount: {
          $sum: {
            $cond: ['$is_suspicious', 1, 0]
          }
        },
        totalDataTransferred: {
          $sum: '$data_size'
        },
        averageDuration: {
          $avg: '$duration'
        },
        uniqueConnections: {
          $addToSet: {
            $concat: ['$source_ip', ':', { $toString: '$source_port' }, '->', '$destination_ip', ':', { $toString: '$destination_port' }]
          }
        }
      }
    }
  ]);

  if (stats.length === 0) {
    return {
      total: 0,
      byEventType: {},
      byProtocol: {},
      byThreatLevel: {},
      suspiciousCount: 0,
      totalDataTransferred: 0,
      averageDuration: 0,
      uniqueConnections: 0
    };
  }

  const result = stats[0];
  
  // Process event type counts
  const eventTypeCounts = {};
  result.byEventType.forEach(item => {
    eventTypeCounts[item.type] = (eventTypeCounts[item.type] || 0) + item.count;
  });

  // Process protocol counts
  const protocolCounts = {};
  result.byProtocol.forEach(item => {
    protocolCounts[item.protocol] = (protocolCounts[item.protocol] || 0) + item.count;
  });

  // Process threat level counts
  const threatLevelCounts = {};
  result.byThreatLevel.forEach(item => {
    threatLevelCounts[item.level] = (threatLevelCounts[item.level] || 0) + item.count;
  });

  return {
    total: result.total,
    byEventType: eventTypeCounts,
    byProtocol: protocolCounts,
    byThreatLevel: threatLevelCounts,
    suspiciousCount: result.suspiciousCount,
    totalDataTransferred: result.totalDataTransferred,
    averageDuration: Math.round(result.averageDuration || 0),
    uniqueConnections: result.uniqueConnections.length
  };
};

// Indexes
networkLogSchema.index({ user_email: 1, timestamp: -1 });
networkLogSchema.index({ device_id: 1, timestamp: -1 });
networkLogSchema.index({ event_type: 1, timestamp: -1 });
networkLogSchema.index({ is_suspicious: 1 });
networkLogSchema.index({ threat_level: 1 });
networkLogSchema.index({ protocol: 1 });
networkLogSchema.index({ timestamp: -1 });

module.exports = mongoose.model('NetworkLog', networkLogSchema);
