const mongoose = require('mongoose');

const threatSchema = new mongoose.Schema({
  device_id: {
    type: String,
    required: [true, 'Device ID is required'],
    index: true
  },
  file_path: {
    type: String,
    required: [true, 'File path is required']
  },
  threat_type: {
    type: String,
    required: [true, 'Threat type is required'],
    enum: ['malware', 'suspicious', 'phishing', 'ransomware', 'trojan', 'backdoor', 'keylogger', 'other']
  },
  confidence_score: {
    type: Number,
    required: [true, 'Confidence score is required'],
    min: [0, 'Confidence score must be at least 0'],
    max: [1, 'Confidence score cannot exceed 1']
  },
  source: {
    type: String,
    required: [true, 'Source is required'],
    enum: ['ai_analysis', 'signature_based', 'behavior_analysis', 'user_report', 'wazuh', 'other']
  },
  details: {
    type: mongoose.Schema.Types.Mixed,
    required: [true, 'Threat details are required']
  },
  action_taken: {
    type: String,
    required: [true, 'Action taken is required'],
    enum: ['blocked', 'quarantined', 'monitored', 'ignored', 'investigating', 'remove', 'approve']
  },
  severity: {
    type: String,
    required: [true, 'Severity is required'],
    enum: ['low', 'medium', 'high', 'critical']
  },
  status: {
    type: String,
    required: [true, 'Status is required'],
    enum: ['new', 'investigating', 'resolved', 'false_positive', 'closed', 'removed', 'quarantined', 'approved'],
    default: 'new'
  },
  ai_verdict: {
    type: String,
    enum: ['Safe', 'Suspicious', 'Threat Detected', 'Unknown']
  },
  ai_confidence: {
    type: String,
    pattern: /^\d+%$/
  },
  ai_reason: {
    type: String
  },
  wazuh_alert: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  user_email: {
    type: String,
    required: [true, 'User email is required'],
    index: true
  },
  created_at: {
    type: Date,
    default: Date.now,
    index: true
  },
  updated_at: {
    type: Date,
    default: Date.now
  },
  resolved_at: {
    type: Date,
    default: null
  },
  resolved_by: {
    type: String,
    default: null
  },
  notes: {
    type: String,
    default: ''
  },
  tags: [{
    type: String,
    trim: true
  }]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for threat age
threatSchema.virtual('age').get(function() {
  return Date.now() - this.created_at.getTime();
});

// Virtual for is resolved
threatSchema.virtual('isResolved').get(function() {
  return this.status === 'resolved' || this.status === 'closed';
});

// Pre-save middleware to update timestamp
threatSchema.pre('save', function(next) {
  this.updated_at = new Date();
  
  // Set resolved_at if status is resolved or closed
  if ((this.status === 'resolved' || this.status === 'closed') && !this.resolved_at) {
    this.resolved_at = new Date();
  }
  
  next();
});

// Static method to find by severity
threatSchema.statics.findBySeverity = function(severity) {
  return this.find({ severity: severity.toLowerCase() });
};

// Static method to find by status
threatSchema.statics.findByStatus = function(status) {
  return this.find({ status: status.toLowerCase() });
};

// Static method to find by device
threatSchema.statics.findByDevice = function(deviceId) {
  return this.find({ device_id: deviceId });
};

// Static method to find by user
threatSchema.statics.findByUser = function(userEmail) {
  return this.find({ user_email: userEmail });
};

// Static method to get threat statistics
threatSchema.statics.getStatistics = async function(query = {}) {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
  // Get all threats matching the query
  const allThreats = await this.find(query);
  const total_threats = allThreats.length;
  
  // Count threats created today
  const threats_today = await this.countDocuments({
    ...query,
    created_at: { $gte: startOfDay }
  });
  
  // Count resolved threats (resolved or closed status)
  const resolved_threats = await this.countDocuments({
    ...query,
    status: { $in: ['resolved', 'closed'] }
  });
  
  // Count active threats (new, investigating status)
  const active_threats = await this.countDocuments({
    ...query,
    status: { $in: ['new', 'investigating'] }
  });
  
  // Get severity breakdown
  const severityStats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: '$severity',
        count: { $sum: 1 }
      }
    }
  ]);
  
  const bySeverity = {};
  severityStats.forEach(item => {
    bySeverity[item._id] = item.count;
  });
  
  // Get status breakdown
  const statusStats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);
  
  const byStatus = {};
  statusStats.forEach(item => {
    byStatus[item._id] = item.count;
  });
  
  // Get type breakdown
  const typeStats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: '$threat_type',
        count: { $sum: 1 }
      }
    }
  ]);
  
  const byType = {};
  typeStats.forEach(item => {
    byType[item._id] = item.count;
  });

  return {
    // Mobile app expected format
    total_threats,
    threats_today,
    resolved_threats,
    active_threats,
    // Additional detailed breakdown
    total: total_threats,
    bySeverity,
    byStatus,
    byType
  };
};

// Indexes
threatSchema.index({ device_id: 1 });
threatSchema.index({ user_email: 1 });
threatSchema.index({ created_at: -1 });
threatSchema.index({ severity: 1 });
threatSchema.index({ status: 1 });
threatSchema.index({ threat_type: 1 });

module.exports = mongoose.model('Threat', threatSchema);
