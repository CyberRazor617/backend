const mongoose = require('mongoose');

const scanLogSchema = new mongoose.Schema({
  user_email: {
    type: String,
    required: [true, 'User email is required'],
    index: true
  },
  device_id: {
    type: String,
    required: [true, 'Device ID is required'],
    index: true
  },
  scan_type: {
    type: String,
    required: [true, 'Scan type is required'],
    enum: ['file_scan', 'network_scan', 'cia_audit', 'system_monitor', 'threat_detection']
  },
  scan_id: {
    type: String,
    required: [true, 'Scan ID is required'],
    index: true
  },
  file_path: {
    type: String,
    default: null
  },
  file_name: {
    type: String,
    default: null
  },
  file_hash: {
    type: String,
    default: null
  },
  file_size: {
    type: Number,
    default: null
  },
  scan_result: {
    type: String,
    required: [true, 'Scan result is required'],
    enum: ['clean', 'suspicious', 'threat', 'error', 'skipped']
  },
  threat_level: {
    type: String,
    enum: ['none', 'low', 'medium', 'high', 'critical'],
    default: 'none'
  },
  ai_verdict: {
    type: String,
    default: null
  },
  ai_confidence: {
    type: String,
    default: null
  },
  ai_reason: {
    type: String,
    default: null
  },
  scan_duration: {
    type: Number,
    default: 0
  },
  scan_timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  extra_data: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  source: {
    type: String,
    enum: ['freetier', 'pro', 'enterprise', 'manual', 'scheduled'],
    default: 'freetier'
  },
  status: {
    type: String,
    enum: ['completed', 'failed', 'in_progress', 'cancelled'],
    default: 'completed'
  },
  created_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for scan age
scanLogSchema.virtual('age').get(function() {
  return Date.now() - this.scan_timestamp.getTime();
});

// Virtual for is threat
scanLogSchema.virtual('isThreat').get(function() {
  return this.scan_result === 'threat' || this.scan_result === 'suspicious';
});

// Pre-save middleware to update timestamp
scanLogSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

// Static method to find by user
scanLogSchema.statics.findByUser = function(userEmail) {
  return this.find({ user_email: userEmail }).sort({ scan_timestamp: -1 });
};

// Static method to find by scan type
scanLogSchema.statics.findByScanType = function(scanType) {
  return this.find({ scan_type: scanType }).sort({ scan_timestamp: -1 });
};

// Static method to find by device
scanLogSchema.statics.findByDevice = function(deviceId) {
  return this.find({ device_id: deviceId }).sort({ scan_timestamp: -1 });
};

// Static method to get scan statistics
scanLogSchema.statics.getStatistics = async function(userEmail = null) {
  const query = userEmail ? { user_email: userEmail } : {};
  
  const stats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: null,
        total: { $sum: 1 },
        byScanType: {
          $push: {
            type: '$scan_type',
            count: 1
          }
        },
        byResult: {
          $push: {
            result: '$scan_result',
            count: 1
          }
        },
        byThreatLevel: {
          $push: {
            level: '$threat_level',
            count: 1
          }
        },
        totalThreats: {
          $sum: {
            $cond: [
              { $in: ['$scan_result', ['threat', 'suspicious']] },
              1,
              0
            ]
          }
        },
        totalClean: {
          $sum: {
            $cond: [
              { $eq: ['$scan_result', 'clean'] },
              1,
              0
            ]
          }
        },
        averageScanTime: {
          $avg: '$scan_duration'
        }
      }
    }
  ]);

  if (stats.length === 0) {
    return {
      total: 0,
      byScanType: {},
      byResult: {},
      byThreatLevel: {},
      totalThreats: 0,
      totalClean: 0,
      averageScanTime: 0
    };
  }

  const result = stats[0];
  
  // Process scan type counts
  const scanTypeCounts = {};
  result.byScanType.forEach(item => {
    scanTypeCounts[item.type] = (scanTypeCounts[item.type] || 0) + item.count;
  });

  // Process result counts
  const resultCounts = {};
  result.byResult.forEach(item => {
    resultCounts[item.result] = (resultCounts[item.result] || 0) + item.count;
  });

  // Process threat level counts
  const threatLevelCounts = {};
  result.byThreatLevel.forEach(item => {
    threatLevelCounts[item.level] = (threatLevelCounts[item.level] || 0) + item.count;
  });

  return {
    total: result.total,
    byScanType: scanTypeCounts,
    byResult: resultCounts,
    byThreatLevel: threatLevelCounts,
    totalThreats: result.totalThreats,
    totalClean: result.totalClean,
    averageScanTime: Math.round(result.averageScanTime || 0)
  };
};

// Indexes
scanLogSchema.index({ user_email: 1, scan_timestamp: -1 });
scanLogSchema.index({ device_id: 1, scan_timestamp: -1 });
scanLogSchema.index({ scan_type: 1, scan_timestamp: -1 });
scanLogSchema.index({ scan_result: 1 });
scanLogSchema.index({ threat_level: 1 });
scanLogSchema.index({ scan_timestamp: -1 });

module.exports = mongoose.model('ScanLog', scanLogSchema);
