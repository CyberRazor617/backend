const mongoose = require('mongoose');

const ciaAuditLogSchema = new mongoose.Schema({
  user_email: {
    type: String,
    required: [true, 'User email is required'],
    index: true
  },
  device_id: {
    type: String,
    required: [true, 'Device ID is required'],
    index: true
  },
  audit_type: {
    type: String,
    required: [true, 'Audit type is required'],
    enum: ['confidentiality', 'integrity', 'availability', 'full_audit']
  },
  audit_id: {
    type: String,
    required: [true, 'Audit ID is required'],
    index: true
  },
  overall_score: {
    type: Number,
    required: [true, 'Overall score is required'],
    min: [0, 'Score must be at least 0'],
    max: [100, 'Score cannot exceed 100']
  },
  confidentiality_score: {
    type: Number,
    min: [0, 'Score must be at least 0'],
    max: [100, 'Score cannot exceed 100'],
    default: 0
  },
  integrity_score: {
    type: Number,
    min: [0, 'Score must be at least 0'],
    max: [100, 'Score cannot exceed 100'],
    default: 0
  },
  availability_score: {
    type: Number,
    min: [0, 'Score must be at least 0'],
    max: [100, 'Score cannot exceed 100'],
    default: 0
  },
  findings: [{
    category: {
      type: String,
      enum: ['confidentiality', 'integrity', 'availability'],
      required: true
    },
    finding_type: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    severity: {
      type: String,
      enum: ['low', 'medium', 'high', 'critical'],
      required: true
    },
    impact_score: {
      type: Number,
      min: [0, 'Impact score must be at least 0'],
      max: [10, 'Impact score cannot exceed 10'],
      required: true
    },
    recommendation: {
      type: String,
      required: true
    },
    status: {
      type: String,
      enum: ['open', 'in_progress', 'resolved', 'accepted_risk'],
      default: 'open'
    }
  }],
  system_info: {
    hostname: {
      type: String,
      default: null
    },
    os: {
      type: String,
      default: null
    },
    architecture: {
      type: String,
      default: null
    },
    cpu_usage: {
      type: Number,
      default: null
    },
    memory_usage: {
      type: Number,
      default: null
    },
    disk_usage: {
      type: Number,
      default: null
    }
  },
  audit_duration: {
    type: Number,
    default: 0
  },
  audit_timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  status: {
    type: String,
    enum: ['completed', 'failed', 'in_progress', 'cancelled'],
    default: 'completed'
  },
  extra_data: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  created_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for audit age
ciaAuditLogSchema.virtual('age').get(function() {
  return Date.now() - this.audit_timestamp.getTime();
});

// Virtual for risk level
ciaAuditLogSchema.virtual('riskLevel').get(function() {
  if (this.overall_score >= 80) return 'low';
  if (this.overall_score >= 60) return 'medium';
  if (this.overall_score >= 40) return 'high';
  return 'critical';
});

// Virtual for critical findings count
ciaAuditLogSchema.virtual('criticalFindingsCount').get(function() {
  return this.findings.filter(f => f.severity === 'critical').length;
});

// Virtual for high findings count
ciaAuditLogSchema.virtual('highFindingsCount').get(function() {
  return this.findings.filter(f => f.severity === 'high').length;
});

// Pre-save middleware to update timestamp
ciaAuditLogSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

// Static method to find by user
ciaAuditLogSchema.statics.findByUser = function(userEmail) {
  return this.find({ user_email: userEmail }).sort({ audit_timestamp: -1 });
};

// Static method to find by device
ciaAuditLogSchema.statics.findByDevice = function(deviceId) {
  return this.find({ device_id: deviceId }).sort({ audit_timestamp: -1 });
};

// Static method to find by audit type
ciaAuditLogSchema.statics.findByAuditType = function(auditType) {
  return this.find({ audit_type: auditType }).sort({ audit_timestamp: -1 });
};

// Static method to get CIA audit statistics
ciaAuditLogSchema.statics.getStatistics = async function(userEmail = null) {
  const query = userEmail ? { user_email: userEmail } : {};
  
  const stats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: null,
        total: { $sum: 1 },
        averageOverallScore: {
          $avg: '$overall_score'
        },
        averageConfidentialityScore: {
          $avg: '$confidentiality_score'
        },
        averageIntegrityScore: {
          $avg: '$integrity_score'
        },
        averageAvailabilityScore: {
          $avg: '$availability_score'
        },
        byAuditType: {
          $push: {
            type: '$audit_type',
            count: 1
          }
        },
        byRiskLevel: {
          $push: {
            $cond: [
              { $gte: ['$overall_score', 80] },
              'low',
              {
                $cond: [
                  { $gte: ['$overall_score', 60] },
                  'medium',
                  {
                    $cond: [
                      { $gte: ['$overall_score', 40] },
                      'high',
                      'critical'
                    ]
                  }
                ]
              }
            ],
            count: 1
          }
        },
        totalFindings: {
          $sum: { $size: '$findings' }
        },
        criticalFindings: {
          $sum: {
            $size: {
              $filter: {
                input: '$findings',
                cond: { $eq: ['$$this.severity', 'critical'] }
              }
            }
          }
        },
        highFindings: {
          $sum: {
            $size: {
              $filter: {
                input: '$findings',
                cond: { $eq: ['$$this.severity', 'high'] }
              }
            }
          }
        }
      }
    }
  ]);

  if (stats.length === 0) {
    return {
      total: 0,
      averageOverallScore: 0,
      averageConfidentialityScore: 0,
      averageIntegrityScore: 0,
      averageAvailabilityScore: 0,
      byAuditType: {},
      byRiskLevel: {},
      totalFindings: 0,
      criticalFindings: 0,
      highFindings: 0
    };
  }

  const result = stats[0];
  
  // Process audit type counts
  const auditTypeCounts = {};
  result.byAuditType.forEach(item => {
    auditTypeCounts[item.type] = (auditTypeCounts[item.type] || 0) + item.count;
  });

  // Process risk level counts
  const riskLevelCounts = {};
  result.byRiskLevel.forEach(item => {
    riskLevelCounts[item] = (riskLevelCounts[item] || 0) + 1;
  });

  return {
    total: result.total,
    averageOverallScore: Math.round(result.averageOverallScore || 0),
    averageConfidentialityScore: Math.round(result.averageConfidentialityScore || 0),
    averageIntegrityScore: Math.round(result.averageIntegrityScore || 0),
    averageAvailabilityScore: Math.round(result.averageAvailabilityScore || 0),
    byAuditType: auditTypeCounts,
    byRiskLevel: riskLevelCounts,
    totalFindings: result.totalFindings,
    criticalFindings: result.criticalFindings,
    highFindings: result.highFindings
  };
};

// Indexes
ciaAuditLogSchema.index({ user_email: 1, audit_timestamp: -1 });
ciaAuditLogSchema.index({ device_id: 1, audit_timestamp: -1 });
ciaAuditLogSchema.index({ audit_type: 1, audit_timestamp: -1 });
ciaAuditLogSchema.index({ overall_score: 1 });
ciaAuditLogSchema.index({ audit_timestamp: -1 });

module.exports = mongoose.model('CIAAuditLog', ciaAuditLogSchema);
