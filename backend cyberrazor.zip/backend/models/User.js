const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'Username is required'],
    trim: true,
    minlength: [3, 'Username must be at least 3 characters long'],
    maxlength: [50, 'Username cannot exceed 50 characters']
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [
      /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
      'Please enter a valid email address'
    ]
  },
  password_hash: {
    type: String,
    required: false, // Will be set by pre-save middleware
    minlength: [6, 'Password must be at least 6 characters long']
  },
  activation_key: {
    type: String,
    unique: true,
    required: true
  },
  role: {
    type: String,
    enum: ['user', 'admin', 'superadmin'],
    default: 'user'
  },
  is_admin: {
    type: Boolean,
    default: false
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: function() {
      return this.role === 'admin' && this.isNew;
    }
  },
  is_active: {
    type: Boolean,
    default: true
  },
  // New fields for approval system
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'active'],
    default: 'pending'
  },
  approved_by: {
    type: String,
    default: null
  },
  approved_at: {
    type: Date,
    default: null
  },
  rejected_by: {
    type: String,
    default: null
  },
  rejected_at: {
    type: Date,
    default: null
  },
  rejection_reason: {
    type: String,
    default: null
  },
  // Trial and subscription information
  trial_start_date: {
    type: Date,
    default: null
  },
  trial_end_date: {
    type: Date,
    default: null
  },
  subscription_plan: {
    type: String,
    enum: ['trial', 'free', 'pro', 'enterprise'],
    default: 'trial'
  },
  subscription_status: {
    type: String,
    enum: ['active', 'expired', 'cancelled'],
    default: 'active'
  },
  subscription_end_date: {
    type: Date,
    default: null
  },
  last_login: {
    type: Date,
    default: null
  },
  login_attempts: {
    type: Number,
    default: 0
  },
  lockout_until: {
    type: Date,
    default: null
  },
  // User preferences
  preferences: {
    dark_mode: {
      type: Boolean,
      default: true
    },
    notifications: {
      type: Boolean,
      default: true
    },
    auto_scan: {
      type: Boolean,
      default: true
    },
    two_factor_auth: {
      type: Boolean,
      default: false
    },
    email_notifications: {
      type: Boolean,
      default: true
    },
    push_notifications: {
      type: Boolean,
      default: true
    }
  },
  // Additional profile information
  profile: {
    full_name: {
      type: String,
      default: null
    },
    organization: {
      type: String,
      default: null
    },
    role: {
      type: String,
      default: 'SOC Analyst'
    },
    phone: {
      type: String,
      default: null
    },
    timezone: {
      type: String,
      default: 'UTC'
    }
  },
  created_at: {
    type: Date,
    default: Date.now
  },
  updated_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for password (not stored in DB)
userSchema.virtual('password')
  .set(function(password) {
    this._password = password;
  })
  .get(function() {
    return this._password;
  });

// Pre-save middleware to hash password
userSchema.pre('save', async function(next) {
  // Hash password when a new plain password has been provided on the model
  // We rely on the virtual setter which stores the plain text in `this._password`.
  // Avoid depending on Mongoose's `isModified('password')` for a virtual field.
  try {
    if (this._password) {
      const salt = await bcrypt.genSalt(parseInt(process.env.BCRYPT_ROUNDS) || 12);
      this.password_hash = await bcrypt.hash(this._password, salt);
      this._password = undefined;
      return next();
    }

    // If this is a new document and still has no password hash, that's an error
    if (this.isNew && !this.password_hash) {
      return next(new Error('Password is required for new users'));
    }

    return next();
  } catch (error) {
    return next(error);
  }
});

// Pre-save middleware to update timestamp
userSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

// Instance method to compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password_hash);
  } catch (error) {
    throw new Error('Password comparison failed');
  }
};

// Instance method to check if account is locked
userSchema.methods.isLocked = function() {
  return this.lockout_until && this.lockout_until > new Date();
};

// Instance method to increment login attempts
userSchema.methods.incrementLoginAttempts = function() {
  this.login_attempts += 1;
  
  // Lock account after 5 failed attempts for 15 minutes
  if (this.login_attempts >= 5) {
    this.lockout_until = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes
  }
  
  return this.save();
};

// Instance method to reset login attempts
userSchema.methods.resetLoginAttempts = function() {
  this.login_attempts = 0;
  this.lockout_until = null;
  this.last_login = new Date();
  return this.save();
};

// Instance method to approve user
userSchema.methods.approve = function(adminEmail) {
  this.status = 'approved';
  this.approved_by = adminEmail;
  this.approved_at = new Date();
  this.trial_start_date = new Date();
  this.trial_end_date = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
  this.subscription_plan = 'trial';
  this.subscription_status = 'active';
  return this.save();
};

// Instance method to reject user
userSchema.methods.reject = function(adminEmail, reason) {
  this.status = 'rejected';
  this.rejected_by = adminEmail;
  this.rejected_at = new Date();
  this.rejection_reason = reason;
  this.is_active = false;
  return this.save();
};

// Instance method to check if trial is active
userSchema.methods.isTrialActive = function() {
  if (this.subscription_plan !== 'trial') return false;
  return this.trial_end_date && this.trial_end_date > new Date();
};

// Instance method to transition to free tier
userSchema.methods.transitionToFreeTier = function() {
  if (this.subscription_plan === 'trial' && !this.isTrialActive()) {
    this.subscription_plan = 'free';
    this.subscription_status = 'active';
    return this.save();
  }
  return Promise.resolve(this);
};

// Static method to find by email
userSchema.statics.findByEmail = function(email) {
  return this.findOne({ email: email.toLowerCase() });
};

// Static method to create admin user
userSchema.statics.createAdmin = async function(adminData) {
  const admin = new this({
    ...adminData,
    role: 'admin',
    is_admin: true,
    is_active: true,
    status: 'approved'
  });
  
  return await admin.save();
};

// Static method to create superadmin user
userSchema.statics.createSuperAdmin = async function(superAdminData) {
  const superAdmin = new this({
    ...superAdminData,
    role: 'superadmin',
    is_admin: true,
    is_active: true,
    status: 'approved'
  });
  
  return await superAdmin.save();
};

// Static method to get pending users
userSchema.statics.getPendingUsers = function() {
  return this.find({ status: 'pending' }).sort({ created_at: -1 });
};

// Static method to get approved users
userSchema.statics.getApprovedUsers = function() {
  return this.find({ status: 'approved' }).sort({ approved_at: -1 });
};

// Instance method to update user preferences
userSchema.methods.updatePreferences = function(preferences) {
  if (preferences) {
    this.preferences = { ...this.preferences, ...preferences };
  }
  return this.save();
};

// Instance method to update user profile
userSchema.methods.updateProfile = function(profile) {
  if (profile) {
    this.profile = { ...this.profile, ...profile };
  }
  return this.save();
};

// Instance method to change password
// Instance method to change password
userSchema.methods.changePassword = async function(currentPassword, newPassword) {
  // Validate inputs early
  if (!currentPassword || !newPassword) {
    throw new Error('Current password and new password are required');
  }

  if (typeof newPassword !== 'string' || newPassword.length < 6) {
    throw new Error('New password must be at least 6 characters long');
  }

  const isValid = await this.comparePassword(currentPassword);
  if (!isValid) {
    throw new Error('Current password is incorrect');
  }

  // Use the internal _password field directly to ensure pre-save hashes it
  this._password = newPassword;

  // Reset login attempts on password change
  this.login_attempts = 0;
  this.lockout_until = null;

  await this.save();
  return true;
};

// Indexes - with explicit names to avoid conflicts
userSchema.index({ email: 1 }, { unique: true, name: 'email_unique' });
userSchema.index({ activation_key: 1 }, { unique: true, name: 'activation_key_unique' });
userSchema.index({ created_at: -1 }, { name: 'created_at_desc' });
userSchema.index({ status: 1 }, { name: 'status_asc' });
userSchema.index({ trial_end_date: 1 }, { name: 'trial_end_date_asc' });

module.exports = mongoose.model('User', userSchema);
