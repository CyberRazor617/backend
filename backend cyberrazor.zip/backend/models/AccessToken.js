const mongoose = require('mongoose');

const accessTokenSchema = new mongoose.Schema({
  token: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },
  isUsed: {
    type: Boolean,
    default: false
  },
  usedAt: {
    type: Date
  },
  usedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'ProUser'
  },
  subscriptionPlan: {
    type: String,
    enum: ['basic', 'pro', 'premium', 'enterprise'],
    required: true
  },
  subscriptionDuration: {
    type: Number, // in days
    required: true,
    default: 30
  },
  expiresAt: {
    type: Date,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index to automatically delete expired tokens after 90 days
accessTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 7776000 }); // 90 days

const AccessToken = mongoose.model('AccessToken', accessTokenSchema);

module.exports = AccessToken;
