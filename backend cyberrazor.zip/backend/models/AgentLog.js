const mongoose = require('mongoose');

const agentLogSchema = new mongoose.Schema({
  user_email: {
    type: String,
    required: [true, 'User email is required'],
    index: true
  },
  device_id: {
    type: String,
    required: [true, 'Device ID is required'],
    index: true
  },
  agent_version: {
    type: String,
    required: [true, 'Agent version is required']
  },
  log_level: {
    type: String,
    required: [true, 'Log level is required'],
    enum: ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
  },
  module: {
    type: String,
    required: [true, 'Module is required'],
    enum: ['file_scan', 'network_monitor', 'cia_audit', 'threat_detection', 'system_monitor', 'agent_core']
  },
  function: {
    type: String,
    required: [true, 'Function is required']
  },
  message: {
    type: String,
    required: [true, 'Message is required']
  },
  event_type: {
    type: String,
    required: [true, 'Event type is required'],
    enum: ['scan_start', 'scan_complete', 'threat_detected', 'network_event', 'audit_result', 'system_event', 'error', 'info']
  },
  file_path: {
    type: String,
    default: null
  },
  file_hash: {
    type: String,
    default: null
  },
  threat_type: {
    type: String,
    default: null
  },
  confidence_score: {
    type: Number,
    default: null
  },
  severity: {
    type: String,
    enum: ['low', 'medium', 'high', 'critical'],
    default: 'low'
  },
  action_taken: {
    type: String,
    enum: ['none', 'quarantined', 'deleted', 'allowed', 'monitored', 'blocked'],
    default: 'none'
  },
  user_response: {
    type: String,
    enum: ['allow', 'block', 'ignore', 'investigate'],
    default: null
  },
  scan_duration: {
    type: Number,
    default: 0
  },
  extra_data: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  },
  timestamp: {
    type: Date,
    default: Date.now,
    index: true
  },
  created_at: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for log age
agentLogSchema.virtual('age').get(function() {
  return Date.now() - this.timestamp.getTime();
});

// Virtual for is error
agentLogSchema.virtual('isError').get(function() {
  return this.log_level === 'ERROR' || this.log_level === 'CRITICAL';
});

// Virtual for is threat
agentLogSchema.virtual('isThreat').get(function() {
  return this.event_type === 'threat_detected' || this.severity === 'high' || this.severity === 'critical';
});

// Pre-save middleware to update timestamp
agentLogSchema.pre('save', function(next) {
  this.updated_at = new Date();
  next();
});

// Static method to find by user
agentLogSchema.statics.findByUser = function(userEmail) {
  return this.find({ user_email: userEmail }).sort({ timestamp: -1 });
};

// Static method to find by device
agentLogSchema.statics.findByDevice = function(deviceId) {
  return this.find({ device_id: deviceId }).sort({ timestamp: -1 });
};

// Static method to find by module
agentLogSchema.statics.findByModule = function(module) {
  return this.find({ module: module }).sort({ timestamp: -1 });
};

// Static method to find by event type
agentLogSchema.statics.findByEventType = function(eventType) {
  return this.find({ event_type: eventType }).sort({ timestamp: -1 });
};

// Static method to find errors
agentLogSchema.statics.findErrors = function(userEmail = null) {
  const query = { 
    log_level: { $in: ['ERROR', 'CRITICAL'] }
  };
  if (userEmail) query.user_email = userEmail;
  return this.find(query).sort({ timestamp: -1 });
};

// Static method to find threats
agentLogSchema.statics.findThreats = function(userEmail = null) {
  const query = { 
    event_type: 'threat_detected'
  };
  if (userEmail) query.user_email = userEmail;
  return this.find(query).sort({ timestamp: -1 });
};

// Static method to get agent log statistics
agentLogSchema.statics.getStatistics = async function(userEmail = null) {
  const query = userEmail ? { user_email: userEmail } : {};
  
  const stats = await this.aggregate([
    { $match: query },
    {
      $group: {
        _id: null,
        total: { $sum: 1 },
        byLogLevel: {
          $push: {
            level: '$log_level',
            count: 1
          }
        },
        byModule: {
          $push: {
            module: '$module',
            count: 1
          }
        },
        byEventType: {
          $push: {
            type: '$event_type',
            count: 1
          }
        },
        bySeverity: {
          $push: {
            severity: '$severity',
            count: 1
          }
        },
        errorCount: {
          $sum: {
            $cond: [
              { $in: ['$log_level', ['ERROR', 'CRITICAL']] },
              1,
              0
            ]
          }
        },
        threatCount: {
          $sum: {
            $cond: [
              { $eq: ['$event_type', 'threat_detected'] },
              1,
              0
            ]
          }
        },
        averageScanTime: {
          $avg: '$scan_duration'
        }
      }
    }
  ]);

  if (stats.length === 0) {
    return {
      total: 0,
      byLogLevel: {},
      byModule: {},
      byEventType: {},
      bySeverity: {},
      errorCount: 0,
      threatCount: 0,
      averageScanTime: 0
    };
  }

  const result = stats[0];
  
  // Process log level counts
  const logLevelCounts = {};
  result.byLogLevel.forEach(item => {
    logLevelCounts[item.level] = (logLevelCounts[item.level] || 0) + item.count;
  });

  // Process module counts
  const moduleCounts = {};
  result.byModule.forEach(item => {
    moduleCounts[item.module] = (moduleCounts[item.module] || 0) + item.count;
  });

  // Process event type counts
  const eventTypeCounts = {};
  result.byEventType.forEach(item => {
    eventTypeCounts[item.type] = (eventTypeCounts[item.type] || 0) + item.count;
  });

  // Process severity counts
  const severityCounts = {};
  result.bySeverity.forEach(item => {
    severityCounts[item.severity] = (severityCounts[item.severity] || 0) + item.count;
  });

  return {
    total: result.total,
    byLogLevel: logLevelCounts,
    byModule: moduleCounts,
    byEventType: eventTypeCounts,
    bySeverity: severityCounts,
    errorCount: result.errorCount,
    threatCount: result.threatCount,
    averageScanTime: Math.round(result.averageScanTime || 0)
  };
};

// Indexes
agentLogSchema.index({ user_email: 1, timestamp: -1 });
agentLogSchema.index({ device_id: 1, timestamp: -1 });
agentLogSchema.index({ module: 1, timestamp: -1 });
agentLogSchema.index({ event_type: 1, timestamp: -1 });
agentLogSchema.index({ log_level: 1 });
agentLogSchema.index({ severity: 1 });
agentLogSchema.index({ timestamp: -1 });

module.exports = mongoose.model('AgentLog', agentLogSchema);
