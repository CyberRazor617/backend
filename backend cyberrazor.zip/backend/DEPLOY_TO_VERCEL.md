# Deploy Backend to Vercel - Quick Guide

## Method 1: Using Vercel CLI (Recommended)

### Install Vercel CLI (if not installed)
```bash
npm install -g vercel
```

### Login to Vercel
```bash
vercel login
```

### Deploy from Backend Directory
```bash
cd H:\Development\CyberRazor\frontend\backend
vercel --prod
```

---

## Method 2: Using GitHub + Vercel (Best for Long-term)

### 1. Initialize Git Repository
```bash
cd H:\Development\CyberRazor\frontend\backend
git init
git add .
git commit -m "Add Stripe payment integration"
```

### 2. Create GitHub Repository
- Go to github.com
- Create new repository called "cyberrazor-backend"
- Don't initialize with README

### 3. Push to GitHub
```bash
git remote add origin https://github.com/YOUR_USERNAME/cyberrazor-backend.git
git branch -M main
git push -u origin main
```

### 4. Connect to Vercel
- Go to vercel.com/dashboard
- Click "Import Project"
- Select your GitHub repository
- Vercel will auto-deploy

---

## Method 3: Manual Redeploy (Quickest if already deployed)

1. Go to https://vercel.com/dashboard
2. Find your "cyberrazorbackend" project
3. Click on it
4. Go to **Settings** tab
5. Scroll to **Git** section
6. Click **"Redeploy"** or trigger a new deployment

---

## Required Environment Variables on Vercel

Make sure these are set in your Vercel project settings:

```env
# Database
MONGODB_URI=<your-mongodb-connection-string>

# JWT
JWT_SECRET=<your-jwt-secret>

# Stripe
STRIPE_PUBLISHABLE_KEY=pk_test_51QhxcRAtSFeuCmPAJW6zwkpg6sFPGFpU4i5W1RAijd7bUcKYoWAalsIx3xNn4WToyDxEYKmHNzSOsHb14PXH8k1U002Cj7ZQg3
STRIPE_SECRET_KEY=sk_test_51QhxcRAtSFeuCmPAxZ3SA2VPNcG2QSRKLOJpNOk3B2gSWdyqKvBx2Gge1SwNtUOWUNP0sbQgcCA5tnD3coyCKlVE00KVHOnvkX
STRIPE_WEBHOOK_SECRET=whsec_9bF0dycyhXxkCBI8wImUiIeQLgtJ9dgg
STRIPE_SUCCESS_URL=https://cyberrazor.vercel.app/payment-success
STRIPE_CANCEL_URL=https://cyberrazor.vercel.app/payment-cancelled

# SMTP (Gmail App Password)
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=cyberrazor0123@gmail.com
SMTP_PASSWORD=<your-gmail-app-password>

# Gemini API (if used)
GEMINI_API_KEY=<your-gemini-key>
```

---

## How to Get Gmail App Password

1. Go to https://myaccount.google.com/security
2. Enable **2-Step Verification** (if not already)
3. Search for "App passwords"
4. Click **App passwords**
5. Select **Mail** and **Other**
6. Name it "CyberRazor Backend"
7. Click **Generate**
8. Copy the 16-character password
9. Use this password in `SMTP_PASSWORD` environment variable

---

## After Deployment

1. Wait 2-3 minutes for deployment to complete
2. Check deployment logs for errors
3. Test the endpoints:
   - https://cyberrazorbackend.vercel.app/api/stripe/create-checkout-session
   - https://cyberrazorbackend.vercel.app/api/pro/check-token

4. Test payment flow:
   - Go to your website
   - Click "Upgrade to Pro"
   - Complete payment
   - Check email for access token

---

## Troubleshooting

**If deployment fails:**
- Check Vercel logs for errors
- Ensure all dependencies are in package.json
- Make sure vercel.json is configured correctly

**If emails don't send:**
- Verify SMTP credentials are correct
- Check Gmail App Password is set
- Enable "Less secure app access" (if using regular password)

**If endpoints return 404:**
- Check server.js has all route imports
- Verify routes are registered with app.use()
- Redeploy with cache cleared
