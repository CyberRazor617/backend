#!/usr/bin/env node
/**
 * Start script with environment variables for CyberRazor Backend
 */

// Set environment variables
process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.PORT = process.env.PORT || '8000';
process.env.MONGODB_URL = process.env.MONGODB_URL || 'mongodb://localhost:27017/cyberrazor_enterprise';
process.env.MONGODB_DB_NAME = process.env.MONGODB_DB_NAME || 'cyberrazor_enterprise';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'cyberrazor-super-secret-jwt-key-change-in-production';
process.env.BCRYPT_ROUNDS = process.env.BCRYPT_ROUNDS || '12';
process.env.RATE_LIMIT_WINDOW_MS = process.env.RATE_LIMIT_WINDOW_MS || '900000';
process.env.RATE_LIMIT_MAX_REQUESTS = process.env.RATE_LIMIT_MAX_REQUESTS || '100';
process.env.WS_HEARTBEAT_INTERVAL = process.env.WS_HEARTBEAT_INTERVAL || '30000';
process.env.WS_MAX_RECONNECT_ATTEMPTS = process.env.WS_MAX_RECONNECT_ATTEMPTS || '5';

console.log('🚀 Starting CyberRazor Backend with environment variables...');
console.log('📋 Environment:');
console.log('  NODE_ENV:', process.env.NODE_ENV);
console.log('  PORT:', process.env.PORT);
console.log('  MONGODB_URL:', process.env.MONGODB_URL);
console.log('  JWT_SECRET:', process.env.JWT_SECRET ? 'Set' : 'Not set');
console.log('  GEMINI_API_KEY:', process.env.GEMINI_API_KEY ? 'Set' : 'Not set');

// Start the server
require('./server.js');
