const express = require('express');
const router = express.Router();
const stripeService = require('../services/stripeService');
const proSubscriptionService = require('../services/proSubscriptionService');

/**
 * @route   POST /api/stripe/create-checkout-session
 * @desc    Create a Stripe checkout session for Pro subscription
 * @access  Public
 */
router.post('/create-checkout-session', async (req, res) => {
  try {
    const { email, plan = 'pro', duration = 30 } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format'
      });
    }

    // Create Stripe checkout session
    const session = await stripeService.createCheckoutSession(email, plan, duration);

    res.status(200).json({
      success: true,
      sessionId: session.sessionId,
      url: session.url,
      message: 'Checkout session created successfully'
    });
  } catch (error) {
    console.error('Create checkout session error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to create checkout session'
    });
  }
});

/**
 * @route   POST /api/stripe/create-subscription
 * @desc    Create a recurring Stripe subscription
 * @access  Public
 */
router.post('/create-subscription', async (req, res) => {
  try {
    const { email, plan = 'pro' } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    // Create Stripe subscription session
    const session = await stripeService.createSubscriptionSession(email, plan);

    res.status(200).json({
      success: true,
      sessionId: session.sessionId,
      url: session.url,
      message: 'Subscription session created successfully'
    });
  } catch (error) {
    console.error('Create subscription error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to create subscription'
    });
  }
});

/**
 * @route   GET /api/stripe/session/:sessionId
 * @desc    Get Stripe session details
 * @access  Public
 */
router.get('/session/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: 'Session ID is required'
      });
    }

    const session = await stripeService.getSession(sessionId);

    res.status(200).json({
      success: true,
      session: {
        id: session.id,
        status: session.payment_status,
        amount: session.amount_total / 100,
        currency: session.currency,
        customer_email: session.customer_email,
        metadata: session.metadata
      }
    });
  } catch (error) {
    console.error('Get session error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to retrieve session'
    });
  }
});

/**
 * @route   POST /api/stripe/webhook
 * @desc    Handle Stripe webhook events
 * @access  Public
 */
router.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];

  try {
    const event = await stripeService.handleWebhook(req.body, sig);

    // Handle the event
    switch (event.type) {
      case 'checkout.session.completed':
        const session = event.data.object;
        console.log('✅ Payment successful:', session.id);

        // Generate access token and send email
        const { email, plan, duration } = session.metadata;
        
        try {
          await proSubscriptionService.createSubscription(
            email,
            plan || 'pro',
            parseInt(duration) || 30
          );
          console.log(`✅ Pro subscription created for ${email}`);
        } catch (subError) {
          console.error('Error creating subscription:', subError);
        }
        break;

      case 'payment_intent.succeeded':
        const paymentIntent = event.data.object;
        console.log('💳 PaymentIntent succeeded:', paymentIntent.id);
        break;

      case 'payment_intent.payment_failed':
        const failedPayment = event.data.object;
        console.log('❌ Payment failed:', failedPayment.id);
        break;

      case 'customer.subscription.created':
        const subscription = event.data.object;
        console.log('🔔 Subscription created:', subscription.id);
        break;

      case 'customer.subscription.deleted':
        const deletedSubscription = event.data.object;
        console.log('🗑️  Subscription deleted:', deletedSubscription.id);
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(400).send(`Webhook Error: ${error.message}`);
  }
});

/**
 * @route   POST /api/stripe/verify-payment
 * @desc    Verify payment and activate subscription
 * @access  Public
 */
router.post('/verify-payment', async (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: 'Session ID is required'
      });
    }

    // Get session details
    const session = await stripeService.getSession(sessionId);

    if (session.payment_status !== 'paid') {
      return res.status(400).json({
        success: false,
        message: 'Payment not completed'
      });
    }

    // Generate access token and send email
    const { email, plan, duration } = session.metadata;
    const result = await proSubscriptionService.createSubscription(
      email,
      plan || 'pro',
      parseInt(duration) || 30
    );

    res.status(200).json({
      success: true,
      message: 'Payment verified and subscription activated',
      accessToken: result.token,
      email: email
    });
  } catch (error) {
    console.error('Verify payment error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to verify payment'
    });
  }
});

/**
 * @route   GET /api/stripe/get-token/:sessionId
 * @desc    Emergency endpoint to get access token for a paid session
 * @access  Public
 */
router.get('/get-token/:sessionId', async (req, res) => {
  try {
    const { sessionId } = req.params;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: 'Session ID is required'
      });
    }

    // Get session details
    const session = await stripeService.getSession(sessionId);

    if (session.payment_status !== 'paid') {
      return res.status(400).json({
        success: false,
        message: 'Payment not completed'
      });
    }

    // Check if token already exists for this email
    const AccessToken = require('../models/AccessToken');
    const { email, plan, duration } = session.metadata;
    
    let existingToken = await AccessToken.findOne({ 
      email: session.customer_email || email 
    }).sort({ createdAt: -1 });

    if (existingToken) {
      return res.status(200).json({
        success: true,
        accessToken: existingToken.token,
        email: existingToken.email,
        message: 'Access token retrieved successfully'
      });
    }

    // If no token exists, create one
    const result = await proSubscriptionService.createSubscription(
      session.customer_email || email,
      plan || 'pro',
      parseInt(duration) || 30
    );

    res.status(200).json({
      success: true,
      accessToken: result.token,
      email: session.customer_email || email,
      message: 'Access token generated successfully'
    });
  } catch (error) {
    console.error('Get token error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to get access token'
    });
  }
});

/**
 * @route   GET /api/stripe/config
 * @desc    Get Stripe configuration
 * @access  Public
 */
router.get('/config', async (req, res) => {
  res.status(200).json({
    success: true,
    publishableKey: process.env.STRIPE_PUBLISHABLE_KEY
  });
});

module.exports = router;
