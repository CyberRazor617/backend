const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

// Validation middleware
const validateActivationRequest = [
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('hostname')
    .notEmpty()
    .withMessage('Hostname is required'),
  
  body('os_info')
    .notEmpty()
    .withMessage('OS information is required'),
  
  body('activation_key')
    .notEmpty()
    .withMessage('Activation key is required')
];

// @route   POST /api/devices/activate-key
// @desc    Activate a device with an activation key
// @access  Public
router.post('/activate-key', validateActivationRequest, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { user_email, hostname, os_info, activation_key } = req.body;

    // Get database connection
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Check if activation key exists and is available
    const activationDoc = await db.collection('device_activations').findOne({
      activation_key: activation_key
    });

    if (!activationDoc) {
      return res.status(400).json({
        error: 'Invalid activation key',
        message: 'The provided activation key is not valid'
      });
    }

    if (activationDoc.status === 'used') {
      return res.status(400).json({
        error: 'Key already used',
        message: 'This activation key has already been used'
      });
    }

    // Check if key has expired
    if (activationDoc.expires_at) {
      const expiryTime = new Date(activationDoc.expires_at);
      if (new Date() > expiryTime) {
        return res.status(400).json({
          error: 'Key expired',
          message: 'This activation key has expired'
        });
      }
    }

    // Update the activation record
    await db.collection('device_activations').updateOne(
      { activation_key: activation_key },
      {
        $set: {
          user_email: user_email,
          hostname: hostname,
          os_info: os_info,
          status: 'used',
          last_seen: new Date().toISOString()
        }
      }
    );

    logger.info(`✅ Device activated successfully: ${hostname} (${user_email})`);

    res.json({
      success: true,
      message: 'Device activated successfully',
      activation_id: activationDoc._id.toString()
    });

  } catch (error) {
    logger.error('Activation error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to activate device'
    });
  }
});

// @route   GET /api/devices
// @desc    Get all activated devices
// @access  Private
router.get('/', optionalAuth, async (req, res) => {
  try {
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Build query - filter out test/demo data
    const query = {
      user_email: { $nin: ['demo@cyberrazor.com', 'test@cyberrazor.com'] },
      hostname: { $nin: ['demo-host', 'test-host'] }
    };

    // If user is authenticated and not admin, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    const devices = await db.collection('device_activations')
      .find(query)
      .sort({ last_seen: -1 })
      .toArray();

    // Transform data
    const transformedDevices = devices.map(device => ({
      id: device._id.toString(),
      ...device,
      _id: undefined
    }));

    res.json({
      devices: transformedDevices,
      total: transformedDevices.length
    });

  } catch (error) {
    logger.error('Error fetching devices:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch devices'
    });
  }
});

// @route   GET /api/devices/activations
// @desc    Get all device activations
// @access  Private
router.get('/activations', optionalAuth, async (req, res) => {
  try {
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Build query - filter out test/demo data
    const query = {
      user_email: { $nin: ['demo@cyberrazor.com', 'test@cyberrazor.com'] },
      hostname: { $nin: ['demo-host', 'test-host'] }
    };

    // If user is authenticated and not admin, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    const activations = await db.collection('device_activations')
      .find(query)
      .sort({ last_seen: -1 })
      .toArray();

    // Transform data
    const transformedActivations = activations.map(activation => ({
      id: activation._id.toString(),
      ...activation,
      _id: undefined
    }));

    res.json({
      devices: transformedActivations,
      total: transformedActivations.length
    });

  } catch (error) {
    logger.error('Error fetching device activations:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch device activations'
    });
  }
});

// @route   POST /api/devices/create-keys
// @desc    Create new activation keys
// @access  Private (Admin)
router.post('/create-keys', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const { count = 5 } = req.body;

    // Generate activation keys
    const activationKeys = [];
    for (let i = 0; i < count; i++) {
      const key = require('crypto').randomBytes(16).toString('hex');
      activationKeys.push({
        activation_key: key,
        status: 'available',
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
        created_by: req.user.email
      });
    }

    // Insert activation keys
    const result = await db.collection('device_activations').insertMany(activationKeys);

    logger.info(`✅ Created ${result.insertedCount} activation keys by admin ${req.user.email}`);

    res.json({
      message: `Created ${result.insertedCount} activation keys`,
      keys: activationKeys.map(k => k.activation_key),
      expires_at: activationKeys[0].expires_at
    });

  } catch (error) {
    logger.error('Error creating activation keys:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create activation keys'
    });
  }
});

// @route   POST /api/devices/refresh-keys
// @desc    Refresh all available activation keys with new expiration
// @access  Private (Admin)
router.post('/refresh-keys', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Update all available keys with new expiration (60 minutes)
    const newExpiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();
    
    const result = await db.collection('device_activations').updateMany(
      { status: 'available' },
      { $set: { expires_at: newExpiresAt } }
    );

    logger.info(`✅ Refreshed ${result.modifiedCount} activation keys by admin ${req.user.email}`);

    res.json({
      message: `Refreshed ${result.modifiedCount} activation keys`,
      new_expiration: newExpiresAt,
      keys_refreshed: result.modifiedCount
    });

  } catch (error) {
    logger.error('Error refreshing activation keys:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to refresh activation keys'
    });
  }
});

// @route   GET /api/devices/stats
// @desc    Get device statistics
// @access  Private
router.get('/stats', optionalAuth, async (req, res) => {
  try {
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Build query - filter out test/demo data
    const query = {
      user_email: { $nin: ['demo@cyberrazor.com', 'test@cyberrazor.com'] },
      hostname: { $nin: ['demo-host', 'test-host'] }
    };

    // If user is authenticated and not admin, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    // Count total devices
    const totalDevices = await db.collection('device_activations').countDocuments(query);

    // Count active devices (status: used)
    const activeDevices = await db.collection('device_activations').countDocuments({
      ...query,
      status: 'used'
    });

    // Count devices by OS
    const osStats = await db.collection('device_activations').aggregate([
      { $match: query },
      { $group: { _id: '$os_info', count: { $sum: 1 } } }
    ]).toArray();

    // Count recent activations (last 24 hours)
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentActivations = await db.collection('device_activations').countDocuments({
      ...query,
      last_seen: { $gte: last24Hours.toISOString() }
    });

    const stats = {
      total_devices: totalDevices,
      active_devices: activeDevices,
      inactive_devices: totalDevices - activeDevices,
      by_os: osStats.reduce((acc, os) => {
        acc[os._id] = os.count;
        return acc;
      }, {}),
      recent_activations_24h: recentActivations,
      timestamp: new Date().toISOString()
    };

    res.json(stats);

  } catch (error) {
    logger.error('Error fetching device stats:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch device statistics'
    });
  }
});

module.exports = router;
