const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const proSubscriptionService = require('../services/proSubscriptionService');
const ProUser = require('../models/ProUser');
const { logger } = require('../config/logger');

/**
 * @route   POST /api/pro/subscribe
 * @desc    Create new subscription and send access token
 * @access  Public
 */
router.post('/subscribe', async (req, res) => {
  try {
    const { email, plan = 'basic', duration = 30 } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Email is required'
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid email format'
      });
    }

    // Create subscription
    const result = await proSubscriptionService.createSubscription(email, plan, duration);

    res.status(201).json(result);
  } catch (error) {
    logger.error('Error creating subscription:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create subscription',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/pro/activate
 * @desc    Activate access token and create user account
 * @access  Public
 */
router.post('/activate', async (req, res) => {
  try {
    const { accessToken, password } = req.body;

    if (!accessToken || !password) {
      return res.status(400).json({
        success: false,
        message: 'Access token and password are required'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long'
      });
    }

    // Activate access token
    const result = await proSubscriptionService.activateAccessToken(accessToken, password);

    if (!result.success) {
      return res.status(400).json(result);
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: result.user.id,
        email: result.user.email,
        type: 'pro'
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(200).json({
      ...result,
      token
    });
  } catch (error) {
    logger.error('Error activating access token:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to activate access token',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/pro/login
 * @desc    Login with access token and password
 * @access  Public
 */
router.post('/login', async (req, res) => {
  try {
    const { accessToken, password } = req.body;

    if (!accessToken || !password) {
      return res.status(400).json({
        success: false,
        message: 'Access token and password are required'
      });
    }

    // Authenticate user
    const result = await proSubscriptionService.authenticateUser(accessToken, password);

    if (!result.success) {
      return res.status(401).json(result);
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        userId: result.user.id,
        email: result.user.email,
        type: 'pro'
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(200).json({
      ...result,
      token
    });
  } catch (error) {
    logger.error('Error logging in:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to login',
      error: error.message
    });
  }
});

/**
 * @route   GET /api/pro/profile
 * @desc    Get user profile
 * @access  Private
 */
router.get('/profile', verifyProToken, async (req, res) => {
  try {
    const proUser = await ProUser.findById(req.userId).select('-password');

    if (!proUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      user: {
        id: proUser._id,
        email: proUser.email,
        plan: proUser.subscriptionPlan,
        status: proUser.subscriptionStatus,
        subscriptionEndDate: proUser.subscriptionEndDate,
        lastLogin: proUser.lastLogin,
        isActive: proUser.isActive
      }
    });
  } catch (error) {
    logger.error('Error fetching profile:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch profile',
      error: error.message
    });
  }
});

/**
 * @route   PUT /api/pro/password
 * @desc    Update user password
 * @access  Private
 */
router.put('/password', verifyProToken, async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body;

    if (!oldPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Old password and new password are required'
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 6 characters long'
      });
    }

    const result = await proSubscriptionService.updatePassword(
      req.userId,
      oldPassword,
      newPassword
    );

    res.status(200).json(result);
  } catch (error) {
    logger.error('Error updating password:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update password',
      error: error.message
    });
  }
});

/**
 * @route   POST /api/pro/check-token
 * @desc    Check if access token is valid and available
 * @access  Public
 */
router.post('/check-token', async (req, res) => {
  try {
    const { accessToken } = req.body;

    if (!accessToken) {
      return res.status(400).json({
        success: false,
        message: 'Access token is required'
      });
    }

    const AccessToken = require('../models/AccessToken');
    const tokenRecord = await AccessToken.findOne({ token: accessToken });

    if (!tokenRecord) {
      return res.status(404).json({
        success: false,
        message: 'Invalid access token',
        status: 'invalid'
      });
    }

    if (tokenRecord.isUsed) {
      return res.status(200).json({
        success: false,
        message: 'This access token has already been used',
        status: 'used'
      });
    }

    if (new Date() > tokenRecord.expiresAt) {
      return res.status(200).json({
        success: false,
        message: 'This access token has expired',
        status: 'expired'
      });
    }

    res.status(200).json({
      success: true,
      message: 'Access token is valid',
      status: 'valid',
      email: tokenRecord.email,
      plan: tokenRecord.subscriptionPlan
    });
  } catch (error) {
    logger.error('Error checking token:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to check token',
      error: error.message
    });
  }
});

/**
 * Middleware to verify JWT token for pro users
 */
function verifyProToken(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'No token provided'
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.type !== 'pro') {
      return res.status(403).json({
        success: false,
        message: 'Invalid token type'
      });
    }

    req.userId = decoded.userId;
    req.email = decoded.email;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token'
    });
  }
}

module.exports = router;
