const express = require('express');
const { logger } = require('../config/logger');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Store alerts in memory (in production, use database)
let realtimeAlerts = [];

// @route   POST /api/alerts/realtime
// @desc    Receive real-time alerts from agents
// @access  Private
router.post('/realtime', requireAuth, async (req, res) => {
  try {
    const alertData = req.body;
    
    // Add user information to alert
    alertData.user_id = req.user.id;
    alertData.user_email = req.user.email;
    alertData.received_at = new Date().toISOString();
    
    // Store alert
    realtimeAlerts.push(alertData);
    
    // Keep only last 1000 alerts to prevent memory issues
    if (realtimeAlerts.length > 1000) {
      realtimeAlerts = realtimeAlerts.slice(-1000);
    }
    
    logger.info(`📱 Real-time alert received from ${req.user.email}: ${alertData.event_type} - ${alertData.file_name}`);
    
    // Send real-time notification via WebSocket if available
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        wsService.broadcastAlertToUser(req.user.id, {
          type: 'realtime_alert',
          alert: alertData
        });
        logger.info(`📡 Alert broadcasted to user ${req.user.email} via WebSocket`);
      }
    } catch (wsError) {
      logger.error(`❌ WebSocket broadcast error: ${wsError.message}`);
    }
    
    res.json({
      success: true,
      message: 'Alert received and processed',
      alert_id: alertData.alert_id
    });
    
  } catch (error) {
    logger.error('Real-time alert processing error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to process alert'
    });
  }
});

// @route   GET /api/alerts/realtime
// @desc    Get real-time alerts for current user
// @access  Private
router.get('/realtime', requireAuth, async (req, res) => {
  try {
    const { limit = 50, offset = 0 } = req.query;
    
    // Filter alerts for current user
    const userAlerts = realtimeAlerts
      .filter(alert => alert.user_id === req.user.id)
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(parseInt(offset), parseInt(offset) + parseInt(limit));
    
    res.json({
      success: true,
      alerts: userAlerts,
      total: realtimeAlerts.filter(alert => alert.user_id === req.user.id).length,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
    
  } catch (error) {
    logger.error('Get alerts error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to retrieve alerts'
    });
  }
});

// @route   GET /api/alerts/realtime/stats
// @desc    Get alert statistics for current user
// @access  Private
router.get('/realtime/stats', requireAuth, async (req, res) => {
  try {
    const userAlerts = realtimeAlerts.filter(alert => alert.user_id === req.user.id);
    
    const stats = {
      total_alerts: userAlerts.length,
      alerts_today: userAlerts.filter(alert => {
        const alertDate = new Date(alert.timestamp).toDateString();
        const today = new Date().toDateString();
        return alertDate === today;
      }).length,
      severity_breakdown: {
        high: userAlerts.filter(alert => alert.severity === 'high').length,
        medium: userAlerts.filter(alert => alert.severity === 'medium').length,
        low: userAlerts.filter(alert => alert.severity === 'low').length
      },
      event_types: userAlerts.reduce((acc, alert) => {
        acc[alert.event_type] = (acc[alert.event_type] || 0) + 1;
        return acc;
      }, {}),
      last_alert: userAlerts.length > 0 ? userAlerts[userAlerts.length - 1].timestamp : null
    };
    
    res.json({
      success: true,
      stats: stats
    });
    
  } catch (error) {
    logger.error('Get alert stats error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to retrieve alert statistics'
    });
  }
});

// @route   DELETE /api/alerts/realtime/:alert_id
// @desc    Delete a specific alert
// @access  Private
router.delete('/realtime/:alert_id', requireAuth, async (req, res) => {
  try {
    const { alert_id } = req.params;
    
    const alertIndex = realtimeAlerts.findIndex(
      alert => alert.alert_id === alert_id && alert.user_id === req.user.id
    );
    
    if (alertIndex === -1) {
      return res.status(404).json({
        error: 'Alert not found',
        message: 'Alert not found or you do not have permission to delete it'
      });
    }
    
    realtimeAlerts.splice(alertIndex, 1);
    
    res.json({
      success: true,
      message: 'Alert deleted successfully'
    });
    
  } catch (error) {
    logger.error('Delete alert error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to delete alert'
    });
  }
});

// @route   POST /api/alerts/realtime/clear
// @desc    Clear all alerts for current user
// @access  Private
router.post('/realtime/clear', requireAuth, async (req, res) => {
  try {
    const beforeCount = realtimeAlerts.length;
    realtimeAlerts = realtimeAlerts.filter(alert => alert.user_id !== req.user.id);
    const clearedCount = beforeCount - realtimeAlerts.length;
    
    logger.info(`🗑️ Cleared ${clearedCount} alerts for user ${req.user.email}`);
    
    res.json({
      success: true,
      message: `Cleared ${clearedCount} alerts`,
      cleared_count: clearedCount
    });
    
  } catch (error) {
    logger.error('Clear alerts error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to clear alerts'
    });
  }
});

module.exports = router;
