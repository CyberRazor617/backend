const express = require('express');
const { logger } = require('../config/logger');
const { requireAuth } = require('../middleware/auth');
const User = require('../models/User');
const { sendApprovalEmail, sendRejectionEmail } = require('../services/emailService');

const router = express.Router();

// @route   GET /api/admin/users
// @desc    Get all users (admin only)
// @access  Private (Admin)
router.get('/users', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    logger.info(`🔍 Admin users request from: ${req.user.email}`);

    // Get all users
    const users = await User.find({}).lean();
    logger.info(`📊 Found ${users.length} users`);

    // Get database connection for additional data
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Get device activations for each user
    const activations = await db.collection('device_activations').find({}).toArray();
    logger.info(`📱 Found ${activations.length} device activations`);

    // Get pro licenses
    let proLicenses = [];
    try {
      proLicenses = await db.collection('pro_licenses').find({}).toArray();
      logger.info(`💳 Found ${proLicenses.length} pro licenses`);
    } catch (error) {
      logger.warn(`⚠️ Pro licenses error: ${error.message}`);
    }

    // Get recent logs for each user
    const userData = [];
    for (const user of users) {
      try {
        const userEmail = user.email;

        // Get user's device activations and convert ObjectIds
        const userActivations = activations
          .filter(a => a.user_email === userEmail)
          .map(a => {
            const activationDict = {};
            for (const [key, value] of Object.entries(a)) {
              if (key === '_id') {
                activationDict.id = value.toString();
              } else {
                activationDict[key] = value;
              }
            }
            return activationDict;
          });

        // Get user's pro license status and convert ObjectId
        let proLicense = null;
        for (const l of proLicenses) {
          if (l.user_email === userEmail) {
            const licenseDict = {};
            for (const [key, value] of Object.entries(l)) {
              if (key === '_id') {
                licenseDict.id = value.toString();
              } else {
                licenseDict[key] = value;
              }
            }
            proLicense = licenseDict;
            break;
          }
        }

        // Get recent logs for this user and convert ObjectIds
        let recentLogs = [];
        try {
          const recentLogsRaw = await db.collection('agent_logs')
            .find({ user_email: userEmail })
            .sort({ timestamp: -1 })
            .limit(10)
            .toArray();

          recentLogs = recentLogsRaw.map(log => {
            const logDict = {};
            for (const [key, value] of Object.entries(log)) {
              if (key === '_id') {
                logDict.id = value.toString();
              } else {
                logDict[key] = value;
              }
            }
            return logDict;
          });
        } catch (error) {
          logger.warn(`⚠️ Logs error for ${userEmail}: ${error.message}`);
        }

        userData.push({
          id: user._id.toString(),
          username: user.username,
          email: user.email,
          is_admin: user.is_admin,
          status: user.status,
          activation_key: user.activation_key,
          created_at: user.created_at,
          approved_by: user.approved_by,
          approved_at: user.approved_at,
          rejected_by: user.rejected_by,
          rejected_at: user.rejected_at,
          rejection_reason: user.rejection_reason,
          subscription_plan: user.subscription_plan,
          trial_start_date: user.trial_start_date,
          trial_end_date: user.trial_end_date,
          device_activations: userActivations,
          pro_license: proLicense,
          recent_logs: recentLogs,
          last_seen: userActivations.length > 0 ? userActivations[userActivations.length - 1].timestamp : null
        });
      } catch (error) {
        logger.warn(`⚠️ Error processing user ${user.email || 'unknown'}: ${error.message}`);
        continue;
      }
    }

    logger.info(`✅ Processed ${userData.length} users successfully`);

    res.json({
      users: userData,
      total_users: userData.length,
      active_users: userData.filter(u => u.device_activations.length > 0).length,
      pro_users: userData.filter(u => u.pro_license).length,
      pending_users: userData.filter(u => u.status === 'pending').length,
      approved_users: userData.filter(u => u.status === 'approved').length,
      rejected_users: userData.filter(u => u.status === 'rejected').length
    });

  } catch (error) {
    logger.error('Admin users error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error fetching users: ${error.message}`
    });
  }
});

// @route   GET /api/admin/pending-users
// @desc    Get pending users (admin only)
// @access  Private (Admin)
router.get('/pending-users', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    logger.info(`🔍 Admin pending users request from: ${req.user.email}`);

    // Get pending users
    const pendingUsers = await User.getPendingUsers();
    logger.info(`📊 Found ${pendingUsers.length} pending users`);

    const userData = pendingUsers.map(user => ({
      id: user._id.toString(),
      username: user.username,
      email: user.email,
      status: user.status,
      created_at: user.created_at,
      activation_key: user.activation_key
    }));

    res.json({
      users: userData,
      total_pending: userData.length
    });

  } catch (error) {
    logger.error('Admin pending users error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error fetching pending users: ${error.message}`
    });
  }
});

// @route   POST /api/admin/user-activation
// @desc    Approve or reject a user (admin only)
// @access  Private (Admin)
router.post('/user-activation', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { user_id, action, rejection_reason } = req.body;

    if (!user_id || !action) {
      return res.status(400).json({
        error: 'Missing required fields',
        message: 'user_id and action are required'
      });
    }

    if (!['approve', 'reject'].includes(action)) {
      return res.status(400).json({
        error: 'Invalid action',
        message: 'Action must be either "approve" or "reject"'
      });
    }

    if (action === 'reject' && !rejection_reason) {
      return res.status(400).json({
        error: 'Rejection reason required',
        message: 'Rejection reason is required when rejecting a user'
      });
    }

    // Find the user
    const user = await User.findById(user_id);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'The specified user does not exist'
      });
    }

    if (user.status !== 'pending') {
      return res.status(400).json({
        error: 'Invalid user status',
        message: 'User is not in pending status'
      });
    }

    logger.info(`🔍 Admin ${req.user.email} ${action}ing user: ${user.email}`);

    let emailSent = false;

    if (action === 'approve') {
      // Approve the user
      await user.approve(req.user.email);
      
      // Send approval email
      try {
        emailSent = await sendApprovalEmail(user.email, user.username);
        if (emailSent) {
          logger.info(`📧 Approval email sent to: ${user.email}`);
        } else {
          logger.warn(`⚠️ Failed to send approval email to: ${user.email}`);
        }
      } catch (emailError) {
        logger.error(`❌ Approval email error: ${emailError.message}`);
      }

      // Send real-time WebSocket notification
      try {
        const wsService = req.app.locals.wsService;
        if (wsService) {
          const userData = {
            id: user._id.toString(),
            username: user.username,
            email: user.email,
            status: user.status,
            approved_by: user.approved_by,
            approved_at: user.approved_at,
            trial_start_date: user.trial_start_date,
            trial_end_date: user.trial_end_date
          };
          
          wsService.broadcastUserApproval(userData, req.user.email);
          logger.info(`📡 Real-time approval notification sent for: ${user.email}`);
        }
      } catch (wsError) {
        logger.error(`❌ WebSocket notification error: ${wsError.message}`);
      }

      logger.info(`✅ User approved: ${user.email}`);
      
      res.json({
        success: true,
        message: `User ${user.username} has been approved successfully`,
        user: {
          id: user._id.toString(),
          username: user.username,
          email: user.email,
          status: user.status,
          approved_by: user.approved_by,
          approved_at: user.approved_at,
          trial_start_date: user.trial_start_date,
          trial_end_date: user.trial_end_date
        },
        email_sent: emailSent
      });

    } else if (action === 'reject') {
      // Reject the user
      await user.reject(req.user.email, rejection_reason);
      
      // Send rejection email
      try {
        emailSent = await sendRejectionEmail(user.email, user.username, rejection_reason);
        if (emailSent) {
          logger.info(`📧 Rejection email sent to: ${user.email}`);
        } else {
          logger.warn(`⚠️ Failed to send rejection email to: ${user.email}`);
        }
      } catch (emailError) {
        logger.error(`❌ Rejection email error: ${emailError.message}`);
      }

      // Send real-time WebSocket notification
      try {
        const wsService = req.app.locals.wsService;
        if (wsService) {
          const userData = {
            id: user._id.toString(),
            username: user.username,
            email: user.email,
            status: user.status,
            rejected_by: user.rejected_by,
            rejected_at: user.rejected_at,
            rejection_reason: user.rejection_reason
          };
          
          wsService.broadcastUserRejection(userData, req.user.email, rejection_reason);
          logger.info(`📡 Real-time rejection notification sent for: ${user.email}`);
        }
      } catch (wsError) {
        logger.error(`❌ WebSocket notification error: ${wsError.message}`);
      }

      logger.info(`❌ User rejected: ${user.email}`);
      
      res.json({
        success: true,
        message: `User ${user.username} has been rejected`,
        user: {
          id: user._id.toString(),
          username: user.username,
          email: user.email,
          status: user.status,
          rejected_by: user.rejected_by,
          rejected_at: user.rejected_at,
          rejection_reason: user.rejection_reason
        },
        email_sent: emailSent
      });
    }

  } catch (error) {
    logger.error('User activation error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error processing user activation: ${error.message}`
    });
  }
});

// @route   GET /api/admin/user/:user_email/logs
// @desc    Get logs for a specific user (admin only)
// @access  Private (Admin)
router.get('/user/:user_email/logs', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { user_email } = req.params;
    const { limit = 100 } = req.query;

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const logsRaw = await db.collection('agent_logs')
      .find({ user_email: user_email })
      .sort({ timestamp: -1 })
      .limit(parseInt(limit))
      .toArray();

    // Convert ObjectIds to strings
    const logs = logsRaw.map(log => {
      const logDict = {};
      for (const [key, value] of Object.entries(log)) {
        if (key === '_id') {
          logDict.id = value.toString();
        } else {
          logDict[key] = value;
        }
      }
      return logDict;
    });

    res.json({
      user_email: user_email,
      logs: logs,
      total_logs: logs.length
    });

  } catch (error) {
    logger.error(`Error fetching user logs for ${req.params.user_email}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error fetching user logs: ${error.message}`
    });
  }
});

// @route   GET /api/admin/user/:user_email/devices
// @desc    Get device activations for a specific user (admin only)
// @access  Private (Admin)
router.get('/user/:user_email/devices', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { user_email } = req.params;

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const devicesRaw = await db.collection('device_activations')
      .find({ user_email: user_email })
      .sort({ timestamp: -1 })
      .toArray();

    // Convert ObjectIds to strings
    const devices = devicesRaw.map(device => {
      const deviceDict = {};
      for (const [key, value] of Object.entries(device)) {
        if (key === '_id') {
          deviceDict.id = value.toString();
        } else {
          deviceDict[key] = value;
        }
      }
      return deviceDict;
    });

    res.json({
      user_email: user_email,
      devices: devices,
      total_devices: devices.length
    });

  } catch (error) {
    logger.error(`Error fetching user devices for ${req.params.user_email}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error fetching user devices: ${error.message}`
    });
  }
});

// @route   DELETE /api/admin/users/by-email/:user_email
// @desc    Remove a user and all their data (admin only)
// @access  Private (Admin)
router.delete('/users/by-email/:user_email', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { user_email } = req.params;

    // Prevent admin from removing themselves
    if (user_email === req.user.email) {
      return res.status(400).json({
        error: 'Cannot remove own account',
        message: 'You cannot remove your own account'
      });
    }

    logger.info(`🗑️ Admin ${req.user.email} attempting to remove user: ${user_email}`);

    // Check if user exists
    const user = await User.findOne({ email: user_email });
    if (!user) {
      logger.warn(`❌ User not found with email: '${user_email}'`);
      return res.status(404).json({
        error: 'User not found',
        message: 'The specified user does not exist'
      });
    }

    logger.info(`✅ Found user: ${user.email} (username: ${user.username})`);

    // Get database connection
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Remove user and all associated data
    // 1. Remove user from users collection
    const userResult = await User.deleteOne({ email: user_email });

    // 2. Remove user's device activations
    const deviceResult = await db.collection('device_activations').deleteMany({ user_email: user_email });

    // 3. Remove user's threats
    const threatResult = await db.collection('threats').deleteMany({ user_email: user_email });

    // 4. Remove user's error reports
    const errorResult = await db.collection('error_reports').deleteMany({ user_email: user_email });

    // 5. Remove user's agent logs
    const logResult = await db.collection('agent_logs').deleteMany({ user_email: user_email });

    // 6. Remove user's scan results
    const scanResult = await db.collection('scan_results').deleteMany({ user_email: user_email });

    // 7. Remove user's scan sessions
    const sessionResult = await db.collection('scan_sessions').deleteMany({ user_email: user_email });

    // 8. Remove user's pro license
    const licenseResult = await db.collection('pro_licenses').deleteMany({ user_email: user_email });

    logger.info(`✅ Removed user ${user_email} and all associated data:`);
    logger.info(`   - User: ${userResult.deletedCount}`);
    logger.info(`   - Device activations: ${deviceResult.deletedCount}`);
    logger.info(`   - Threats: ${threatResult.deletedCount}`);
    logger.info(`   - Error reports: ${errorResult.deletedCount}`);
    logger.info(`   - Agent logs: ${logResult.deletedCount}`);
    logger.info(`   - Scan results: ${scanResult.deletedCount}`);
    logger.info(`   - Scan sessions: ${sessionResult.deletedCount}`);
    logger.info(`   - Pro licenses: ${licenseResult.deletedCount}`);

    res.json({
      success: true,
      message: `User ${user_email} and all associated data removed successfully`,
      removed_data: {
        user: userResult.deletedCount,
        device_activations: deviceResult.deletedCount,
        threats: threatResult.deletedCount,
        error_reports: errorResult.deletedCount,
        agent_logs: logResult.deletedCount,
        scan_results: scanResult.deletedCount,
        scan_sessions: sessionResult.deletedCount,
        pro_licenses: licenseResult.deletedCount
      }
    });

  } catch (error) {
    logger.error(`Error removing user ${req.params.user_email}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

// @route   DELETE /api/admin/users/:user_id
// @desc    Remove a user by ID and all their data (admin only)
// @access  Private (Admin)
router.delete('/users/:user_id', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { user_id } = req.params;

    // Validate user_id format (MongoDB ObjectId)
    if (!user_id.match(/^[0-9a-fA-F]{24}$/)) {
      return res.status(400).json({
        error: 'Invalid user ID format',
        message: 'User ID must be a valid MongoDB ObjectId'
      });
    }

    logger.info(`🗑️ Admin ${req.user.email} attempting to remove user with ID: ${user_id}`);

    // Check if user exists by ID
    const user = await User.findById(user_id);
    if (!user) {
      logger.warn(`❌ User not found with ID: '${user_id}'`);
      return res.status(404).json({
        error: 'User not found',
        message: 'The specified user does not exist'
      });
    }

    // Prevent admin from removing themselves
    if (user.email === req.user.email) {
      return res.status(400).json({
        error: 'Cannot remove own account',
        message: 'You cannot remove your own account'
      });
    }

    // Prevent deletion of other admin users (optional safety check)
    if (user.is_admin) {
      return res.status(403).json({
        error: 'Cannot delete admin users',
        message: 'Admin users cannot be deleted for security reasons'
      });
    }

    logger.info(`✅ Found user: ${user.email} (username: ${user.username})`);

    // Get database connection
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Remove user and all associated data
    // 1. Remove user from users collection
    const userResult = await User.deleteOne({ _id: user_id });

    // 2. Remove user's device activations
    const deviceResult = await db.collection('device_activations').deleteMany({ user_email: user.email });

    // 3. Remove user's threats
    const threatResult = await db.collection('threats').deleteMany({ user_email: user.email });

    // 4. Remove user's error reports
    const errorResult = await db.collection('error_reports').deleteMany({ user_email: user.email });

    // 5. Remove user's agent logs
    const logResult = await db.collection('agent_logs').deleteMany({ user_email: user.email });

    // 6. Remove user's scan results
    const scanResult = await db.collection('scan_results').deleteMany({ user_email: user.email });

    // 7. Remove user's scan sessions
    const sessionResult = await db.collection('scan_sessions').deleteMany({ user_email: user.email });

    // 8. Remove user's pro license
    const licenseResult = await db.collection('pro_licenses').deleteMany({ user_email: user.email });

    // 9. Remove user's activities
    const activityResult = await db.collection('activities').deleteMany({ user_email: user.email });

    logger.info(`✅ Removed user ${user.email} (ID: ${user_id}) and all associated data:`);
    logger.info(`   - User: ${userResult.deletedCount}`);
    logger.info(`   - Device activations: ${deviceResult.deletedCount}`);
    logger.info(`   - Threats: ${threatResult.deletedCount}`);
    logger.info(`   - Error reports: ${errorResult.deletedCount}`);
    logger.info(`   - Agent logs: ${logResult.deletedCount}`);
    logger.info(`   - Scan results: ${scanResult.deletedCount}`);
    logger.info(`   - Scan sessions: ${sessionResult.deletedCount}`);
    logger.info(`   - Pro licenses: ${licenseResult.deletedCount}`);
    logger.info(`   - Activities: ${activityResult.deletedCount}`);

    res.json({
      success: true,
      message: `User ${user.username} (${user.email}) has been permanently deleted`,
      deleted_user_id: user_id,
      deleted_user_email: user.email,
      removed_data: {
        user: userResult.deletedCount,
        device_activations: deviceResult.deletedCount,
        threats: threatResult.deletedCount,
        error_reports: errorResult.deletedCount,
        agent_logs: logResult.deletedCount,
        scan_results: scanResult.deletedCount,
        scan_sessions: sessionResult.deletedCount,
        pro_licenses: licenseResult.deletedCount,
        activities: activityResult.deletedCount
      }
    });

  } catch (error) {
    logger.error(`Error removing user ${req.params.user_id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

// @route   GET /api/admin/real-time/dashboard-stats
// @desc    Get real-time dashboard statistics
// @access  Private (Admin)
router.get('/real-time/dashboard-stats', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Get total threats
    const totalThreats = await db.collection('threats').countDocuments({});

    // Get recent threats (last 24 hours)
    const cutoffTime = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentThreats24h = await db.collection('threats').countDocuments({
      timestamp: { $gte: cutoffTime.toISOString() }
    });

    // Get user statistics
    const totalUsers = await User.countDocuments({});
    const pendingUsers = await User.countDocuments({ status: 'pending' });
    const approvedUsers = await User.countDocuments({ status: 'approved' });
    const rejectedUsers = await User.countDocuments({ status: 'rejected' });

    // Get active devices
    const activeDevices = await db.collection('device_activations').countDocuments({ status: 'used' });

    // Get scan summary
    const totalScans = await db.collection('scan_results').countDocuments({});

    res.json({
      totalThreats: totalThreats,
      recentThreats: recentThreats24h,
      totalUsers: totalUsers,
      pendingUsers: pendingUsers,
      approvedUsers: approvedUsers,
      rejectedUsers: rejectedUsers,
      activeDevices: activeDevices,
      totalScans: totalScans,
      systemStatus: 'operational',
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error fetching real-time dashboard stats:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

// @route   GET /api/admin/real-time/dashboard-stats-enhanced
// @desc    Get enhanced real-time dashboard statistics
// @access  Private (Admin)
router.get('/real-time/dashboard-stats-enhanced', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Get comprehensive statistics
    const totalThreats = await db.collection('threats').countDocuments({});
    const totalUsers = await User.countDocuments({});
    const pendingUsers = await User.countDocuments({ status: 'pending' });
    const approvedUsers = await User.countDocuments({ status: 'approved' });
    const rejectedUsers = await User.countDocuments({ status: 'rejected' });
    const activeDevices = await db.collection('device_activations').countDocuments({ status: 'used' });
    const totalScans = await db.collection('scan_results').countDocuments({});

    // Get recent activity (last 24 hours)
    const cutoffTime = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentThreats24h = await db.collection('threats').countDocuments({
      timestamp: { $gte: cutoffTime.toISOString() }
    });

    // Get threat distribution by type
    const threatTypes = await db.collection('threats').aggregate([
      { $group: { _id: '$threat_type', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 10 }
    ]).toArray();

    // Get user registration trend (last 7 days)
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const userRegistrations = await User.aggregate([
      { $match: { created_at: { $gte: sevenDaysAgo } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$created_at' } }, count: { $sum: 1 } } },
      { $sort: { _id: 1 } }
    ]);

    res.json({
      overview: {
        totalThreats,
        totalUsers,
        pendingUsers,
        approvedUsers,
        rejectedUsers,
        activeDevices,
        totalScans,
        recentThreats24h
      },
      threatTypes: threatTypes.map(t => ({ type: t._id, count: t.count })),
      userRegistrations: userRegistrations.map(u => ({ date: u._id, count: u.count })),
      systemStatus: 'operational',
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error fetching enhanced dashboard stats:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

// @route   GET /api/admin/real-time/threats
// @desc    Get real-time threats data
// @access  Private (Admin)
router.get('/real-time/threats', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { limit = 50 } = req.query;
    const db = req.app.locals.db;
    
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const threats = await db.collection('threats')
      .find({})
      .sort({ timestamp: -1 })
      .limit(parseInt(limit))
      .toArray();

    // Convert ObjectIds to strings
    const formattedThreats = threats.map(threat => {
      const threatDict = {};
      for (const [key, value] of Object.entries(threat)) {
        if (key === '_id') {
          threatDict.id = value.toString();
        } else {
          threatDict[key] = value;
        }
      }
      return threatDict;
    });

    res.json({
      threats: formattedThreats,
      total: formattedThreats.length,
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error fetching real-time threats:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

// @route   GET /api/admin/real-time/agents
// @desc    Get real-time agents data
// @access  Private (Admin)
router.get('/real-time/agents', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const db = req.app.locals.db;
    
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Get agent logs summary
    const agentSummary = await db.collection('agent_logs').aggregate([
      { $group: { _id: '$user_email', count: { $sum: 1 }, lastSeen: { $max: '$timestamp' } } },
      { $sort: { lastSeen: -1 } },
      { $limit: 20 }
    ]).toArray();

    res.json({
      agents: agentSummary.map(agent => ({
        userEmail: agent._id,
        logCount: agent.count,
        lastSeen: agent.lastSeen
      })),
      totalAgents: agentSummary.length,
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error fetching real-time agents:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

// @route   GET /api/admin/real-time/system-status
// @desc    Get real-time system status
// @access  Private (Admin)
router.get('/real-time/system-status', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const db = req.app.locals.db;
    
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Check database connectivity
    const dbStatus = await db.admin().ping();
    
    // Get system metrics
    const totalCollections = await db.listCollections().toArray();
    const dbStats = await db.stats();

    res.json({
      status: 'operational',
      database: {
        connected: dbStatus.ok === 1,
        collections: totalCollections.length,
        dataSize: dbStats.dataSize,
        indexSize: dbStats.indexSize
      },
      services: {
        api: 'operational',
        websocket: 'operational',
        email: 'operational'
      },
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error fetching system status:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Internal server error: ${error.message}`
    });
  }
});

module.exports = router;
