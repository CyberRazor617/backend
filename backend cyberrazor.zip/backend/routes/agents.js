const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// Validation middleware
const validateAgentLogs = [
  body('device_id')
    .notEmpty()
    .withMessage('Device ID is required'),
  
  body('hostname')
    .notEmpty()
    .withMessage('Hostname is required'),
  
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('level')
    .isIn(['INFO', 'WARNING', 'ERROR', 'DEBUG'])
    .withMessage('Invalid log level'),
  
  body('message')
    .notEmpty()
    .withMessage('Log message is required')
];

// @route   POST /api/agent/logs
// @desc    Receive logs from CLI agent
// @access  Public
router.post('/logs', validateAgentLogs, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const {
      device_id,
      hostname,
      user_email,
      level,
      message,
      module,
      log_type,
      file_path,
      extra_data
    } = req.body;

    // Get database connection
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const logId = uuidv4();
    
    const logDoc = {
      _id: logId,
      device_id: device_id,
      hostname: hostname,
      user_email: user_email,
      level: level,
      message: message,
      module: module || '',
      log_type: log_type || 'agent_activity',
      timestamp: new Date().toISOString(),
      file_path: file_path,
      extra_data: extra_data || {}
    };

    await db.collection('agent_logs').insertOne(logDoc);

    logger.info(`📝 Agent log received: ${level} - ${message.substring(0, 100)}...`);

    res.json({
      success: true,
      message: 'Log received successfully',
      log_id: logId
    });

  } catch (error) {
    logger.error('Error receiving agent log:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to receive log'
    });
  }
});

// @route   GET /api/agent/logs
// @desc    Get agent logs for dashboard
// @access  Private
router.get('/logs', async (req, res) => {
  try {
    const { user_email, limit = 100 } = req.query;

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const query = user_email ? { user_email: user_email } : {};
    const logs = await db.collection('agent_logs')
      .find(query)
      .sort({ timestamp: -1 })
      .limit(parseInt(limit))
      .toArray();

    // Transform data
    const transformedLogs = logs.map(log => ({
      id: log._id.toString(),
      ...log,
      _id: undefined
    }));

    res.json({
      logs: transformedLogs,
      total: transformedLogs.length
    });

  } catch (error) {
    logger.error('Error fetching agent logs:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch agent logs'
    });
  }
});

// @route   POST /api/agent/status
// @desc    Receive status updates from agents
// @access  Public
router.post('/status', async (req, res) => {
  try {
    const { device_id, status, message, details = {} } = req.body;

    if (!device_id) {
      return res.status(400).json({
        error: 'Device ID is required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Store status update
    const statusUpdate = {
      device_id,
      status: status || 'unknown',
      message: message || 'No message',
      details,
      timestamp: new Date().toISOString()
    };

    await db.collection('agent_status').insertOne(statusUpdate);

    logger.info(`📊 Agent status update: ${device_id} - ${status}: ${message}`);

    res.json({
      success: true,
      message: 'Status update received'
    });

  } catch (error) {
    logger.error('Error processing agent status:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to process status update'
    });
  }
});

// @route   POST /api/agent/alerts
// @desc    Receive alerts from agents
// @access  Public
router.post('/alerts', async (req, res) => {
  try {
    const { device_id, alert_type, message, details = {} } = req.body;

    if (!device_id) {
      return res.status(400).json({
        error: 'Device ID is required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Store alert
    const alert = {
      device_id,
      alert_type: alert_type || 'general',
      message: message || 'No message',
      details,
      timestamp: new Date().toISOString(),
      status: 'new'
    };

    await db.collection('agent_alerts').insertOne(alert);

    logger.info(`🚨 Agent alert: ${device_id} - ${alert_type}: ${message}`);

    res.json({
      success: true,
      message: 'Alert received'
    });

  } catch (error) {
    logger.error('Error processing agent alert:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to process alert'
    });
  }
});

// @route   POST /api/agent/errors
// @desc    Receive error reports from agents
// @access  Public
router.post('/errors', async (req, res) => {
  try {
    const { device_id, error_type, error_message, stack_trace } = req.body;

    if (!device_id) {
      return res.status(400).json({
        error: 'Device ID is required'
      });
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Store error report
    const errorReport = {
      device_id,
      error_type: error_type || 'unknown',
      error_message: error_message || 'No message',
      stack_trace: stack_trace || null,
      timestamp: new Date().toISOString()
    };

    await db.collection('agent_errors').insertOne(errorReport);

    logger.error(`❌ Agent error: ${device_id} - ${error_type}: ${error_message}`);

    res.json({
      success: true,
      message: 'Error report received'
    });

  } catch (error) {
    logger.error('Error processing agent error report:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to process error report'
    });
  }
});

// @route   GET /api/agent/status
// @desc    Get agent status for dashboard
// @access  Private
router.get('/status', async (req, res) => {
  try {
    const { user_email } = req.query;

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const query = user_email ? { user_email: user_email, status: 'running' } : { status: 'running' };
    const agents = await db.collection('agent_processes')
      .find(query)
      .sort({ last_heartbeat: -1 })
      .toArray();

    // Transform data
    const transformedAgents = agents.map(agent => ({
      id: agent._id.toString(),
      ...agent,
      _id: undefined
    }));

    res.json({
      agents: transformedAgents,
      total: transformedAgents.length
    });

  } catch (error) {
    logger.error('Error fetching agent status:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch agent status'
    });
  }
});

module.exports = router;
