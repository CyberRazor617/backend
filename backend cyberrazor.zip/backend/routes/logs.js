const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const ScanLog = require('../models/ScanLog');
const NetworkLog = require('../models/NetworkLog');
const CIAAuditLog = require('../models/CIAAuditLog');
const AgentLog = require('../models/AgentLog');

const router = express.Router();

// Validation middleware for scan logs
const validateScanLog = [
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('device_id')
    .notEmpty()
    .withMessage('Device ID is required'),
  
  body('scan_type')
    .isIn(['file_scan', 'network_scan', 'cia_audit', 'system_monitor', 'threat_detection'])
    .withMessage('Invalid scan type'),
  
  body('scan_result')
    .isIn(['clean', 'suspicious', 'threat', 'error', 'skipped'])
    .withMessage('Invalid scan result')
];

// Validation middleware for network logs
const validateNetworkLog = [
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('device_id')
    .notEmpty()
    .withMessage('Device ID is required'),
  
  body('event_type')
    .isIn(['connection', 'disconnection', 'suspicious_activity', 'port_scan', 'data_transfer', 'protocol_analysis'])
    .withMessage('Invalid event type'),
  
  body('source_ip')
    .isIP()
    .withMessage('Invalid source IP address'),
  
  body('destination_ip')
    .isIP()
    .withMessage('Invalid destination IP address')
];

// Validation middleware for CIA audit logs
const validateCIAAuditLog = [
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('device_id')
    .notEmpty()
    .withMessage('Device ID is required'),
  
  body('audit_type')
    .isIn(['confidentiality', 'integrity', 'availability', 'full_audit'])
    .withMessage('Invalid audit type'),
  
  body('overall_score')
    .isInt({ min: 0, max: 100 })
    .withMessage('Overall score must be between 0 and 100')
];

// Validation middleware for agent logs
const validateAgentLog = [
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('device_id')
    .notEmpty()
    .withMessage('Device ID is required'),
  
  body('log_level')
    .isIn(['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'])
    .withMessage('Invalid log level'),
  
  body('module')
    .isIn(['file_scan', 'network_monitor', 'cia_audit', 'threat_detection', 'system_monitor', 'agent_core'])
    .withMessage('Invalid module'),
  
  body('event_type')
    .isIn(['scan_start', 'scan_complete', 'threat_detected', 'network_event', 'audit_result', 'system_event', 'error', 'info'])
    .withMessage('Invalid event type')
];

// @route   POST /api/logs/scan
// @desc    Create a new scan log entry
// @access  Public (for agent reporting)
router.post('/scan', validateScanLog, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const scanLog = new ScanLog(req.body);
    await scanLog.save();

    logger.info(`📊 Scan log created: ${req.body.scan_type} - ${req.body.scan_result} (${req.body.user_email})`);

    // Broadcast to WebSocket clients
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastScanLog(scanLog.toObject());
    }

    res.status(201).json({
      success: true,
      message: 'Scan log created successfully',
      log_id: scanLog._id.toString()
    });

  } catch (error) {
    logger.error('Error creating scan log:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create scan log'
    });
  }
});

// @route   POST /api/logs/network
// @desc    Create a new network log entry
// @access  Public (for agent reporting)
router.post('/network', validateNetworkLog, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const networkLog = new NetworkLog(req.body);
    await networkLog.save();

    logger.info(`🌐 Network log created: ${req.body.event_type} - ${req.body.source_ip}:${req.body.source_port} -> ${req.body.destination_ip}:${req.body.destination_port} (${req.body.user_email})`);

    // Broadcast to WebSocket clients
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastNetworkLog(networkLog.toObject());
    }

    res.status(201).json({
      success: true,
      message: 'Network log created successfully',
      log_id: networkLog._id.toString()
    });

  } catch (error) {
    logger.error('Error creating network log:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create network log'
    });
  }
});

// @route   POST /api/logs/cia-audit
// @desc    Create a new CIA audit log entry
// @access  Public (for agent reporting)
router.post('/cia-audit', validateCIAAuditLog, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const ciaAuditLog = new CIAAuditLog(req.body);
    await ciaAuditLog.save();

    logger.info(`🔒 CIA audit log created: ${req.body.audit_type} - Score: ${req.body.overall_score}/100 (${req.body.user_email})`);

    // Broadcast to WebSocket clients
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastCIAAuditLog(ciaAuditLog.toObject());
    }

    res.status(201).json({
      success: true,
      message: 'CIA audit log created successfully',
      log_id: ciaAuditLog._id.toString()
    });

  } catch (error) {
    logger.error('Error creating CIA audit log:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create CIA audit log'
    });
  }
});

// @route   POST /api/logs/agent
// @desc    Create a new agent log entry
// @access  Public (for agent reporting)
router.post('/agent', validateAgentLog, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const agentLog = new AgentLog(req.body);
    await agentLog.save();

    logger.info(`🤖 Agent log created: ${req.body.module} - ${req.body.event_type} - ${req.body.log_level} (${req.body.user_email})`);

    // Broadcast to WebSocket clients
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastAgentLog(agentLog.toObject());
    }

    res.status(201).json({
      success: true,
      message: 'Agent log created successfully',
      log_id: agentLog._id.toString()
    });

  } catch (error) {
    logger.error('Error creating agent log:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create agent log'
    });
  }
});

// @route   GET /api/logs/scan
// @desc    Get scan logs for user
// @access  Private
router.get('/scan', optionalAuth, async (req, res) => {
  try {
    const {
      limit = 100,
      page = 1,
      scan_type,
      scan_result,
      threat_level,
      device_id
    } = req.query;

    // Build query
    const query = {};
    
    if (scan_type) query.scan_type = scan_type;
    if (scan_result) query.scan_result = scan_result;
    if (threat_level) query.threat_level = threat_level;
    if (device_id) query.device_id = device_id;
    
    // If user is authenticated, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    // Calculate skip value for pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Execute query
    const logs = await ScanLog.find(query)
      .sort({ scan_timestamp: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await ScanLog.countDocuments(query);

    // Transform data
    const transformedLogs = logs.map(log => ({
      id: log._id.toString(),
      ...log,
      _id: undefined
    }));

    res.json({
      logs: transformedLogs,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      total_pages: Math.ceil(total / parseInt(limit))
    });

  } catch (error) {
    logger.error('Error fetching scan logs:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch scan logs'
    });
  }
});

// @route   GET /api/logs/network
// @desc    Get network logs for user
// @access  Private
router.get('/network', optionalAuth, async (req, res) => {
  try {
    const {
      limit = 100,
      page = 1,
      event_type,
      protocol,
      is_suspicious,
      device_id
    } = req.query;

    // Build query
    const query = {};
    
    if (event_type) query.event_type = event_type;
    if (protocol) query.protocol = protocol;
    if (is_suspicious !== undefined) query.is_suspicious = is_suspicious === 'true';
    if (device_id) query.device_id = device_id;
    
    // If user is authenticated, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    // Calculate skip value for pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Execute query
    const logs = await NetworkLog.find(query)
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await NetworkLog.countDocuments(query);

    // Transform data
    const transformedLogs = logs.map(log => ({
      id: log._id.toString(),
      ...log,
      _id: undefined
    }));

    res.json({
      logs: transformedLogs,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      total_pages: Math.ceil(total / parseInt(limit))
    });

  } catch (error) {
    logger.error('Error fetching network logs:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch network logs'
    });
  }
});

// @route   PUT /api/logs/network/:id/action
// @desc    Admin action on a network log (e.g., block, quarantine)
// @access  Private (Admin)
router.put('/network/:id/action', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { id } = req.params;
    const { action, notes } = req.body;

    if (!action) {
      return res.status(400).json({
        error: 'Action required',
        message: 'action field is required'
      });
    }

    const allowed = ['allowed', 'blocked', 'monitored', 'quarantined', 'logged'];
    if (!allowed.includes(action)) {
      return res.status(400).json({
        error: 'Invalid action',
        message: `Action must be one of: ${allowed.join(', ')}`
      });
    }

    // Update via Mongoose model to keep hooks/validation
    const log = await NetworkLog.findById(id);
    if (!log) {
      return res.status(404).json({
        error: 'Network log not found',
        message: 'The specified network log does not exist'
      });
    }

    log.action_taken = action;
    if (notes !== undefined) {
      log.extra_data = { ...(log.extra_data || {}), admin_notes: notes };
    }
    await log.save();

    logger.info(`🛡️ Admin ${req.user.email} set action '${action}' on network log ${id}`);

    // Broadcast to admin room
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastNetworkLog(log.toObject());
    }

    res.json({
      success: true,
      message: `Action '${action}' applied to network log`,
      log: {
        id: log._id.toString(),
        ...log.toObject(),
        _id: undefined
      }
    });

  } catch (error) {
    logger.error(`Error applying action to network log ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to apply action to network log'
    });
  }
});

// @route   GET /api/logs/cia-audit
// @desc    Get CIA audit logs for user
// @access  Private
router.get('/cia-audit', optionalAuth, async (req, res) => {
  try {
    const {
      limit = 100,
      page = 1,
      audit_type,
      device_id
    } = req.query;

    // Build query
    const query = {};
    
    if (audit_type) query.audit_type = audit_type;
    if (device_id) query.device_id = device_id;
    
    // If user is authenticated, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    // Calculate skip value for pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Execute query
    const logs = await CIAAuditLog.find(query)
      .sort({ audit_timestamp: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await CIAAuditLog.countDocuments(query);

    // Transform data
    const transformedLogs = logs.map(log => ({
      id: log._id.toString(),
      ...log,
      _id: undefined
    }));

    res.json({
      logs: transformedLogs,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      total_pages: Math.ceil(total / parseInt(limit))
    });

  } catch (error) {
    logger.error('Error fetching CIA audit logs:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch CIA audit logs'
    });
  }
});

// @route   GET /api/logs/agent
// @desc    Get agent logs for user
// @access  Private
router.get('/agent', optionalAuth, async (req, res) => {
  try {
    const {
      limit = 100,
      page = 1,
      module,
      log_level,
      event_type,
      device_id
    } = req.query;

    // Build query
    const query = {};
    
    if (module) query.module = module;
    if (log_level) query.log_level = log_level;
    if (event_type) query.event_type = event_type;
    if (device_id) query.device_id = device_id;
    
    // If user is authenticated, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    // Calculate skip value for pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Execute query
    const logs = await AgentLog.find(query)
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await AgentLog.countDocuments(query);

    // Transform data
    const transformedLogs = logs.map(log => ({
      id: log._id.toString(),
      ...log,
      _id: undefined
    }));

    res.json({
      logs: transformedLogs,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      total_pages: Math.ceil(total / parseInt(limit))
    });

  } catch (error) {
    logger.error('Error fetching agent logs:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch agent logs'
    });
  }
});

// @route   GET /api/logs/stats/dashboard
// @desc    Get comprehensive dashboard statistics
// @access  Private
router.get('/stats/dashboard', optionalAuth, async (req, res) => {
  try {
    const userEmail = req.user && !req.user.is_admin ? req.user.email : null;

    logger.info(`Fetching dashboard stats for user: ${userEmail || 'all users'}`);

    // Get statistics from all log types
    const [scanStats, networkStats, ciaStats, agentStats] = await Promise.all([
      ScanLog.getStatistics(userEmail).catch(err => {
        logger.error('Error fetching scan stats:', err);
        return { total: 0, byScanType: [], byResult: [], byThreatLevel: [] };
      }),
      NetworkLog.getStatistics(userEmail).catch(err => {
        logger.error('Error fetching network stats:', err);
        return { total: 0, byEventType: [], byThreatLevel: [] };
      }),
      CIAAuditLog.getStatistics(userEmail).catch(err => {
        logger.error('Error fetching CIA audit stats:', err);
        return { total: 0, averageScores: {}, byAuditType: [] };
      }),
      AgentLog.getStatistics(userEmail).catch(err => {
        logger.error('Error fetching agent stats:', err);
        return { total: 0, byModule: [], byLogLevel: [] };
      })
    ]);

    // Calculate overall metrics
    const totalThreats = scanStats.totalThreats + agentStats.threatCount;
    const totalErrors = agentStats.errorCount;
    const totalSuspiciousNetwork = networkStats.suspiciousCount;
    const averageCIAScore = ciaStats.averageOverallScore;

    // Get recent activity (last 24 hours)
    const last24Hours = new Date(Date.now() - 24 * 60 * 60 * 1000);
    
    const recentScanLogs = await ScanLog.countDocuments({
      ...(userEmail && { user_email: userEmail }),
      scan_timestamp: { $gte: last24Hours }
    });

    const recentNetworkLogs = await NetworkLog.countDocuments({
      ...(userEmail && { user_email: userEmail }),
      timestamp: { $gte: last24Hours }
    });

    const recentAgentLogs = await AgentLog.countDocuments({
      ...(userEmail && { user_email: userEmail }),
      timestamp: { $gte: last24Hours }
    });

    const dashboardStats = {
      overview: {
        totalThreats,
        totalErrors,
        totalSuspiciousNetwork,
        averageCIAScore,
        recentActivity: {
          scans: recentScanLogs,
          network: recentNetworkLogs,
          agent: recentAgentLogs
        }
      },
      scan: scanStats,
      network: networkStats,
      cia: ciaStats,
      agent: agentStats
    };

    res.json(dashboardStats);

  } catch (error) {
    logger.error('Error fetching dashboard statistics:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch dashboard statistics'
    });
  }
});

// @route   GET /api/logs/recent
// @desc    Get recent logs across all types
// @access  Private
router.get('/recent', optionalAuth, async (req, res) => {
  try {
    const { limit = 50 } = req.query;
    const userEmail = req.user && !req.user.is_admin ? req.user.email : null;

    // Get recent logs from all types
    const [recentScans, recentNetwork, recentCIA, recentAgent] = await Promise.all([
      ScanLog.find(userEmail ? { user_email: userEmail } : {})
        .sort({ scan_timestamp: -1 })
        .limit(parseInt(limit))
        .lean(),
      NetworkLog.find(userEmail ? { user_email: userEmail } : {})
        .sort({ timestamp: -1 })
        .limit(parseInt(limit))
        .lean(),
      CIAAuditLog.find(userEmail ? { user_email: userEmail } : {})
        .sort({ audit_timestamp: -1 })
        .limit(parseInt(limit))
        .lean(),
      AgentLog.find(userEmail ? { user_email: userEmail } : {})
        .sort({ timestamp: -1 })
        .limit(parseInt(limit))
        .lean()
    ]);

    // Combine and sort all logs by timestamp
    const allLogs = [
      ...recentScans.map(log => ({ ...log, log_type: 'scan', timestamp: log.scan_timestamp })),
      ...recentNetwork.map(log => ({ ...log, log_type: 'network', timestamp: log.timestamp })),
      ...recentCIA.map(log => ({ ...log, log_type: 'cia_audit', timestamp: log.audit_timestamp })),
      ...recentAgent.map(log => ({ ...log, log_type: 'agent', timestamp: log.timestamp }))
    ].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
     .slice(0, parseInt(limit));

    // Transform data
    const transformedLogs = allLogs.map(log => ({
      id: log._id.toString(),
      ...log,
      _id: undefined
    }));

    res.json({
      logs: transformedLogs,
      total: transformedLogs.length
    });

  } catch (error) {
    logger.error('Error fetching recent logs:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch recent logs'
    });
  }
});

module.exports = router;
