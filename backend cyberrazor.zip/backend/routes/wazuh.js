const express = require('express');
const { logger } = require('../config/logger');

const router = express.Router();

// @route   GET /api/wazuh/alerts
// @desc    Get Wazuh security alerts
// @access  Public
router.get('/alerts', async (req, res) => {
  try {
    const { limit = 50, severity } = req.query;

    // Return mock data when Wazuh is not available
    const mockAlerts = [
      {
        id: 'wazuh_001',
        timestamp: new Date().toISOString(),
        level: '12',
        description: 'Suspicious network activity detected',
        agent: 'agent-001',
        rule: {
          level: 12,
          description: 'Network scan detected'
        },
        full_log: 'Network scan from 192.168.1.100 detected'
      },
      {
        id: 'wazuh_002',
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        level: '14',
        description: 'Failed login attempt',
        agent: 'agent-002',
        rule: {
          level: 14,
          description: 'Multiple failed login attempts'
        },
        full_log: 'Multiple failed login attempts from 10.0.0.50'
      }
    ];

    res.json({
      alerts: mockAlerts,
      message: 'Wazuh integration not available - showing mock data'
    });

  } catch (error) {
    logger.error('Error fetching Wazuh alerts:', error);
    
    // Return mock data on error
    const mockAlerts = [
      {
        id: 'wazuh_error_001',
        timestamp: new Date().toISOString(),
        level: '10',
        description: 'Wazuh integration error',
        agent: 'system',
        rule: {
          level: 10,
          description: 'Integration error'
        },
        full_log: `Wazuh integration error: ${error.message}`
      }
    ];
    
    res.json({
      alerts: mockAlerts,
      message: `Wazuh integration error: ${error.message}`
    });
  }
});

// @route   GET /api/wazuh/agents
// @desc    Get Wazuh agents status
// @access  Public
router.get('/agents', async (req, res) => {
  try {
    res.json({
      agents: [],
      message: 'Wazuh integration not available'
    });
  } catch (error) {
    logger.error('Error fetching Wazuh agents:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error fetching Wazuh agents: ${error.message}`
    });
  }
});

module.exports = router;
