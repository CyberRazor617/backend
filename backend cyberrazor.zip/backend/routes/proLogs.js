const express = require('express');
const router = express.Router();

// In-memory storage for logs (replace with database in production)
const logsStore = {
  file_scanning: [],
  network_analysis: [],
  cia_audit: [],
  all: []
};

// Maximum logs to store per category
const MAX_LOGS_PER_CATEGORY = 100;

/**
 * @route   POST /api/pro/logs
 * @desc    Receive logs from pro agent
 * @access  Private (requires access token)
 */
router.post('/logs', async (req, res) => {
  try {
    const {
      category,
      event_type,
      entity_path,
      message,
      threat_status,
      action_taken,
      remarks,
      timestamp,
      user_email,
      access_token
    } = req.body;

    // Validate required fields
    if (!category || !event_type || !access_token) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields'
      });
    }

    // Validate category
    const validCategories = ['file_scanning', 'network_analysis', 'cia_audit'];
    if (!validCategories.includes(category)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid category'
      });
    }

    // TODO: Validate access token with database
    // For now, we'll accept any token

    // Create log entry
    const logEntry = {
      id: Date.now() + Math.random(),
      category,
      event_type,
      entity_path: entity_path || 'N/A',
      message: message || '',
      threat_status: threat_status || 'N/A',
      action_taken: action_taken || 'N/A',
      remarks: remarks || '',
      timestamp: timestamp || Date.now() / 1000,
      user_email: user_email || 'Unknown'
    };

    // Store in category-specific array
    logsStore[category].push(logEntry);
    logsStore.all.push(logEntry);

    // Keep only last MAX_LOGS_PER_CATEGORY logs
    if (logsStore[category].length > MAX_LOGS_PER_CATEGORY) {
      logsStore[category].shift();
    }
    if (logsStore.all.length > MAX_LOGS_PER_CATEGORY * 3) {
      logsStore.all.shift();
    }

    console.log(`📊 Log received: [${category}] ${event_type} - ${threat_status}`);

    res.status(200).json({
      success: true,
      message: 'Log received successfully'
    });

  } catch (error) {
    console.error('Error receiving log:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to receive log'
    });
  }
});

/**
 * @route   GET /api/pro/logs
 * @desc    Get logs for a specific category
 * @access  Private
 */
router.get('/logs', async (req, res) => {
  try {
    const { category, limit } = req.query;
    const maxLimit = parseInt(limit) || 50;

    // Validate category
    const validCategories = ['file_scanning', 'network_analysis', 'cia_audit', 'all'];
    const selectedCategory = category || 'all';

    if (!validCategories.includes(selectedCategory)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid category'
      });
    }

    // Get logs from selected category
    const logs = logsStore[selectedCategory] || [];
    const limitedLogs = logs.slice(-maxLimit);

    res.status(200).json({
      success: true,
      category: selectedCategory,
      count: limitedLogs.length,
      logs: limitedLogs
    });

  } catch (error) {
    console.error('Error fetching logs:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch logs'
    });
  }
});

/**
 * @route   DELETE /api/pro/logs
 * @desc    Clear logs for a specific category
 * @access  Private
 */
router.delete('/logs', async (req, res) => {
  try {
    const { category } = req.query;

    if (category && logsStore[category]) {
      logsStore[category] = [];
      res.status(200).json({
        success: true,
        message: `Logs cleared for category: ${category}`
      });
    } else if (!category) {
      // Clear all logs
      Object.keys(logsStore).forEach(key => {
        logsStore[key] = [];
      });
      res.status(200).json({
        success: true,
        message: 'All logs cleared'
      });
    } else {
      res.status(400).json({
        success: false,
        message: 'Invalid category'
      });
    }

  } catch (error) {
    console.error('Error clearing logs:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to clear logs'
    });
  }
});

module.exports = router;
