const express = require('express');
const router = express.Router();
const Activity = require('../models/Activity');
const { logger } = require('../config/logger');
const authMiddleware = require('../middleware/auth');

// @route   GET /api/activities/recent
// @desc    Get recent activities with filtering options
// @access  Private (Admin/SuperAdmin)
router.get('/recent', authMiddleware.requireAuth, async (req, res) => {
  try {
    const { 
      limit = 50, 
      category, 
      type, 
      severity, 
      timeframe = '24h',
      page = 1 
    } = req.query;

    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    // Build filter object
    const filter = {};
    
    if (category) filter.category = category;
    if (type) filter.type = type;
    if (severity) filter.severity = severity;

    // Add timeframe filter
    if (timeframe !== 'all') {
      let startDate;
      const now = new Date();
      
      switch (timeframe) {
        case '1h':
          startDate = new Date(now.getTime() - 60 * 60 * 1000);
          break;
        case '24h':
          startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
          break;
        case '7d':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case '30d':
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
          break;
        default:
          startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      }
      
      filter.timestamp = { $gte: startDate };
    }

    const skip = (Number(page) - 1) * Number(limit);
    
    // Get activities with pagination
    const activities = await Activity.find(filter)
      .populate('performedBy', 'username email role')
      .sort({ timestamp: -1 })
      .skip(skip)
      .limit(Number(limit));

    const total = await Activity.countDocuments(filter);

    // Format activities for display
    const formattedActivities = activities.map(activity => activity.formatForDisplay());

    res.json({
      success: true,
      data: {
        activities: formattedActivities,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          pages: Math.ceil(total / Number(limit))
        },
        filters: {
          category,
          type,
          severity,
          timeframe
        }
      },
      message: 'Recent activities retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching recent activities:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching recent activities',
      error: error.message
    });
  }
});

// @route   GET /api/activities/stats
// @desc    Get activity statistics
// @access  Private (Admin/SuperAdmin)
router.get('/stats', authMiddleware.requireAuth, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    const { timeframe = '24h' } = req.query;

    // Get activity statistics
    const stats = await Activity.getActivityStats(timeframe);

    // Get total activities count
    const totalActivities = await Activity.countDocuments();

    // Get activities by category
    const categoryStats = await Activity.aggregate([
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]);

    // Get activities by severity
    const severityStats = await Activity.aggregate([
      {
        $group: {
          _id: '$severity',
          count: { $sum: 1 }
        }
      },
      {
        $sort: { count: -1 }
      }
    ]);

    res.json({
      success: true,
      data: {
        totalActivities,
        timeframe,
        activityStats: stats,
        categoryStats: categoryStats.map(cat => ({
          category: cat._id,
          count: cat.count
        })),
        severityStats: severityStats.map(sev => ({
          severity: sev._id,
          count: sev.count
        }))
      },
      message: 'Activity statistics retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching activity statistics:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching activity statistics',
      error: error.message
    });
  }
});

// @route   GET /api/activities/trends
// @desc    Get activity trends over time
// @access  Private (Admin/SuperAdmin)
router.get('/trends', authMiddleware.requireAuth, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    const { days = 7 } = req.query;

    // Get activity trends
    const trends = await Activity.getActivityTrends(Number(days));

    res.json({
      success: true,
      data: {
        trends,
        days: Number(days)
      },
      message: 'Activity trends retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching activity trends:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching activity trends',
      error: error.message
    });
  }
});

// @route   GET /api/activities/user/:userId
// @desc    Get activities for a specific user
// @access  Private (Admin/SuperAdmin)
router.get('/user/:userId', authMiddleware.requireAuth, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    const { userId } = req.params;
    const { limit = 50 } = req.query;

    // Get activities for the user
    const activities = await Activity.getActivitiesByUser(userId, Number(limit));

    // Format activities for display
    const formattedActivities = activities.map(activity => activity.formatForDisplay());

    res.json({
      success: true,
      data: {
        activities: formattedActivities,
        userId,
        total: formattedActivities.length
      },
      message: 'User activities retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching user activities:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching user activities',
      error: error.message
    });
  }
});

// @route   GET /api/activities/target/:targetType/:targetId
// @desc    Get activities for a specific target (user, admin, bug, etc.)
// @access  Private (Admin/SuperAdmin)
router.get('/target/:targetType/:targetId', authMiddleware.requireAuth, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    const { targetType, targetId } = req.params;
    const { limit = 50 } = req.query;

    // Validate target type
    const validTargetTypes = ['user', 'admin', 'bug', 'system', 'threat', 'scan'];
    if (!validTargetTypes.includes(targetType)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid target type'
      });
    }

    // Get activities for the target
    const activities = await Activity.getActivitiesByTarget(targetId, targetType, Number(limit));

    // Format activities for display
    const formattedActivities = activities.map(activity => activity.formatForDisplay());

    res.json({
      success: true,
      data: {
        activities: formattedActivities,
        targetType,
        targetId,
        total: formattedActivities.length
      },
      message: 'Target activities retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching target activities:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching target activities',
      error: error.message
    });
  }
});

// @route   GET /api/activities/dashboard
// @desc    Get activities for dashboard display
// @access  Private (Admin/SuperAdmin)
router.get('/dashboard', authMiddleware.requireAuth, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    const { limit = 20 } = req.query;

    // Get recent activities for dashboard
    const activities = await Activity.getRecentActivities(Number(limit));

    // Format activities for display
    const formattedActivities = activities.map(activity => activity.formatForDisplay());

    // Get activity summary
    const summary = await Activity.aggregate([
      {
        $group: {
          _id: '$type',
          count: { $sum: 1 },
          lastActivity: { $max: '$timestamp' }
        }
      },
      {
        $sort: { count: -1 }
      },
      {
        $limit: 10
      }
    ]);

    res.json({
      success: true,
      data: {
        activities: formattedActivities,
        summary: summary.map(item => ({
          type: item._id,
          count: item.count,
          lastActivity: item.lastActivity
        })),
        total: formattedActivities.length
      },
      message: 'Dashboard activities retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching dashboard activities:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching dashboard activities',
      error: error.message
    });
  }
});

// @route   GET /api/activities/real-time
// @desc    Get real-time activities (for WebSocket/SSE)
// @access  Private (Admin/SuperAdmin)
router.get('/real-time', authMiddleware.requireAuth, async (req, res) => {
  try {
    // Check if user has admin privileges
    if (!req.user.is_admin) {
      return res.status(403).json({
        success: false,
        message: 'Admin privileges required'
      });
    }

    const { since } = req.query;
    const sinceDate = since ? new Date(since) : new Date(Date.now() - 5 * 60 * 1000); // Default: last 5 minutes

    // Get activities since the specified time
    const activities = await Activity.find({
      timestamp: { $gte: sinceDate }
    })
      .populate('performedBy', 'username email role')
      .sort({ timestamp: -1 })
      .limit(100);

    // Format activities for display
    const formattedActivities = activities.map(activity => activity.formatForDisplay());

    res.json({
      success: true,
      data: {
        activities: formattedActivities,
        since: sinceDate,
        total: formattedActivities.length
      },
      message: 'Real-time activities retrieved successfully'
    });

  } catch (error) {
    logger.error('Error fetching real-time activities:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching real-time activities',
      error: error.message
    });
  }
});

module.exports = router;
