const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const Threat = require('../models/Threat');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const { sendThreatAlertEmail } = require('../services/emailService');

const router = express.Router();

// Helper: parse severity query param into a form usable by Mongo queries
const parseSeverityParam = (sev) => {
  if (!sev && sev !== 0) return null
  try {
    if (Array.isArray(sev)) {
      return { $in: sev.map(s => String(s).toLowerCase()) }
    }
    const s = String(sev)
    if (s.includes(',')) {
      return { $in: s.split(',').map(x => x.trim().toLowerCase()) }
    }
    return String(sev).toLowerCase()
  } catch (e) {
    return sev
  }
}

// Validation middleware
const validateThreatReport = [
  body('device_id')
    .notEmpty()
    .withMessage('Device ID is required'),
  
  body('threat_type')
    .optional()
    .isString()
    .withMessage('Threat type must be a string'),
  
  body('confidence_score')
    .optional()
    .isFloat({ min: 0, max: 1 })
    .withMessage('Confidence score must be between 0 and 1'),
  
  body('source')
    .optional()
    .isString()
    .withMessage('Source must be a string'),
  
  body('action_taken')
    .optional()
    .isString()
    .withMessage('Action taken must be a string'),
  
  body('severity')
    .optional()
    .isString()
    .withMessage('Severity must be a string')
];

// @route   POST /api/threats/agent
// @desc    Report a threat from agent (flexible validation)
// @access  Public
router.post('/agent', async (req, res) => {
  try {
    const {
      device_id,
      threat_type = 'other',
      confidence_score = 0.5,
      source = 'ai_analysis',
      details = {},
      action_taken = 'monitored',
      severity = 'medium',
      user_email = 'unknown'
    } = req.body;

    if (!device_id) {
      return res.status(400).json({
        error: 'Device ID is required'
      });
    }

    // Extract file information from details if available
    const file_path = details.file_path || 'Unknown file';
    const ai_verdict = details.verdict || 'Unknown';
    const ai_confidence = details.confidence || 'Unknown';
    const ai_reason = details.reason || 'No reason provided';

    // Create new threat
    const threat = new Threat({
      device_id,
      file_path,
      threat_type,
      confidence_score,
      source,
      details: details || {},
      action_taken,
      severity,
      ai_verdict,
      ai_confidence,
      ai_reason,
      user_email: user_email || 'unknown'
    });

    await threat.save();

    logger.info(`🚨 AGENT THREAT REPORTED: ${file_path} - ${ai_verdict || 'Unknown'} (${severity})`);
    logger.info(`   Device: ${device_id}`);
    logger.info(`   Type: ${threat_type}`);
    logger.info(`   Confidence: ${ai_confidence || 'N/A'}`);
    logger.info(`   Reason: ${ai_reason || 'N/A'}`);

    // Broadcast real-time updates via WebSocket service (if available)
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        const threatPayload = {
          id: threat._id.toString(),
          device_id: threat.device_id,
          file_path: threat.file_path,
          threat_type: threat.threat_type,
          severity: threat.severity,
          status: threat.status,
          user_email: threat.user_email,
          created_at: threat.created_at
        };

        wsService.sendToUser(threat.user_email, {
          type: 'threat_update',
          data: threatPayload,
          timestamp: new Date().toISOString()
        });

        wsService.sendToRoom('admin', {
          type: 'threat_update',
          data: threatPayload,
          timestamp: new Date().toISOString()
        });

        const stats = await Threat.getStatistics({ user_email: threat.user_email });
        const dashboardData = {
          overview: {
            totalThreats: stats.total || stats.total_threats || 0,
            totalErrors: 0,
            totalSuspiciousNetwork: stats.bySeverity?.suspicious || 0,
            recentActivity: {
              scans: stats.threats_today || 0,
              network: 0,
              agent: stats.total || stats.total_threats || 0
            }
          },
          scan: {
            averageScanTime: 150,
            byThreatLevel: {
              critical: stats.bySeverity?.critical || 0,
              high: stats.bySeverity?.high || 0,
              medium: stats.bySeverity?.medium || 0,
              low: stats.bySeverity?.low || 0,
              none: stats.bySeverity?.none || 0
            },
            byResult: {
              clean: 0,
              suspicious: stats.bySeverity?.suspicious || 0,
              threat: stats.bySeverity?.threat || 0,
              error: 0
            }
          },
          network: {
            uniqueConnections: 0,
            totalDataTransferred: 0,
            byEventType: {}
          }
        };

        wsService.sendToUser(threat.user_email, {
          type: 'dashboard_update',
          data: dashboardData,
          timestamp: new Date().toISOString()
        });
      }
    } catch (wsError) {
      logger.error('WebSocket broadcast error after agent threat create:', wsError);
    }

    res.json({
      success: true,
      message: 'Threat reported successfully',
      threat_id: threat._id
    });

  } catch (error) {
    logger.error('Error reporting agent threat:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to report threat'
    });
  }
});

// @route   POST /api/threats
// @desc    Report a new threat
// @access  Public (for agent reporting)
router.post('/', validateThreatReport, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const {
      device_id,
      threat_type = 'other',
      confidence_score = 0.5,
      source = 'ai_analysis',
      details = {},
      action_taken = 'monitored',
      severity = 'medium',
      user_email = 'unknown'
    } = req.body;

    // Extract file information from details if available
    const file_path = details.file_path || 'Unknown file';
    const ai_verdict = details.verdict || 'Unknown';
    const ai_confidence = details.confidence || 'Unknown';
    const ai_reason = details.reason || 'No reason provided';

    // Create new threat
    const threat = new Threat({
      device_id,
      file_path,
      threat_type,
      confidence_score,
      source,
      details: details || {},
      action_taken,
      severity,
      ai_verdict,
      ai_confidence,
      ai_reason,
      user_email: user_email || 'unknown'
    });

    await threat.save();

    logger.info(`🚨 THREAT REPORTED: ${file_path} - ${ai_verdict || 'Unknown'} (${severity})`);
    logger.info(`   Device: ${device_id}`);
    logger.info(`   Type: ${threat_type}`);
    logger.info(`   Confidence: ${ai_confidence || 'N/A'}`);
    logger.info(`   Reason: ${ai_reason || 'N/A'}`);

    // Send threat alert email if user email is provided
    if (user_email && user_email !== 'unknown') {
      try {
        await sendThreatAlertEmail(user_email, {
          file_path,
          threat_type,
          severity,
          confidence_score,
          action_taken,
          ai_verdict,
          ai_confidence
        });
        logger.info(`📧 Threat alert email sent to: ${user_email}`);
      } catch (emailError) {
        logger.error(`❌ Failed to send threat alert email: ${emailError.message}`);
      }
    }

    // Broadcast real-time updates via WebSocket service (if available)
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        const threatPayload = {
          id: threat._id.toString(),
          device_id: threat.device_id,
          file_path: threat.file_path,
          threat_type: threat.threat_type,
          severity: threat.severity,
          status: threat.status,
          user_email: threat.user_email,
          created_at: threat.created_at
        };

        // Send an immediate threat update to the affected user and admin room
        wsService.sendToUser(threat.user_email, {
          type: 'threat_update',
          data: threatPayload,
          timestamp: new Date().toISOString()
        });

        wsService.sendToRoom('admin', {
          type: 'threat_update',
          data: threatPayload,
          timestamp: new Date().toISOString()
        });

        // Also broadcast a lightweight dashboard update for the user
        const stats = await Threat.getStatistics({ user_email: threat.user_email });
        const dashboardData = {
          overview: {
            totalThreats: stats.total || stats.total_threats || 0,
            totalErrors: 0,
            totalSuspiciousNetwork: stats.bySeverity?.suspicious || 0,
            recentActivity: {
              scans: stats.threats_today || 0,
              network: 0,
              agent: stats.total || stats.total_threats || 0
            }
          },
          scan: {
            averageScanTime: 150,
            byThreatLevel: {
              critical: stats.bySeverity?.critical || 0,
              high: stats.bySeverity?.high || 0,
              medium: stats.bySeverity?.medium || 0,
              low: stats.bySeverity?.low || 0,
              none: stats.bySeverity?.none || 0
            },
            byResult: {
              clean: 0,
              suspicious: stats.bySeverity?.suspicious || 0,
              threat: stats.bySeverity?.threat || 0,
              error: 0
            }
          },
          network: {
            uniqueConnections: 0,
            totalDataTransferred: 0,
            byEventType: {}
          }
        };

        wsService.sendToUser(threat.user_email, {
          type: 'dashboard_update',
          data: dashboardData,
          timestamp: new Date().toISOString()
        });
      }
    } catch (wsError) {
      logger.error('WebSocket broadcast error after threat create:', wsError);
    }

    res.status(201).json({
      success: true,
      message: 'Threat reported successfully',
      threat_id: threat._id.toString()
    });

  } catch (error) {
    logger.error('Threat reporting error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to report threat'
    });
  }
});

// @route   GET /api/threats
// @desc    Get all threats (with optional filtering)
// @access  Private
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      limit = 100,
      page = 1,
      severity,
      status,
      threat_type,
      device_id,
      user_email
    } = req.query;

    // Build query
    const query = {};
    
    // Support flexible severity filtering:
    // - single value (e.g. severity=high)
    // - repeated params (severity=high&severity=critical)
    // - comma-separated list (severity=high,critical)
    const parsedSeverity = parseSeverityParam(severity)
    if (parsedSeverity) query.severity = parsedSeverity
    if (status) query.status = status;
    if (threat_type) query.threat_type = threat_type;
    if (device_id) query.device_id = device_id;
    
    // Filter out removed, quarantined, and approved files by default unless status is explicitly requested
    if (!status) {
      query.status = { $nin: ['removed', 'quarantined', 'approved'] };
    }
    
    // If user is authenticated, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    } else if (user_email) {
      query.user_email = user_email;
    }

    // Calculate skip value for pagination
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Execute query
    const threats = await Threat.find(query)
      .sort({ created_at: -1 })
      .skip(skip)
      .limit(parseInt(limit))
      .lean();

    // Get total count for pagination
    const total = await Threat.countDocuments(query);

    // Transform data
    const transformedThreats = threats.map(threat => ({
      id: threat._id.toString(),
      ...threat,
      _id: undefined
    }));

    res.json({
      threats: transformedThreats,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      total_pages: Math.ceil(total / parseInt(limit))
    });

  } catch (error) {
    logger.error('Error fetching threats:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch threats'
    });
  }
});

// @route   GET /api/threats/stats/summary
// @desc    Get threat statistics
// @access  Private
router.get('/stats/summary', optionalAuth, async (req, res) => {
  try {
    let query = {};
    
    // If user is authenticated and not admin, filter by their email
    if (req.user && !req.user.is_admin) {
      query.user_email = req.user.email;
    }

    const stats = await Threat.getStatistics(query);
    
    res.json(stats);

  } catch (error) {
    logger.error('Error fetching threat stats:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch threat statistics'
    });
  }
});

// @route   GET /api/threats/:id
// @desc    Get specific threat details
// @access  Private
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const { id } = req.params;
    
    const threat = await Threat.findById(id);
    if (!threat) {
      return res.status(404).json({
        error: 'Threat not found',
        message: 'The specified threat does not exist'
      });
    }

    // Check if user has access to this threat
    if (req.user && !req.user.is_admin && threat.user_email !== req.user.email) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You do not have permission to view this threat'
      });
    }

    const threatData = {
      id: threat._id.toString(),
      ...threat.toObject(),
      _id: undefined
    };

    res.json(threatData);

  } catch (error) {
    logger.error(`Error fetching threat ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch threat details'
    });
  }
});

// @route   PUT /api/threats/:id/status
// @desc    Update threat status
// @access  Private
router.put('/:id/status', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes, resolved_by } = req.body;

    if (!status) {
      return res.status(400).json({
        error: 'Status required',
        message: 'Status field is required'
      });
    }

    const threat = await Threat.findById(id);
    if (!threat) {
      return res.status(404).json({
        error: 'Threat not found',
        message: 'The specified threat does not exist'
      });
    }

    // Check if user has access to this threat
    if (!req.user.is_admin && threat.user_email !== req.user.email) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You do not have permission to update this threat'
      });
    }

    // Update threat
    const updateData = { status };
    if (notes !== undefined) updateData.notes = notes;
    if (resolved_by !== undefined) updateData.resolved_by = resolved_by;

    const updatedThreat = await Threat.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true }
    );

    logger.info(`✅ Threat ${id} status updated to ${status} by ${req.user.email}`);

    // Broadcast update via WebSocket
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        const payload = {
          id: updatedThreat._id.toString(),
          status: updatedThreat.status,
          action: status,
          user_email: updatedThreat.user_email,
          updated_at: updatedThreat.updated_at
        };

        // Notify the owner
        wsService.sendToUser(updatedThreat.user_email, {
          type: 'threat_update',
          data: payload,
          timestamp: new Date().toISOString()
        });

        // Notify admins
        wsService.sendToRoom('admin', {
          type: 'threat_update',
          data: payload,
          timestamp: new Date().toISOString()
        });
      }
    } catch (wsErr) {
      logger.error('WebSocket broadcast error after status update:', wsErr);
    }

    res.json({
      success: true,
      message: `Threat status updated to ${status}`,
      threat: {
        id: updatedThreat._id.toString(),
        ...updatedThreat.toObject(),
        _id: undefined
      }
    });

  } catch (error) {
    logger.error(`Error updating threat ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to update threat status'
    });
  }
});

// @route   PUT /api/threats/:id/action
// @desc    Perform admin action on a threat (e.g., quarantine, block)
// @access  Private (Admin)
router.put('/:id/action', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { id } = req.params;
    const { action, notes } = req.body;

    if (!action) {
      return res.status(400).json({
        error: 'Action required',
        message: 'action field is required'
      });
    }

    // Validate action
    const allowed = ['blocked', 'quarantined', 'monitored', 'ignored', 'investigating'];
    if (!allowed.includes(action)) {
      return res.status(400).json({
        error: 'Invalid action',
        message: `Action must be one of: ${allowed.join(', ')}`
      });
    }

    const threat = await Threat.findById(id);
    if (!threat) {
      return res.status(404).json({
        error: 'Threat not found',
        message: 'The specified threat does not exist'
      });
    }

    threat.action_taken = action;
    if (notes !== undefined) threat.notes = notes;
    // Optionally set status based on action
    if (action === 'quarantined' || action === 'blocked') {
      threat.status = 'resolved';
      threat.resolved_by = req.user.email;
      threat.resolved_at = new Date();
    }
    await threat.save();

    logger.info(`🛡️ Admin ${req.user.email} set action '${action}' on threat ${id}`);

    // Broadcast to admins
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastThreatAlert({
        id: threat._id.toString(),
        ...threat.toObject(),
        _id: undefined
      });
    }

    res.json({
      success: true,
      message: `Action '${action}' applied to threat`,
      threat: {
        id: threat._id.toString(),
        ...threat.toObject(),
        _id: undefined
      }
    });

  } catch (error) {
    logger.error(`Error applying action to threat ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to apply action to threat'
    });
  }
});

// @route   PATCH /api/threats/:id
// @desc    Update threat status (for user actions like remove, approve, quarantine)
// @access  Private
router.patch('/:id', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, action_taken, action_timestamp } = req.body;

    const threat = await Threat.findById(id);
    if (!threat) {
      return res.status(404).json({
        error: 'Threat not found',
        message: 'The specified threat does not exist'
      });
    }

    // Check if user has access to this threat
    if (!req.user.is_admin && threat.user_email !== req.user.email) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You do not have permission to update this threat'
      });
    }

    // Update threat with new status
    if (status !== undefined) threat.status = status;
    if (action_taken !== undefined) threat.action_taken = action_taken;
    if (action_timestamp !== undefined) threat.action_timestamp = action_timestamp;
    
    await threat.save();

    logger.info(`✅ Threat ${id} updated to status ${status} by ${req.user.email}`);

    // Broadcast update via WebSocket
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        const payload = {
          id: threat._id.toString(),
          status: threat.status,
          action_taken: threat.action_taken,
          user_email: threat.user_email,
          updated_at: threat.updated_at
        };

        wsService.sendToUser(threat.user_email, {
          type: 'threat_update',
          data: payload,
          timestamp: new Date().toISOString()
        });

        wsService.sendToRoom('admin', {
          type: 'threat_update',
          data: payload,
          timestamp: new Date().toISOString()
        });
      }
    } catch (wsErr) {
      logger.error('WebSocket broadcast error after PATCH update:', wsErr);
    }

    res.json({
      success: true,
      message: `Threat status updated to ${status}`,
      threat: {
        id: threat._id.toString(),
        ...threat.toObject(),
        _id: undefined
      }
    });

  } catch (error) {
    logger.error(`Error updating threat ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to update threat'
    });
  }
});

// @route   DELETE /api/threats/:id
// @desc    Delete a threat (admin only)
// @access  Private (Admin)
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { id } = req.params;
    
    const threat = await Threat.findByIdAndDelete(id);
    if (!threat) {
      return res.status(404).json({
        error: 'Threat not found',
        message: 'The specified threat does not exist'
      });
    }

    logger.info(`🗑️ Threat ${id} deleted by admin ${req.user.email}`);

    res.json({
      success: true,
      message: 'Threat deleted successfully'
    });

  } catch (error) {
    logger.error(`Error deleting threat ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to delete threat'
    });
  }
});

// @route   POST /api/threats/bulk-update
// @desc    Bulk update threat statuses (admin only)
// @access  Private (Admin)
router.post('/bulk-update', requireAuth, async (req, res) => {
  try {
    // Check if user is admin
    if (!req.user.is_admin) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    const { threat_ids, status, notes } = req.body;

    if (!threat_ids || !Array.isArray(threat_ids) || threat_ids.length === 0) {
      return res.status(400).json({
        error: 'Invalid input',
        message: 'threat_ids array is required'
      });
    }

    if (!status) {
      return res.status(400).json({
        error: 'Status required',
        message: 'Status field is required'
      });
    }

    // Update threats
    const updateData = { status };
    if (notes !== undefined) updateData.notes = notes;

    const result = await Threat.updateMany(
      { _id: { $in: threat_ids } },
      updateData
    );

    logger.info(`✅ Bulk updated ${result.modifiedCount} threats to status ${status} by admin ${req.user.email}`);

    res.json({
      success: true,
      message: `Successfully updated ${result.modifiedCount} threats`,
      updated_count: result.modifiedCount
    });

  } catch (error) {
    logger.error('Bulk update threats error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to bulk update threats'
    });
  }
});

// @route   PUT /api/threats/:id/user-action
// @desc    Perform user action on a threat (approve, quarantine, remove)
// @access  Private (User)
router.put('/:id/user-action', requireAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const { action, notes } = req.body;

    if (!action) {
      return res.status(400).json({
        error: 'Action required',
        message: 'action field is required'
      });
    }

    // Validate action for users
    const userAllowed = ['monitored', 'quarantined', 'blocked'];
    if (!userAllowed.includes(action)) {
      return res.status(400).json({
        error: 'Invalid action',
        message: `Action must be one of: ${userAllowed.join(', ')}`
      });
    }

    const threat = await Threat.findById(id);
    if (!threat) {
      return res.status(404).json({
        error: 'Threat not found',
        message: 'The specified threat does not exist'
      });
    }

    // Check if user owns this threat (by email)
    if (threat.user_email !== req.user.email) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You can only manage your own threats'
      });
    }

    threat.action_taken = action;
    if (notes !== undefined) threat.notes = notes;
    
    // Set status based on action
    if (action === 'quarantined') {
      threat.status = 'quarantined';
    } else if (action === 'blocked') {
      threat.status = 'blocked';
    } else if (action === 'monitored') {
      threat.status = 'approved';
    }
    
    threat.resolved_by = req.user.email;
    threat.resolved_at = new Date();
    await threat.save();

    logger.info(`👤 User ${req.user.email} set action '${action}' on threat ${id}`);

    // Broadcast user action via WebSocket
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        const payload = {
          id: threat._id.toString(),
          action_taken: threat.action_taken,
          status: threat.status,
          user_email: threat.user_email,
          resolved_at: threat.resolved_at
        };

        wsService.sendToUser(threat.user_email, {
          type: 'threat_update',
          data: payload,
          timestamp: new Date().toISOString()
        });

        wsService.sendToRoom('admin', {
          type: 'threat_update',
          data: payload,
          timestamp: new Date().toISOString()
        });
      }
    } catch (wsErr) {
      logger.error('WebSocket broadcast error after user action:', wsErr);
    }

    res.json({
      success: true,
      message: `Action '${action}' applied to threat`,
      threat: {
        id: threat._id.toString(),
        ...threat.toObject(),
      }
    });

  } catch (error) {
    logger.error(`Error applying user action to threat ${req.params.id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to apply action to threat'
    });
  }
});

module.exports = router;
// Export helper for unit tests
module.exports.parseSeverityParam = parseSeverityParam;
