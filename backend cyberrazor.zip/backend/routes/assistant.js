const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const { requireAuth, optionalAuth } = require('../middleware/auth');
const Threat = require('../models/Threat');
const fuzzyMatcher = require('../utils/fuzzyMatcher');

const router = express.Router();

// Initialize fuzzy matcher on startup
(async () => {
  try {
    const loaded = await fuzzyMatcher.loadTrainingData();
    if (loaded) {
      const stats = fuzzyMatcher.getStats();
      logger.info(`✅ Fuzzy matcher initialized with ${stats.totalQuestions} Q&A pairs`);
    } else {
      logger.warn('⚠️ Fuzzy matcher failed to load training data');
    }
  } catch (error) {
    logger.error('❌ Fuzzy matcher initialization error:', error);
  }
})();

// Validation middleware
const validateChatMessage = [
  body('message')
    .notEmpty()
    .withMessage('Message is required')
    .isLength({ min: 1, max: 1000 })
    .withMessage('Message must be between 1 and 1000 characters')
];

// @route   POST /api/assistant/chat
// @desc    Chat with CyberRazor AI assistant
// @access  Private
router.post('/chat', requireAuth, validateChatMessage, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { message } = req.body;
    const userEmail = req.user.email;
    
    logger.info(`🤖 Assistant chat request from ${userEmail}: ${message.substring(0, 100)}...`);

    // Get user's recent threats for context
    const recentThreats = await Threat.find({ user_email: userEmail })
      .sort({ created_at: -1 })
      .limit(5)
      .lean();

    // Try fuzzy matching first with train.json data
    let response = null;
    let matchInfo = null;
    
    if (fuzzyMatcher.loaded) {
      const match = fuzzyMatcher.findBestMatch(message, 0.55);
      if (match) {
        response = match.answer;
        matchInfo = {
          matchType: match.matchType,
          score: match.score,
          confidence: match.confidence,
          matchedQuestion: match.matchedQuestion
        };
        logger.info(`✅ Fuzzy match found (${match.matchType}, score: ${match.score.toFixed(3)}, confidence: ${match.confidence})`);
      } else {
        logger.info('ℹ️ No fuzzy match found, using fallback response');
      }
    }

    // Fallback to context-aware response if no match found
    if (!response) {
      response = generateAIResponse(message, recentThreats, userEmail);
    }

    // Log the interaction
    logger.info(`🤖 Assistant response generated for ${userEmail}`);

    res.json({
      response: response,
      timestamp: new Date().toISOString(),
      context: {
        recent_threats_count: recentThreats.length,
        user_email: userEmail
      },
      match: matchInfo
    });

  } catch (error) {
    logger.error('Assistant chat error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to process chat message'
    });
  }
});

// Helper function to generate AI responses
function generateAIResponse(message, recentThreats, userEmail) {
  const lowerMessage = message.toLowerCase();
  
  // Base response for CyberRazor SOAR assistant
  let response = 'I\'m CyberRazor AI, your cybersecurity SOAR assistant. I can help you analyze threats, understand alerts from your CyberRazor tools, and provide security recommendations. What specific security concern would you like to discuss?';

  // Check for threat-related queries
  if (lowerMessage.includes('alert') || lowerMessage.includes('threat')) {
    if (recentThreats.length > 0) {
      const criticalThreats = recentThreats.filter(t => t.severity === 'critical');
      const highThreats = recentThreats.filter(t => t.severity === 'high');
      
      if (criticalThreats.length > 0) {
        response = `I can see you have ${criticalThreats.length} critical threat(s) that require immediate attention. The most recent critical threat is: "${criticalThreats[0].ai_verdict || criticalThreats[0].threat_type}". I recommend reviewing the AI verdict and taking immediate action. Would you like me to explain the threat details?`;
      } else if (highThreats.length > 0) {
        response = `You have ${highThreats.length} high-priority threat(s) that need attention. The most recent is: "${highThreats[0].ai_verdict || highThreats[0].threat_type}". I recommend reviewing these threats and implementing appropriate security measures.`;
      } else {
        response = `I can see you have ${recentThreats.length} recent threat(s) in your system. I can help you analyze these threats and provide recommendations for incident response. Would you like me to explain any specific threat details?`;
      }
    } else {
      response = 'I can help you analyze security alerts from your CyberRazor SOAR system. Based on your recent threats, I recommend reviewing the AI verdicts and confidence scores. For critical alerts, immediate action is required. Would you like me to explain any specific threat details?';
    }
  }
  
  // Malware-related queries
  else if (lowerMessage.includes('malware') || lowerMessage.includes('virus')) {
    const malwareThreats = recentThreats.filter(t => 
      t.threat_type?.toLowerCase().includes('malware') || 
      t.ai_verdict?.toLowerCase().includes('malware') ||
      t.file_path?.toLowerCase().includes('malware')
    );
    
    if (malwareThreats.length > 0) {
      response = `I found ${malwareThreats.length} malware-related threat(s) in your recent alerts. CyberRazor's AI analysis has detected potential malware with confidence scores. I recommend quarantining suspicious files and running a full system scan. The SOAR system can automate these responses.`;
    } else {
      response = 'CyberRazor\'s AI analysis can detect various malware types. If you\'re seeing malware alerts, check the AI verdict and confidence score. I recommend quarantining suspicious files and running a full system scan. The SOAR system can automate these responses.';
    }
  }
  
  // Network-related queries
  else if (lowerMessage.includes('network') || lowerMessage.includes('traffic')) {
    response = 'Network monitoring is a key feature of CyberRazor SOAR. Unusual traffic patterns are automatically flagged. I can help you understand network alerts and suggest appropriate responses based on the threat level.';
  }
  
  // Password/security queries
  else if (lowerMessage.includes('password') || lowerMessage.includes('security')) {
    response = 'Password security is crucial for your organization. CyberRazor can monitor for password policy violations and suspicious login attempts. I recommend enabling multi-factor authentication and using strong, unique passwords.';
  }
  
  // SOAR/CyberRazor specific queries
  else if (lowerMessage.includes('soar') || lowerMessage.includes('cyberrazor')) {
    response = 'CyberRazor SOAR (Security Orchestration, Automation, and Response) helps automate your security operations. I can explain how the system works, help you understand alerts, and guide you through incident response procedures.';
  }
  
  // Help queries
  else if (lowerMessage.includes('help') || lowerMessage.includes('what can you do')) {
    response = 'As your CyberRazor SOAR assistant, I can help you with:\n• Analyzing security alerts and AI verdicts\n• Explaining threat intelligence from your system\n• Providing incident response guidance\n• Understanding SOAR automation workflows\n• Security best practices and recommendations\n• Troubleshooting CyberRazor tool issues';
  }
  
  // Automation queries
  else if (lowerMessage.includes('automation') || lowerMessage.includes('workflow')) {
    response = 'CyberRazor SOAR automates security workflows to reduce response time. The system can automatically quarantine threats, block malicious IPs, and escalate critical alerts. I can help you understand and configure these automation rules.';
  }
  
  // Incident response queries
  else if (lowerMessage.includes('incident') || lowerMessage.includes('response')) {
    if (recentThreats.length > 0) {
      response = `Incident response is streamlined with CyberRazor SOAR. You have ${recentThreats.length} recent threat(s) that may require incident response. The system provides step-by-step guidance for different threat types. I can walk you through the response process for any active incidents in your environment.`;
    } else {
      response = 'Incident response is streamlined with CyberRazor SOAR. The system provides step-by-step guidance for different threat types. I can walk you through the response process for any active incidents in your environment.';
    }
  }
  
  // Statistics queries
  else if (lowerMessage.includes('stat') || lowerMessage.includes('summary') || lowerMessage.includes('overview')) {
    if (recentThreats.length > 0) {
      const severityCounts = recentThreats.reduce((acc, threat) => {
        acc[threat.severity] = (acc[threat.severity] || 0) + 1;
        return acc;
      }, {});
      
      response = `Here's a summary of your recent threats:\n• Total recent threats: ${recentThreats.length}\n• Critical: ${severityCounts.critical || 0}\n• High: ${severityCounts.high || 0}\n• Medium: ${severityCounts.medium || 0}\n• Low: ${severityCounts.low || 0}\n\nI recommend focusing on critical and high-priority threats first.`;
    } else {
      response = 'You currently have no recent threats in your system. This is good news! However, I recommend maintaining regular security monitoring and staying vigilant for potential threats.';
    }
  }

  return response;
}

// @route   GET /api/assistant/context
// @desc    Get user's threat context for assistant
// @access  Private
router.get('/context', requireAuth, async (req, res) => {
  try {
    const userEmail = req.user.email;
    
    // Get user's recent threats
    const recentThreats = await Threat.find({ user_email: userEmail })
      .sort({ created_at: -1 })
      .limit(10)
      .lean();

    // Get threat statistics
    const totalThreats = await Threat.countDocuments({ user_email: userEmail });
    const activeThreats = await Threat.countDocuments({ 
      user_email: userEmail, 
      status: { $in: ['active', 'investigating'] } 
    });
    const resolvedThreats = await Threat.countDocuments({ 
      user_email: userEmail, 
      status: 'resolved' 
    });

    // Get severity breakdown
    const severityBreakdown = await Threat.aggregate([
      { $match: { user_email: userEmail } },
      { $group: { _id: '$severity', count: { $sum: 1 } } }
    ]);

    const context = {
      user_email: userEmail,
      recent_threats: recentThreats.map(threat => ({
        id: threat._id.toString(),
        threat_type: threat.threat_type,
        severity: threat.severity,
        ai_verdict: threat.ai_verdict,
        created_at: threat.created_at,
        status: threat.status
      })),
      statistics: {
        total_threats: totalThreats,
        active_threats: activeThreats,
        resolved_threats: resolvedThreats,
        severity_breakdown: severityBreakdown.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {})
      }
    };

    res.json(context);

  } catch (error) {
    logger.error('Assistant context error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to get assistant context'
    });
  }
});

// @route   POST /api/assistant/search
// @desc    Search for multiple matching answers
// @access  Private
router.post('/search', requireAuth, validateChatMessage, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { message } = req.body;
    const topN = parseInt(req.query.top) || 3;
    const threshold = parseFloat(req.query.threshold) || 0.4;

    if (!fuzzyMatcher.loaded) {
      return res.status(503).json({
        error: 'Service unavailable',
        message: 'Fuzzy matcher not loaded'
      });
    }

    const matches = fuzzyMatcher.findTopMatches(message, topN, threshold);

    res.json({
      query: message,
      matches: matches,
      count: matches.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Assistant search error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to search for matches'
    });
  }
});

// @route   GET /api/assistant/stats
// @desc    Get fuzzy matcher statistics
// @access  Private
router.get('/stats', requireAuth, async (req, res) => {
  try {
    const stats = fuzzyMatcher.getStats();
    res.json({
      ...stats,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    logger.error('Assistant stats error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to get stats'
    });
  }
});

module.exports = router;
