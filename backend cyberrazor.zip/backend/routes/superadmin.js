const express = require('express');
const router = express.Router();
const User = require('../models/User');
const BugReport = require('../models/BugReport');
const authMiddleware = require('../middleware/auth');
const ActivityTracker = require('../middleware/activityTracker');

// @desc    Get all admins
// @route   GET /api/superadmin/admins
// @access  Private (SuperAdmin only)
router.get('/admins', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const admins = await User.find({ role: 'admin' }).sort({ createdAt: -1 });
    
    res.json({
      success: true,
      data: admins,
      message: 'Admins retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Create new admin
// @route   POST /api/superadmin/admins
// @access  Private (SuperAdmin only)
router.post('/admins', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { username, email, password } = req.body;

    // Validate input
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide username, email, and password'
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { username }]
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email or username already exists'
      });
    }

    // Create new admin
    const admin = new User({
      username,
      email,
      password,
      role: 'admin',
      is_admin: true,
      is_active: true,
      status: 'active',
      createdBy: req.user._id,
      activation_key: require('crypto').randomBytes(32).toString('hex')
    });

    await admin.save();

    // Track activity
    const activity = await ActivityTracker.trackAdminCreated(admin, req.user, req);

    // Broadcast activity update
    if (req.app.locals.wsService && activity) {
      await ActivityTracker.broadcastActivity(activity, req.app.locals.wsService);
    }

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'admin_created',
        data: {
          admin: {
            id: admin._id,
            username: admin.username,
            email: admin.email,
            role: admin.role,
            isActive: admin.is_active,
            createdAt: admin.createdAt
          },
          createdBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.status(201).json({
      success: true,
      data: admin,
      message: 'Admin created successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update admin
// @route   PUT /api/superadmin/admins/:id
// @access  Private (SuperAdmin only)
router.put('/admins/:id', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    // Remove sensitive fields
    delete updates.password;
    delete updates.role;
    delete updates.createdBy;

    const admin = await User.findByIdAndUpdate(
      id,
      { ...updates, updated_at: new Date() },
      { new: true, runValidators: true }
    );

    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found'
      });
    }

    // Track activity
    await ActivityTracker.trackAdminUpdated(admin, req.user, updates, req);

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'admin_updated',
        data: {
          admin: {
            id: admin._id,
            username: admin.username,
            email: admin.email,
            role: admin.role,
            isActive: admin.is_active,
            updatedAt: admin.updated_at
          },
          updatedBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.json({
      success: true,
      data: admin,
      message: 'Admin updated successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Toggle admin status
// @route   PATCH /api/superadmin/admins/:id/toggle-status
// @access  Private (SuperAdmin only)
router.patch('/admins/:id/toggle-status', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;

    const admin = await User.findById(id);
    
    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found'
      });
    }

    // Prevent deactivating self
    if (admin._id.toString() === req.user._id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot deactivate your own account'
      });
    }

    const previousStatus = admin.is_active;
    admin.is_active = !admin.is_active;
    await admin.save();

    // Track activity
    await ActivityTracker.trackAdminStatusToggled(admin, req.user, admin.is_active, req);

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'admin_status_toggled',
        data: {
          admin: {
            id: admin._id,
            username: admin.username,
            email: admin.email,
            isActive: admin.is_active
          },
          toggledBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.json({
      success: true,
      data: admin,
      message: `Admin ${admin.is_active ? 'activated' : 'deactivated'} successfully`
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Delete admin
// @route   DELETE /api/superadmin/admins/:id
// @access  Private (SuperAdmin only)
router.delete('/admins/:id', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;

    // Prevent deleting self
    if (id === req.user._id) {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete your own account'
      });
    }

    const admin = await User.findByIdAndDelete(id);
    
    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found'
      });
    }

    // Track activity
    await ActivityTracker.trackAdminDeleted(admin, req.user, req);

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'admin_deleted',
        data: {
          adminId: admin._id,
          username: admin.username,
          deletedBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.json({
      success: true,
      message: 'Admin deleted successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get admin by ID
// @route   GET /api/superadmin/admins/:id
// @access  Private (SuperAdmin only)
router.get('/admins/:id', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;

    const admin = await User.findById(id);
    
    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found'
      });
    }

    res.json({
      success: true,
      data: admin,
      message: 'Admin retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get all bug reports
// @route   GET /api/superadmin/bugs
// @access  Private (SuperAdmin only)
router.get('/bugs', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { status, priority, assignedTo, page = 1, limit = 10 } = req.query;
    
    // Build filter object
    const filter = {};
    
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (assignedTo) filter.assignedTo = assignedTo;

    const skip = (Number(page) - 1) * Number(limit);
    
    const bugs = await BugReport.find(filter)
      .populate('reportedBy', 'username email')
      .populate('assignedTo', 'username email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));
    
    const total = await BugReport.countDocuments(filter);
    
    res.json({
      success: true,
      data: bugs,
      pagination: {
        page: Number(page),
        limit: Number(limit),
        total,
        pages: Math.ceil(total / Number(limit))
      },
      message: 'Bug reports retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get bug report by ID
// @route   GET /api/superadmin/bugs/:id
// @access  Private (SuperAdmin only)
router.get('/bugs/:id', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;

    const bug = await BugReport.findById(id)
      .populate('reportedBy', 'username email')
      .populate('assignedTo', 'username email');
    
    if (!bug) {
      return res.status(404).json({
        success: false,
        message: 'Bug report not found'
      });
    }

    res.json({
      success: true,
      data: bug,
      message: 'Bug report retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Create new bug report
// @route   POST /api/superadmin/bugs
// @access  Private (SuperAdmin only)
router.post('/bugs', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { title, description, priority = 'medium', tags = [] } = req.body;

    // Validate input
    if (!title || !description) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title and description'
      });
    }

    const bug = new BugReport({
      title,
      description,
      priority,
      tags,
      reportedBy: req.user._id
    });

    await bug.save();

    // Track activity
    await ActivityTracker.trackBugCreated(bug, req.user, req);

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'new_bug_report',
        data: {
          bug: {
            id: bug._id,
            title: bug.title,
            description: bug.description,
            status: bug.status,
            priority: bug.priority,
            reportedBy: bug.reportedBy,
            assignedTo: bug.assignedTo,
            tags: bug.tags,
            createdAt: bug.createdAt
          },
          reportedBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.status(201).json({
      success: true,
      data: bug,
      message: 'Bug report created successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Update bug report
// @route   PUT /api/superadmin/bugs/:id
// @access  Private (SuperAdmin only)
router.put('/bugs/:id', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const bug = await BugReport.findById(id);
    
    if (!bug) {
      return res.status(404).json({
        success: false,
        message: 'Bug report not found'
      });
    }

    // Update bug
    Object.assign(bug, updates);
    bug.updatedAt = new Date();
    await bug.save();

    // Track activity
    await ActivityTracker.trackBugUpdated(bug, req.user, updates, req);

    // Check if bug was resolved
    if (updates.status === 'resolved' || updates.status === 'closed') {
      await ActivityTracker.trackBugResolved(bug, req.user, req);
    }

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'bug_updated',
        data: {
          bug: {
            id: bug._id,
            title: bug.title,
            description: bug.description,
            status: bug.status,
            priority: bug.priority,
            reportedBy: bug.reportedBy,
            assignedTo: bug.assignedTo,
            tags: bug.tags,
            updatedAt: bug.updatedAt
          },
          updatedBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.json({
      success: true,
      data: bug,
      message: 'Bug report updated successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Delete bug report
// @route   DELETE /api/superadmin/bugs/:id
// @access  Private (SuperAdmin only)
router.delete('/bugs/:id', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;

    const bug = await BugReport.findByIdAndDelete(id);
    
    if (!bug) {
      return res.status(404).json({
        success: false,
        message: 'Bug report not found'
      });
    }

    // Track activity
    await ActivityTracker.trackBugDeleted(bug, req.user, req);

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'bug_deleted',
        data: {
          bugId: bug._id,
          title: bug.title,
          deletedBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.json({
      success: true,
      message: 'Bug report deleted successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Assign bug to admin
// @route   PATCH /api/superadmin/bugs/:id/assign
// @access  Private (SuperAdmin only)
router.patch('/bugs/:id/assign', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const { id } = req.params;
    const { assignedTo } = req.body;

    const bug = await BugReport.findByIdAndUpdate(
      id,
      { assignedTo, updatedAt: new Date() },
      { new: true, runValidators: true }
    );
    
    if (!bug) {
      return res.status(404).json({
        success: false,
        message: 'Bug report not found'
      });
    }

    // Get assigned user details
    const assignedUser = await User.findById(assignedTo);

    // Track activity
    await ActivityTracker.trackBugAssigned(bug, req.user, assignedUser, req);

    // Emit socket event for real-time updates
    if (req.app.locals.wsService) {
      req.app.locals.wsService.broadcastToAll({
        type: 'bug_assigned',
        data: {
          bug: {
            id: bug._id,
            title: bug.title,
            assignedTo: bug.assignedTo
          },
          assignedBy: req.user.username,
          timestamp: new Date().toISOString()
        }
      });
    }

    res.json({
      success: true,
      data: bug,
      message: 'Bug assigned successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get dashboard statistics
// @route   GET /api/superadmin/dashboard/stats
// @access  Private (SuperAdmin only)
router.get('/dashboard/stats', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    const [
      totalAdmins,
      activeAdmins,
      totalBugs,
      openBugs,
      inProgressBugs,
      resolvedBugs,
      closedBugs
    ] = await Promise.all([
      User.countDocuments({ role: 'admin' }),
      User.countDocuments({ role: 'admin', is_active: true }),
      BugReport.countDocuments(),
      BugReport.countDocuments({ status: 'open' }),
      BugReport.countDocuments({ status: 'in-progress' }),
      BugReport.countDocuments({ status: 'resolved' }),
      BugReport.countDocuments({ status: 'closed' })
    ]);

    const stats = {
      totalAdmins,
      activeAdmins,
      inactiveAdmins: totalAdmins - activeAdmins,
      totalBugs,
      openBugs,
      inProgressBugs,
      resolvedBugs,
      closedBugs,
      bugResolutionRate: totalBugs > 0 ? Math.round(((resolvedBugs + closedBugs) / totalBugs) * 100) : 0
    };

    res.json({
      success: true,
      data: stats,
      message: 'Dashboard statistics retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get recent activity
// @route   GET /api/superadmin/dashboard/activity
// @access  Private (SuperAdmin only)
router.get('/dashboard/activity', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    // Get recent admin activities
    const recentAdmins = await User.find({ role: 'admin' })
      .sort({ updated_at: -1 })
      .limit(5)
      .select('username email is_active last_login updated_at');

    // Get recent bug activities
    const recentBugs = await BugReport.find()
      .sort({ updatedAt: -1 })
      .limit(5)
      .select('title status priority updatedAt');

    const activities = [
      ...recentAdmins.map(admin => ({
        type: 'admin',
        action: admin.is_active ? 'Admin activated' : 'Admin deactivated',
        target: admin.username,
        timestamp: admin.updated_at,
        details: { email: admin.email, lastLogin: admin.last_login }
      })),
      ...recentBugs.map(bug => ({
        type: 'bug',
        action: `Bug ${bug.status}`,
        target: bug.title,
        timestamp: bug.updatedAt,
        details: { priority: bug.priority, status: bug.status }
      }))
    ].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, 10);

    res.json({
      success: true,
      data: activities,
      message: 'Recent activity retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

// @desc    Get performance metrics
// @route   GET /api/superadmin/dashboard/metrics
// @access  Private (SuperAdmin only)
router.get('/dashboard/metrics', authMiddleware.requireAuth, authMiddleware.requireSuperAdmin, async (req, res, next) => {
  try {
    // Get bug resolution metrics by month
    const currentDate = new Date();
    const sixMonthsAgo = new Date(currentDate.getFullYear(), currentDate.getMonth() - 6, 1);

    const monthlyMetrics = await BugReport.aggregate([
      {
        $match: {
          createdAt: { $gte: sixMonthsAgo }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          },
          totalBugs: { $sum: 1 },
          resolvedBugs: {
            $sum: {
              $cond: [{ $in: ['$status', ['resolved', 'closed']] }, 1, 0]
            }
          }
        }
      },
      {
        $sort: { '_id.year': 1, '_id.month': 1 }
      }
    ]);

    // Get admin performance metrics
    const adminMetrics = await BugReport.aggregate([
      {
        $match: {
          assignedTo: { $exists: true, $ne: null }
        }
      },
      {
        $group: {
          _id: '$assignedTo',
          totalAssigned: { $sum: 1 },
          resolved: {
            $sum: {
              $cond: [{ $in: ['$status', ['resolved', 'closed']] }, 1, 0]
            }
          }
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'admin'
        }
      },
      {
        $unwind: '$admin'
      },
      {
        $project: {
          adminName: '$admin.username',
          totalAssigned: 1,
          resolved: 1,
          resolutionRate: {
            $round: [
              { $multiply: [{ $divide: ['$resolved', '$totalAssigned'] }, 100] },
              2
            ]
          }
        }
      },
      {
        $sort: { resolutionRate: -1 }
      }
    ]);

    res.json({
      success: true,
      data: {
        monthlyMetrics,
        adminMetrics
      },
      message: 'Performance metrics retrieved successfully'
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
