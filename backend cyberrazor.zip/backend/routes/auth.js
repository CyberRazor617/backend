const express = require('express');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const User = require('../models/User');
const { requireAuth } = require('../middleware/auth');
const { sendEmail, sendWelcomeEmail } = require('../services/emailService');

const router = express.Router();

// Validation middleware
const validateSignup = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 50 })
    .withMessage('Username must be between 3 and 50 characters')
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('Username can only contain letters, numbers, underscores, and hyphens'),
  
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number')
];

const validateLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required')
];

// Helper function to create JWT token
const createToken = (user) => {
  const payload = {
    sub: user.email,
    user_id: user._id.toString(),
    username: user.username,
    role: user.role,
    is_admin: user.is_admin,
    status: user.status
  };

  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30m'
  });
};

// @route   POST /api/auth/signup
// @desc    Register a new user
// @access  Public
router.post('/signup', validateSignup, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { username, email, password } = req.body;
    
    logger.info(`🔐 Signup attempt for: ${email}`);
    
    // Check if user already exists
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        error: 'User already exists',
        message: 'Email already registered'
      });
    }
    
    // Generate activation key
    const activationKey = uuidv4();
    
    // Create new user with pending status
    const user = new User({
      username,
      email,
      password,
      activation_key: activationKey,
      status: 'pending' // Default status is pending
    });
    
    await user.save();
    logger.info(`✅ User created with pending status: ${email}`);
    
    // Send welcome email with pending status message
    let emailSent = false;
    try {
      emailSent = await sendWelcomeEmail(email, username, activationKey);
      if (emailSent) {
        logger.info(`📧 Welcome email sent to: ${email}`);
      } else {
        logger.warn(`⚠️ Failed to send welcome email to: ${email}`);
      }
    } catch (emailError) {
      logger.error(`❌ Email sending error: ${emailError.message}`);
    }

    // Send real-time WebSocket notification to admins about new pending user
    try {
      const wsService = req.app.locals.wsService;
      if (wsService) {
        const userData = {
          id: user._id.toString(),
          username: user.username,
          email: user.email,
          status: user.status,
          created_at: user.created_at,
          activation_key: user.activation_key
        };
        
        wsService.broadcastPendingUserUpdate(userData);
        logger.info(`📡 Real-time pending user notification sent for: ${email}`);
      }
    } catch (wsError) {
      logger.error(`❌ WebSocket notification error: ${wsError.message}`);
    }
    
    // Return success response with pending status
    res.status(201).json({
      success: true,
      message: 'Account request submitted successfully. You will receive an email once your account is approved.',
      user: {
        id: user._id.toString(),
        username: user.username,
        email: user.email,
        status: user.status,
        created_at: user.created_at
      },
      email_sent: emailSent
    });
    
  } catch (error) {
    logger.error('Signup error:', error);
    
    if (error.code === 11000) {
      return res.status(400).json({
        error: 'Duplicate field',
        message: 'Email or activation key already exists'
      });
    }
    
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to create user account'
    });
  }
});

// @route   POST /api/auth/login
// @desc    Authenticate user and return token
// @access  Public
router.post('/login', validateLogin, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { email, password } = req.body;
    
    logger.info(`🔐 Login attempt for: ${email}`);
    
    // Find user by email
    const user = await User.findByEmail(email);
    if (!user) {
      logger.warn(`❌ User not found: ${email}`);
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Incorrect email or password'
      });
    }

    // Auto-approve superadmin users
    if (user.email === 'superadmin@cyberrazor.com') {
      // Set required fields if they're missing (for existing users)
      if (!user.username) {
        user.username = 'superadmin';
      }
      if (!user.activation_key) {
        user.activation_key = 'superadmin-activation-key';
      }
      // Set password if missing or invalid
      if (!user.password_hash) {
        user.password = 'superadmin123'; // This will be hashed by the pre-save middleware
        logger.info('🔑 Setting SuperAdmin password');
      }
      
      if (user.status === 'pending' || user.status === 'rejected') {
        user.status = 'approved';
        user.is_active = true;
        user.role = 'superadmin';
        user.is_admin = true;
        await user.save();
        logger.info('✅ SuperAdmin auto-approved:', user.email);
      } else {
        // Save the user even if just updating missing fields
        await user.save();
        logger.info('✅ SuperAdmin fields updated:', user.email);
      }
    }
    
    // Check if account is locked - Skip for superadmin
    if (user.role !== 'superadmin' && user.isLocked()) {
      return res.status(423).json({
        error: 'Account locked',
        message: 'Account is temporarily locked due to multiple failed login attempts. Please try again later.'
      });
    }
    
    // Check user status - Skip for superadmin
    if (user.role !== 'superadmin') {
      if (user.status === 'pending') {
        return res.status(403).json({
          error: 'Account pending',
          message: 'Your account is still under review. You will receive an email once your account is approved.',
          status: 'pending'
        });
      }
      
      if (user.status === 'rejected') {
        return res.status(403).json({
          error: 'Account rejected',
          message: user.rejection_reason || 'Your account application has been rejected.',
          status: 'rejected'
        });
      }
      
      if (!user.is_active) {
        return res.status(403).json({
          error: 'Account inactive',
          message: 'Your account has been deactivated. Please contact support.',
          status: 'inactive'
        });
      }
    }
    
    // Verify password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      // Increment login attempts - Skip for superadmin
      if (user.role !== 'superadmin') {
        await user.incrementLoginAttempts();
      }
      
      logger.warn(`❌ Invalid password for: ${email}`);
      return res.status(401).json({
        error: 'Authentication failed',
        message: 'Incorrect email or password'
      });
    }
    
    // Reset login attempts on successful login
    await user.resetLoginAttempts();
    
    // Check if trial has expired and transition to free tier
    if (user.subscription_plan === 'trial' && !user.isTrialActive()) {
      await user.transitionToFreeTier();
      logger.info(`🔄 User ${email} transitioned from trial to free tier`);
    }
    
    // Create access token
    const accessToken = createToken(user);
    
    logger.info(`✅ Login successful: ${email}`);
    
    res.json({
      access_token: accessToken,
      token_type: 'bearer',
      user: {
        id: user._id.toString(),
        username: user.username,
        email: user.email,
        role: user.role,
        is_admin: user.is_admin,
        status: user.status,
        activation_key: user.activation_key,
        subscription_plan: user.subscription_plan,
        trial_end_date: user.trial_end_date,
        created_at: user.created_at
      }
    });
    
  } catch (error) {
    logger.error('Login error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Authentication failed'
    });
  }
});

// @route   GET /api/auth/me
// @desc    Get current user information
// @access  Private
router.get('/me', requireAuth, async (req, res) => {
  try {
    // Get fresh user data
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User no longer exists'
      });
    }
    
    res.json({
      id: user._id.toString(),
      username: user.username,
      email: user.email,
      is_admin: user.is_admin,
      status: user.status,
      activation_key: user.activation_key,
      subscription_plan: user.subscription_plan,
      trial_end_date: user.trial_end_date,
      last_login: user.last_login,
      created_at: user.created_at,
      profile: user.profile,
      preferences: user.preferences
    });
  } catch (error) {
    logger.error('Get user info error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to get user information'
    });
  }
});

// @route   POST /api/auth/logout
// @desc    Logout user (token revocation handled client-side)
// @access  Private
router.post('/logout', requireAuth, async (req, res) => {
  try {
    // In a real application, you might want to add the token to a blacklist
    // For now, we'll just return a success message
    res.json({
      message: 'Successfully logged out',
      note: 'Token revocation is handled client-side'
    });
  } catch (error) {
    logger.error('Logout error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Logout failed'
    });
  }
});

// @route   GET /api/auth/status
// @desc    Check user account status
// @access  Public
router.get('/status', async (req, res) => {
  try {
    const { email } = req.query;
    
    if (!email) {
      return res.status(400).json({
        error: 'Email required',
        message: 'Email parameter is required'
      });
    }
    
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'No account found with this email'
      });
    }
    
    res.json({
      email: user.email,
      status: user.status,
      message: user.status === 'pending' 
        ? 'Your account is under review. You will receive an email once approved.'
        : user.status === 'rejected'
        ? user.rejection_reason || 'Your account application has been rejected.'
        : 'Account status retrieved successfully'
    });
    
  } catch (error) {
    logger.error('Status check error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to check account status'
    });
  }
});

// @route   GET /api/auth/test
// @desc    Test endpoint to verify authentication endpoints are working
// @access  Public
router.get('/test', (req, res) => {
  res.json({
    message: 'Authentication endpoints are working!',
    status: 'ok',
    timestamp: new Date().toISOString()
  });
});

// @route   POST /api/auth/refresh
// @desc    Refresh access token
// @access  Private
router.post('/refresh', requireAuth, async (req, res) => {
  try {
    // Get fresh user data
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(401).json({
        error: 'User not found',
        message: 'Token is valid but user no longer exists'
      });
    }
    
    // Check if user is still active
    if (!user.is_active || user.status === 'rejected') {
      return res.status(401).json({
        error: 'Account inactive',
        message: 'Account is no longer active'
      });
    }
    
    // Create new token
    const newToken = createToken(user);
    
    res.json({
      access_token: newToken,
      token_type: 'bearer',
      expires_in: process.env.JWT_EXPIRES_IN || '30m'
    });
    
  } catch (error) {
    logger.error('Token refresh error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to refresh token'
    });
  }
});

// @route   PUT /api/auth/profile
// @desc    Update user profile information
// @access  Private
router.put('/profile', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User no longer exists'
      });
    }

    const { full_name, organization, role, phone, timezone } = req.body;
    
    // Update profile information
    await user.updateProfile({
      full_name,
      organization,
      role,
      phone,
      timezone
    });

    logger.info(`👤 Profile updated for user: ${user.email}`);

    res.json({
      success: true,
      message: 'Profile updated successfully',
      profile: user.profile
    });

  } catch (error) {
    logger.error('Profile update error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to update profile'
    });
  }
});

// @route   PUT /api/auth/preferences
// @desc    Update user preferences
// @access  Private
router.put('/preferences', requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User no longer exists'
      });
    }

    const { dark_mode, notifications, auto_scan, two_factor_auth, email_notifications, push_notifications } = req.body;
    
    // Update preferences
    await user.updatePreferences({
      dark_mode,
      notifications,
      auto_scan,
      two_factor_auth,
      email_notifications,
      push_notifications
    });

    logger.info(`⚙️ Preferences updated for user: ${user.email}`);

    res.json({
      success: true,
      message: 'Preferences updated successfully',
      preferences: user.preferences
    });

  } catch (error) {
    logger.error('Preferences update error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to update preferences'
    });
  }
});

// @route   POST /api/auth/change-password
// @desc    Change user password
// @access  Private
router.post('/change-password', requireAuth, async (req, res) => {
  try {
    // Log presence of body keys (do NOT log actual password values)
    const bodyKeys = req.body ? Object.keys(req.body) : [];
    logger.info(`Password change request for user=${req.user ? req.user.email : 'unknown'} - bodyKeys=${JSON.stringify(bodyKeys)}`);

    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'Current password and new password are required'
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        error: 'Validation failed',
        message: 'New password must be at least 6 characters long'
      });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        error: 'User not found',
        message: 'User no longer exists'
      });
    }

    // Change password
    await user.changePassword(currentPassword, newPassword);

    logger.info(`🔐 Password changed for user: ${user.email}`);

    res.json({
      success: true,
      message: 'Password changed successfully'
    });

  } catch (error) {
    logger.error('Password change error:', error);
    
    if (error.message === 'Current password is incorrect') {
      return res.status(400).json({
        error: 'Invalid password',
        message: 'Current password is incorrect'
      });
    }

    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to change password'
    });
  }
});

// @route   POST /api/auth/approve-superadmin
// @desc    Special endpoint to approve superadmin user
// @access  Public (for setup purposes)
router.post('/approve-superadmin', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (email !== 'superadmin@cyberrazor.com') {
      return res.status(400).json({
        error: 'Invalid request',
        message: 'This endpoint is only for superadmin approval'
      });
    }

    // Find the superadmin user
    let user = await User.findByEmail(email);
    
    if (!user) {
      // Create the superadmin user if it doesn't exist
      user = new User({
        username: 'superadmin',
        email: 'superadmin@cyberrazor.com',
        password: password,
        role: 'superadmin',
        is_admin: true,
        is_active: true,
        status: 'approved',
        activation_key: require('crypto').randomBytes(32).toString('hex')
      });
      await user.save();
      logger.info('✅ SuperAdmin user created and approved');
    } else {
      // Update existing user
      user.password = password;
      user.role = 'superadmin';
      user.is_admin = true;
      user.is_active = true;
      user.status = 'approved';
      await user.save();
      logger.info('✅ SuperAdmin user updated and approved');
    }

    res.json({
      success: true,
      message: 'SuperAdmin user approved successfully',
      user: {
        id: user._id.toString(),
        username: user.username,
        email: user.email,
        role: user.role,
        status: user.status
      }
    });

  } catch (error) {
    logger.error('SuperAdmin approval error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to approve superadmin user'
    });
  }
});

module.exports = router;
