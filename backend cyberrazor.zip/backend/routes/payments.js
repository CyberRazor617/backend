const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');

const router = express.Router();

// Validation middleware
const validatePaymentVerification = [
  body('txHash')
    .notEmpty()
    .withMessage('Transaction hash is required'),
  
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('amount')
    .notEmpty()
    .withMessage('Amount is required'),
  
  body('walletAddress')
    .notEmpty()
    .withMessage('Wallet address is required')
];

// @route   POST /api/payments/verify-payment
// @desc    Verify a payment transaction and activate Pro license
// @access  Public
router.post('/verify-payment', validatePaymentVerification, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { txHash, email, amount, walletAddress } = req.body;

    // Mock payment verification (replace with actual implementation)
    const mockResult = {
      success: true,
      message: 'Payment verified successfully (mock)',
      license_key: `PRO-${Date.now()}`,
      expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
    };

    logger.info(`💳 Payment verification request: ${txHash} for ${email}`);

    if (mockResult.success) {
      res.json({
        success: true,
        message: 'Payment verified successfully',
        license_key: mockResult.license_key,
        expires_at: mockResult.expires_at,
        tx_hash: txHash
      });
    } else {
      res.json({
        success: false,
        message: mockResult.message
      });
    }

  } catch (error) {
    logger.error('Payment verification error:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error verifying payment: ${error.message}`
    });
  }
});

// @route   GET /api/payments/status/:tx_hash
// @desc    Get the status of a payment transaction
// @access  Public
router.get('/status/:tx_hash', async (req, res) => {
  try {
    const { tx_hash } = req.params;

    // Mock payment status (replace with actual implementation)
    const mockStatus = {
      success: true,
      status: 'confirmed',
      message: 'Payment confirmed successfully',
      license_key: `PRO-${Date.now()}`,
      expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
    };

    res.json(mockStatus);

  } catch (error) {
    logger.error(`Error getting payment status for ${req.params.tx_hash}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error getting payment status: ${error.message}`
    });
  }
});

// @route   GET /api/payments/user/pro-license
// @desc    Get user's Pro license information
// @access  Private
router.get('/user/pro-license', async (req, res) => {
  try {
    // Mock pro license (replace with actual implementation)
    const mockLicense = {
      success: true,
      has_license: true,
      license_key: `PRO-${Date.now()}`,
      expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
      plan: 'pro',
      features: ['advanced_threat_detection', 'ai_analysis', 'priority_support']
    };

    res.json(mockLicense);

  } catch (error) {
    logger.error('Error getting user pro license:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error getting user license: ${error.message}`
    });
  }
});

// @route   POST /api/payments/pending
// @desc    Create a pending payment record for tracking
// @access  Public
router.post('/pending', validatePaymentVerification, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { txHash, email, amount, walletAddress } = req.body;

    // Mock pending payment creation (replace with actual implementation)
    const mockResult = {
      success: true,
      message: 'Pending payment created successfully',
      payment_id: `PEND-${Date.now()}`,
      status: 'pending'
    };

    logger.info(`⏳ Pending payment created: ${txHash} for ${email}`);

    res.json(mockResult);

  } catch (error) {
    logger.error('Error creating pending payment:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: `Error creating pending payment: ${error.message}`
    });
  }
});

module.exports = router;
