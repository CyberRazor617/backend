const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const gmailService = require('../services/gmailService');

const router = express.Router();

// Validation middleware for contact/appointment form
const validateContactForm = [
  body('name')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Name must be between 2 and 100 characters'),
  
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('company')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Company name must be less than 200 characters'),
  
  body('phone')
    .optional()
    .trim()
    .isLength({ max: 20 })
    .withMessage('Phone number must be less than 20 characters'),
  
  body('message')
    .trim()
    .isLength({ min: 10, max: 2000 })
    .withMessage('Message must be between 10 and 2000 characters'),
  
  body('service')
    .optional()
    .trim()
    .isLength({ max: 100 })
    .withMessage('Service must be less than 100 characters')
];

// @route   POST /api/contact/appointment
// @desc    Send appointment/contact form email via Gmail API
// @access  Public
router.post('/appointment', validateContactForm, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { name, email, company, phone, message, service } = req.body;
    
    logger.info(`📧 Appointment request from: ${name} (${email})`);
    logger.info(`   Company: ${company || 'N/A'}`);
    logger.info(`   Service: ${service || 'N/A'}`);
    
    // Check if Gmail service is authorized
    if (!gmailService.isAuthorized()) {
      logger.warn('⚠️ Gmail service not authorized, appointment request failed');
      return res.status(503).json({
        success: false,
        error: 'Email service temporarily unavailable',
        message: 'Please try again later or contact us directly at cyberrazor0123@gmail.com'
      });
    }

    // Send appointment email to cyberrazor0123@gmail.com
    const emailResult = await gmailService.sendAppointmentEmail({
      name,
      email,
      company,
      phone,
      message,
      service
    });

    if (emailResult.success) {
      logger.info(`✅ Appointment email sent successfully for: ${name} (${email})`);
      
      res.status(200).json({
        success: true,
        message: 'Thank you for your interest! We will contact you soon to schedule your appointment.',
        emailSent: true,
        messageId: emailResult.messageId
      });
    } else {
      logger.error(`❌ Failed to send appointment email: ${emailResult.error}`);
      
      res.status(500).json({
        success: false,
        error: 'Failed to send appointment request',
        message: 'There was an error sending your appointment request. Please try again later.',
        details: emailResult.error
      });
    }

  } catch (error) {
    logger.error('Appointment form error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      message: 'An unexpected error occurred. Please try again later.'
    });
  }
});

// @route   GET /api/contact/status
// @desc    Get Gmail service status
// @access  Public
router.get('/status', async (req, res) => {
  try {
    const authStatus = gmailService.getAuthStatus();
    
    res.json({
      success: true,
      authorized: authStatus.authorized,
      message: authStatus.authorized ? 
        'Email service is ready' : 
        'Email service needs configuration'
    });
  } catch (error) {
    logger.error('Contact status check error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to check email service status'
    });
  }
});

module.exports = router;
