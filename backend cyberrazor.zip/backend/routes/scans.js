const express = require('express');
const { body, validationResult } = require('express-validator');
const { logger } = require('../config/logger');
const { requireAuth } = require('../middleware/auth');
const geminiService = require('../services/geminiService');

const router = express.Router();

// Validation middleware
const validateScanRequest = [
  body('user_email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('scan_path')
    .notEmpty()
    .withMessage('Scan path is required'),
  
  body('scan_type')
    .isIn(['full', 'quick', 'custom'])
    .withMessage('Invalid scan type'),
  
  body('include_subdirectories')
    .isBoolean()
    .withMessage('Include subdirectories must be a boolean')
];

// @route   POST /api/scans/start
// @desc    Start a file scan
// @access  Private
router.post('/start', requireAuth, validateScanRequest, async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Validation failed',
        details: errors.array()
      });
    }

    const { user_email, scan_path, scan_type, include_subdirectories } = req.body;

    logger.info(`🔍 Starting file scan for: ${user_email}`);

    // Get database connection
    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Create scan session
    const scanId = require('crypto').randomUUID();
    const scanSession = {
      _id: scanId,
      user_email: user_email,
      scan_path: scan_path,
      scan_type: scan_type,
      status: 'running',
      start_time: new Date().toISOString(),
      files_scanned: 0,
      threats_found: 0,
      clean_files: 0
    };

    await db.collection('scan_sessions').insertOne(scanSession);

    // Start background scan (simulated for now)
    const scanResults = await simulateFileScan(req.body, db);

    res.json({
      scan_id: scanId,
      status: 'completed',
      files_scanned: scanResults.length,
      threats_found: scanResults.filter(r => r.scan_status === 'threat').length,
      clean_files: scanResults.filter(r => r.scan_status === 'clean').length
    });

  } catch (error) {
    logger.error('Error starting file scan:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to start file scan'
    });
  }
});

// @route   GET /api/scans/results
// @desc    Get scan results for user
// @access  Private
router.get('/results', requireAuth, async (req, res) => {
  try {
    const { user_email, limit = 100 } = req.query;

    // If user is not admin, only show their own results
    if (!req.user.is_admin) {
      user_email = req.user.email;
    }

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const results = await db.collection('scan_results')
      .find({ user_email: user_email })
      .sort({ scan_timestamp: -1 })
      .limit(parseInt(limit))
      .toArray();

    // Transform data
    const transformedResults = results.map(result => ({
      id: result._id.toString(),
      ...result,
      _id: undefined
    }));

    res.json({
      results: transformedResults,
      total: transformedResults.length
    });

  } catch (error) {
    logger.error('Error fetching scan results:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch scan results'
    });
  }
});

// @route   GET /api/scans/status/:scan_id
// @desc    Get scan status
// @access  Private
router.get('/status/:scan_id', requireAuth, async (req, res) => {
  try {
    const { scan_id } = req.params;

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    const scanSession = await db.collection('scan_sessions').findOne({ _id: scan_id });
    if (!scanSession) {
      return res.status(404).json({
        error: 'Scan session not found',
        message: 'The specified scan session does not exist'
      });
    }

    // Check if user has access to this scan
    if (!req.user.is_admin && scanSession.user_email !== req.user.email) {
      return res.status(403).json({
        error: 'Access denied',
        message: 'You do not have permission to view this scan'
      });
    }

    const scanData = {
      id: scanSession._id.toString(),
      ...scanSession,
      _id: undefined
    };

    res.json(scanData);

  } catch (error) {
    logger.error(`Error fetching scan status ${req.params.scan_id}:`, error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch scan status'
    });
  }
});

// @route   GET /api/scans/summary
// @desc    Get scan summary for the specified time window
// @access  Private
router.get('/summary', requireAuth, async (req, res) => {
  try {
    const { minutes = 10 } = req.query;

    // Calculate cutoff time
    const cutoffTime = new Date(Date.now() - parseInt(minutes) * 60 * 1000);

    const db = req.app.locals.db;
    if (!db) {
      return res.status(500).json({
        error: 'Database not available',
        message: 'Database connection failed'
      });
    }

    // Build query for agent logs
    const query = {
      timestamp: { $gte: cutoffTime.toISOString() }
    };

    // If user is not admin, only show their own logs
    if (!req.user.is_admin) {
      query.user_email = req.user.email;
    }

    // Fetch agent logs for the time window
    const logs = await db.collection('agent_logs')
      .find(query)
      .sort({ timestamp: -1 })
      .toArray();

    const scanResults = [];
    let totalFiles = 0;
    let maliciousFiles = 0;
    let safeFiles = 0;
    let suspiciousFiles = 0;
    let totalScanTime = 0;

    logs.forEach(log => {
      // Convert ObjectId to string
      const logId = log._id.toString();
      delete log._id;
      log.id = logId;

      // Include logs that are related to scanning activities
      const message = (log.message || '').toLowerCase();
      const module = (log.module || '').toLowerCase();

      const isScanRelated = (
        module.includes('file_scan') ||
        module.includes('threat_detection') ||
        module.includes('vulnerability_check') ||
        module.includes('system_monitor') ||
        module.includes('network_scan') ||
        message.includes('file') ||
        message.includes('scan') ||
        message.includes('threat') ||
        message.includes('malware') ||
        message.includes('vulnerability') ||
        message.includes('security') ||
        message.includes('monitoring')
      );

      if (isScanRelated) {
        // Extract file information from the log
        const messageText = log.message || '';
        const filePath = log.file_path || '';

        // Determine scan result based on log message and level
        let analysisResult = 'Safe';
        let threatLevel = 'None';
        const description = messageText;

        if (log.level === 'ERROR' || messageText.toLowerCase().includes('threat') || messageText.toLowerCase().includes('malware')) {
          analysisResult = 'Malicious';
          threatLevel = 'High';
        } else if (log.level === 'WARNING' || messageText.toLowerCase().includes('suspicious')) {
          analysisResult = 'Suspicious';
          threatLevel = 'Medium';
        } else if (messageText.toLowerCase().includes('clean') || messageText.toLowerCase().includes('safe')) {
          analysisResult = 'Safe';
          threatLevel = 'None';
        }

        // Extract filename from file_path or message
        let filename = 'Unknown';
        if (filePath) {
          if (filePath.includes('/')) {
            filename = filePath.split('/').pop();
          } else if (filePath.includes('\\')) {
            filename = filePath.split('\\').pop();
          } else {
            filename = filePath;
          }
        } else if (messageText.includes('file:')) {
          const parts = messageText.split('file:');
          if (parts.length > 1) {
            filename = parts[1].trim().split(' ')[0];
          }
        }

        // Transform data to match frontend expectations
        const transformedResult = {
          id: log.id,
          fileName: filename,
          filePath: filePath || 'System scan',
          timestamp: log.timestamp || '',
          analysisResult: analysisResult,
          description: description,
          threatLevel: threatLevel,
          fileSize: `${log.extra_data?.file_size || 0} bytes`,
          scanDuration: log.extra_data?.scan_duration || 0,
          scannerVersion: 'v2.1.0'
        };

        scanResults.push(transformedResult);
        totalFiles++;

        // Count by status
        if (analysisResult === 'Malicious') {
          maliciousFiles++;
        } else if (analysisResult === 'Safe') {
          safeFiles++;
        } else if (analysisResult === 'Suspicious') {
          suspiciousFiles++;
        }

        // Accumulate scan time
        totalScanTime += log.extra_data?.scan_duration || 0;
      }
    });

    // Calculate summary statistics
    const averageScanTime = totalFiles > 0 ? Math.floor(totalScanTime / totalFiles) : 0;
    const lastScanTime = scanResults.length > 0 ? scanResults[0].timestamp : new Date().toISOString();

    const summary = {
      totalFiles: totalFiles,
      maliciousFiles: maliciousFiles,
      safeFiles: safeFiles,
      suspiciousFiles: suspiciousFiles,
      averageScanTime: averageScanTime,
      lastScanTime: lastScanTime
    };

    res.json({
      scanResults: scanResults,
      summary: summary
    });

  } catch (error) {
    logger.error('Error fetching scan summary:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Failed to fetch scan summary'
    });
  }
});

// Simulate file scanning (placeholder for actual implementation)
async function simulateFileScan(scanRequest, database) {
  try {
    // This would be replaced with actual file scanning logic
    // For now, return empty results
    return [];
  } catch (error) {
    logger.error('Error in file scanning simulation:', error);
    return [];
  }
}

module.exports = router;
