const { MongoMemoryServer } = require('mongodb-memory-server');
const mongoose = require('mongoose');
const request = require('supertest');
const { expect } = require('chai');

let mongod;
let app;
let Threat;

describe('GET /api/threats severity filtering', function() {
  this.timeout(20000);

  before(async () => {
    // Start in-memory MongoDB
    // Use a local download directory for binaries to avoid permission issues in user profile
    const path = require('path');
    const downloadDir = path.resolve(__dirname, '../.mongodb-binaries');
    mongod = await MongoMemoryServer.create({
      binary: { downloadDir }
    });
    const uri = mongod.getUri();

    // Ensure server doesn't call listen() when imported
    process.env.VERCEL = '1';
    process.env.MONGODB_URL = uri;

    // Connect mongoose for test setup
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Load app after setting env and connecting
    app = require('../server');

    // Load Threat model
    Threat = require('../models/Threat');

    // Seed some sample threats for a single test user
    await Threat.create([
      {
        device_id: 'dev-1',
        file_path: '/tmp/malware.exe',
        threat_type: 'malware',
        confidence_score: 0.9,
        source: 'ai_analysis',
        details: { verdict: 'THREAT' },
        action_taken: 'monitored',
        severity: 'high',
        status: 'new',
        ai_verdict: 'Threat Detected',
        ai_confidence: '90%',
        ai_reason: 'suspicious heuristics',
        user_email: 'test@example.com'
      },
      {
        device_id: 'dev-2',
        file_path: '/tmp/critical.bin',
        threat_type: 'ransomware',
        confidence_score: 0.98,
        source: 'ai_analysis',
        details: { verdict: 'THREAT' },
        action_taken: 'monitored',
        severity: 'critical',
        status: 'new',
        ai_verdict: 'Threat Detected',
        ai_confidence: '98%',
        ai_reason: 'high confidence ransomware',
        user_email: 'test@example.com'
      },
      {
        device_id: 'dev-3',
        file_path: '/tmp/medium.txt',
        threat_type: 'suspicious',
        confidence_score: 0.6,
        source: 'ai_analysis',
        details: { verdict: 'SUSPICIOUS' },
        action_taken: 'monitored',
        severity: 'medium',
        status: 'new',
        ai_verdict: 'Suspicious',
        ai_confidence: '60%',
        ai_reason: 'anomaly',
        user_email: 'test@example.com'
      }
    ]);
  });

  after(async () => {
    // Clean up
    await mongoose.disconnect();
    if (mongod) await mongod.stop();
  });

  it('returns only high severity when severity=high', async () => {
    const res = await request(app)
      .get('/api/threats')
      .query({ user_email: 'test@example.com', severity: 'high' })
      .expect(200);

    expect(res.body).to.have.property('threats');
    expect(res.body.threats).to.be.an('array');
    // Should include only the single high item (not critical)
    const ids = res.body.threats.map(t => t.severity);
    expect(ids).to.include('high');
    expect(ids).to.not.include('critical');
    expect(res.body.total).to.equal(1);
  });

  it('returns high and critical when severity=high,critical', async () => {
    const res = await request(app)
      .get('/api/threats')
      .query({ user_email: 'test@example.com', severity: 'high,critical' })
      .expect(200);

    expect(res.body).to.have.property('threats');
    expect(res.body.threats).to.be.an('array');
    const severities = res.body.threats.map(t => t.severity);
    expect(severities).to.include('high');
    expect(severities).to.include('critical');
    expect(res.body.total).to.equal(2);
  });

  it('returns high and critical when severity param repeated', async () => {
    const res = await request(app)
      .get('/api/threats')
      .query({ user_email: 'test@example.com', severity: ['high', 'critical'] })
      .expect(200);

    expect(res.body).to.have.property('threats');
    expect(res.body.threats).to.be.an('array');
    const severities = res.body.threats.map(t => t.severity);
    expect(severities).to.include('high');
    expect(severities).to.include('critical');
    expect(res.body.total).to.equal(2);
  });
});
