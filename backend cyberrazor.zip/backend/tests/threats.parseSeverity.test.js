const { expect } = require('chai');
const threatsRouter = require('../routes/threats');

describe('parseSeverityParam helper', () => {
  it('returns null for empty/undefined', () => {
    expect(threatsRouter.parseSeverityParam(undefined)).to.equal(null);
    expect(threatsRouter.parseSeverityParam(null)).to.equal(null);
  });

  it('returns lowercase string for single value', () => {
    expect(threatsRouter.parseSeverityParam('High')).to.equal('high');
    expect(threatsRouter.parseSeverityParam('medium')).to.equal('medium');
  });

  it('returns $in array for comma-separated values', () => {
    const res = threatsRouter.parseSeverityParam('high,critical');
    expect(res).to.be.an('object');
    expect(res).to.have.property('$in');
    expect(res.$in).to.deep.equal(['high', 'critical']);
  });

  it('returns $in array for repeated array input', () => {
    const res = threatsRouter.parseSeverityParam(['high', 'critical']);
    expect(res).to.be.an('object');
    expect(res.$in).to.deep.equal(['high', 'critical']);
  });
});
