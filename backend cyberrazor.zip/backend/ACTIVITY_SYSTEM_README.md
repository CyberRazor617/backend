# Real-Time Activity Tracking System

## Overview

The Real-Time Activity Tracking System provides comprehensive monitoring and logging of all system activities in the CyberRazor platform. It tracks user actions, system events, and administrative operations with real-time updates via WebSockets.

## Features

- **Comprehensive Activity Tracking**: Monitors admin creation, bug reports, user management, and system events
- **Real-Time Updates**: WebSocket-based live updates to the frontend
- **Activity Filtering**: Filter activities by type, category, severity, and timeframe
- **Activity Statistics**: Detailed analytics and trends
- **Audit Trail**: Complete history of all system activities
- **Performance Optimized**: Efficient database queries with proper indexing

## Architecture

### Backend Components

1. **Activity Model** (`models/Activity.js`)
   - MongoDB schema for storing activity records
   - Comprehensive indexing for performance
   - Built-in methods for querying and formatting

2. **Activity Tracker** (`middleware/activityTracker.js`)
   - Centralized activity tracking functions
   - Automatic activity creation for system events
   - WebSocket broadcasting integration

3. **Activity Routes** (`routes/activities.js`)
   - RESTful API endpoints for activity data
   - Real-time activity fetching
   - Statistics and analytics endpoints

4. **WebSocket Service** (`services/websocketService.js`)
   - Real-time activity broadcasting
   - Room-based subscriptions
   - Connection management

### Frontend Components

1. **Activity Feed Component** (`components/real-time/ActivityFeed.tsx`)
   - Real-time activity display
   - Auto-refresh functionality
   - WebSocket integration

2. **WebSocket Hook** (`hooks/useWebSocket.ts`)
   - React hook for WebSocket connections
   - Automatic reconnection
   - Message handling

## Activity Types

### User Management Activities
- `admin_created` - New admin account created
- `admin_updated` - Admin account updated
- `admin_deleted` - Admin account deleted
- `admin_status_toggled` - Admin status changed
- `user_registered` - New user registration
- `user_approved` - User account approved
- `user_rejected` - User account rejected
- `user_deleted` - User account deleted

### Bug Management Activities
- `bug_created` - New bug report created
- `bug_updated` - Bug report updated
- `bug_deleted` - Bug report deleted
- `bug_assigned` - Bug report assigned
- `bug_resolved` - Bug report resolved

### System Activities
- `system_alert` - System alert generated
- `threat_detected` - Security threat detected
- `scan_completed` - Security scan completed
- `login_success` - Successful login
- `login_failed` - Failed login attempt
- `password_changed` - Password changed
- `settings_updated` - User settings updated

## API Endpoints

### Get Recent Activities
```
GET /api/activities/recent
```
Query Parameters:
- `limit` (number): Number of activities to return (default: 50)
- `category` (string): Filter by activity category
- `type` (string): Filter by activity type
- `severity` (string): Filter by severity level
- `timeframe` (string): Time range (1h, 24h, 7d, 30d, all)
- `page` (number): Page number for pagination

### Get Dashboard Activities
```
GET /api/activities/dashboard
```
Query Parameters:
- `limit` (number): Number of activities to return (default: 20)

### Get Activity Statistics
```
GET /api/activities/stats
```
Query Parameters:
- `timeframe` (string): Time range for statistics (default: 24h)

### Get Activity Trends
```
GET /api/activities/trends
```
Query Parameters:
- `days` (number): Number of days for trends (default: 7)

### Get Real-Time Activities
```
GET /api/activities/real-time
```
Query Parameters:
- `since` (string): ISO timestamp to get activities since

## WebSocket Events

### Connection
```javascript
const ws = new WebSocket('ws://localhost:8000/ws?token=YOUR_JWT_TOKEN');
```

### Activity Update Event
```javascript
ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  if (message.type === 'activity_update') {
    // Handle new activity
    console.log('New activity:', message.data);
  }
};
```

### Subscribe to Admin Room
```javascript
ws.send(JSON.stringify({
  type: 'join_room',
  payload: { room: 'admin' }
}));
```

## Database Schema

### Activity Collection
```javascript
{
  _id: ObjectId,
  type: String,           // Activity type
  action: String,         // Human-readable action
  description: String,    // Detailed description
  performedBy: ObjectId,  // Reference to User
  performedByEmail: String,
  targetId: ObjectId,     // Target object ID
  targetType: String,     // Target type (user, admin, bug, etc.)
  targetName: String,     // Target name
  metadata: Object,       // Additional data
  severity: String,       // low, medium, high, critical
  category: String,       // user_management, bug_management, etc.
  ipAddress: String,      // Client IP
  userAgent: String,      // Client user agent
  timestamp: Date,        // Activity timestamp
  createdAt: Date,
  updatedAt: Date
}
```

## Usage Examples

### Tracking Admin Creation
```javascript
const admin = new User({
  username: 'newadmin',
  email: 'admin@example.com',
  role: 'admin'
});
await admin.save();

// Track the activity
await ActivityTracker.trackAdminCreated(admin, req.user, req);
```

### Getting Recent Activities
```javascript
const activities = await Activity.getRecentActivities(20);
const formatted = activities.map(activity => activity.formatForDisplay());
```

### WebSocket Integration
```javascript
// Frontend
const { isConnected, subscribeToRoom } = useWebSocket({
  onMessage: (message) => {
    if (message.type === 'activity_update') {
      setActivities(prev => [message.data, ...prev]);
    }
  }
});

// Subscribe to admin activities
useEffect(() => {
  if (isConnected) {
    subscribeToRoom('admin');
  }
}, [isConnected, subscribeToRoom]);
```

## Performance Considerations

### Database Indexes
The Activity model includes comprehensive indexes for optimal query performance:
- `type` - For filtering by activity type
- `performedBy` - For user-specific queries
- `targetId` - For target-specific queries
- `category` - For category filtering
- `severity` - For severity filtering
- `timestamp` - For time-based queries
- Compound indexes for common query patterns

### Query Optimization
- Use pagination for large result sets
- Implement proper filtering to reduce data transfer
- Cache frequently accessed statistics
- Use aggregation pipelines for complex analytics

### WebSocket Optimization
- Implement connection pooling
- Use room-based subscriptions to reduce unnecessary broadcasts
- Implement message queuing for offline clients
- Add connection health monitoring

## Security Considerations

### Access Control
- All activity endpoints require admin authentication
- WebSocket connections require valid JWT tokens
- Activity data is filtered based on user permissions

### Data Privacy
- Sensitive information is excluded from activity logs
- IP addresses and user agents are logged for security auditing
- Activity data retention policies should be implemented

### Audit Trail
- All administrative actions are logged
- Failed authentication attempts are tracked
- System changes are recorded with timestamps and user information

## Testing

### Running Tests
```bash
# Run the activity system test
node backend/test-activity-system.js
```

### Test Coverage
- Activity creation and tracking
- Database queries and formatting
- WebSocket integration
- API endpoint functionality
- Error handling and edge cases

## Monitoring and Maintenance

### Health Checks
- Monitor WebSocket connection counts
- Track activity creation rates
- Monitor database query performance
- Alert on failed activity tracking

### Maintenance Tasks
- Regular cleanup of old activity records
- Database index optimization
- WebSocket connection monitoring
- Performance metrics collection

## Future Enhancements

### Planned Features
- Activity search and filtering UI
- Advanced analytics dashboard
- Activity export functionality
- Real-time notifications
- Activity-based alerting system
- Integration with external monitoring tools

### Scalability Improvements
- Redis caching for frequently accessed data
- Database sharding for large activity volumes
- Message queue for high-volume activity processing
- CDN integration for global WebSocket connections

## Troubleshooting

### Common Issues

1. **WebSocket Connection Failures**
   - Check JWT token validity
   - Verify WebSocket server is running
   - Check network connectivity

2. **Activity Not Being Tracked**
   - Verify ActivityTracker is properly imported
   - Check database connection
   - Review error logs for tracking failures

3. **Performance Issues**
   - Check database indexes
   - Monitor query execution times
   - Review WebSocket connection counts

### Debug Mode
Enable debug logging by setting the environment variable:
```bash
DEBUG=activity:*
```

## Support

For issues or questions regarding the Activity Tracking System:
1. Check the logs for error messages
2. Review the API documentation
3. Test with the provided test script
4. Contact the development team

---

*Last updated: January 2024*
