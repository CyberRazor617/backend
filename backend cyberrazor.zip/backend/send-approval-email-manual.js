#!/usr/bin/env node
/**
 * Manually send approval email to a specific user
 */

require('dotenv').config();
const nodemailer = require('nodemailer');

const userEmail = 'syedminhalrizvi9@gmail.com';
const username = 'minhal_rizvi'; // Update if different

const sendApprovalEmail = async () => {
  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║           SENDING APPROVAL EMAIL MANUALLY                   ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  const transporter = nodemailer.createTransporter({
    host: process.env.SMTP_SERVER,
    port: parseInt(process.env.SMTP_PORT),
    secure: false,
    auth: {
      user: process.env.SMTP_USERNAME,
      pass: process.env.SMTP_PASSWORD
    },
    tls: {
      rejectUnauthorized: false
    }
  });

  const subject = '🎉 Congratulations! Your CyberRazor Account is Approved';
  
  const htmlBody = `
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #2563eb; margin-bottom: 10px;">🛡️ CyberRazor</h1>
                <h2 style="color: #10b981; margin-bottom: 20px;">🎉 Congratulations!</h2>
            </div>
            
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
                <h2 style="color: white; margin: 0; font-size: 28px;">Your Account Has Been Approved! 🚀</h2>
            </div>
            
            <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #10b981;">
                <p style="margin-bottom: 15px;">Dear <strong>${username}</strong>,</p>
                
                <p style="margin-bottom: 15px; font-size: 18px; color: #059669;">
                    <strong>🎊 Great news! Your CyberRazor account has been approved by our admin team!</strong>
                </p>
                
                <p style="margin-bottom: 15px;">
                    You can now access your user portal and start protecting your digital assets with our advanced security solutions.
                </p>
                
                <div style="background: white; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <h3 style="color: #0369a1; margin-bottom: 15px;">🔗 Access Your Portal</h3>
                    <a href="https://cyberrazor.vercel.app/login" 
                       style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 18px; box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);">
                        Login to CyberRazor Portal
                    </a>
                </div>
                
                <div style="background: #fef3c7; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #92400e; margin-bottom: 15px; text-align: center;">🎁 What You Get:</h3>
                    <ul style="margin: 0; padding-left: 20px; color: #78350f;">
                        <li style="margin-bottom: 10px;"><strong>7-Day Free Trial</strong> - Full access to all premium features</li>
                        <li style="margin-bottom: 10px;"><strong>Unique Activation Key</strong> - For web dashboard and agent activation</li>
                        <li style="margin-bottom: 10px;"><strong>Real-time Threat Monitoring</strong> - 24/7 security protection</li>
                        <li style="margin-bottom: 10px;"><strong>AI-Powered Analysis</strong> - Advanced threat detection</li>
                        <li style="margin-bottom: 10px;"><strong>Comprehensive Dashboard</strong> - Monitor all your security metrics</li>
                    </ul>
                </div>
                
                <div style="background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0;">
                    <h3 style="color: #1e40af; margin-bottom: 15px; text-align: center;">🚀 Next Steps:</h3>
                    <ol style="margin: 0; padding-left: 20px; color: #1e3a8a;">
                        <li style="margin-bottom: 10px;">Login to your portal using your registered credentials</li>
                        <li style="margin-bottom: 10px;">Download your unique activation key from the dashboard</li>
                        <li style="margin-bottom: 10px;">Install the CyberRazor security agent on your devices</li>
                        <li style="margin-bottom: 10px;">Start monitoring and protecting your digital assets</li>
                    </ol>
                </div>
                
                <p style="margin-bottom: 15px; font-size: 16px;">
                    <strong>Welcome to the CyberRazor family!</strong> We're excited to help you secure your digital world with cutting-edge cybersecurity technology.
                </p>
                
                <p style="margin-bottom: 0;">
                    Best regards,<br>
                    <strong>The CyberRazor Team</strong><br>
                    <span style="color: #6b7280; font-size: 14px;">Your Trusted Security Partner</span>
                </p>
            </div>
            
            <div style="text-align: center; color: #6b7280; font-size: 12px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
                <p>This is an automated message. Please do not reply to this email.</p>
                <p style="margin-top: 10px;">© 2024 CyberRazor. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>
  `;

  try {
    console.log(`📧 Sending approval email to: ${userEmail}`);
    
    const mailOptions = {
      from: process.env.SMTP_USERNAME,
      to: userEmail,
      subject: subject,
      html: htmlBody
    };

    const info = await transporter.sendMail(mailOptions);
    
    console.log('✅ Approval email sent successfully!');
    console.log(`   Message ID: ${info.messageId}`);
    console.log(`   To: ${userEmail}`);
    console.log(`   Response: ${info.response}\n`);
    
    console.log('╔══════════════════════════════════════════════════════════════╗');
    console.log('║              ✅ APPROVAL EMAIL SENT                          ║');
    console.log('╚══════════════════════════════════════════════════════════════╝\n');
    console.log(`📧 Check email inbox: ${userEmail}\n`);

  } catch (error) {
    console.error('\n❌ Failed to send approval email:');
    console.error(`   Error: ${error.message}\n`);
    process.exit(1);
  }
};

sendApprovalEmail();
