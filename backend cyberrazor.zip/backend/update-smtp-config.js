#!/usr/bin/env node
/**
 * Script to update SMTP configuration in .env file
 */

const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env');

// Read current .env file
let envContent = fs.readFileSync(envPath, 'utf8');

// Update SMTP credentials
envContent = envContent.replace(
  /SMTP_USERNAME=.*/,
  'SMTP_USERNAME=cyberrazor.technical@gmail.com'
);

envContent = envContent.replace(
  /SMTP_PASSWORD=.*/,
  'SMTP_PASSWORD=dmhnlgqfyjvksbge'
);

// Write updated content back to .env
fs.writeFileSync(envPath, envContent);

console.log('✅ SMTP configuration updated successfully!');
console.log('📧 Email: cyberrazor.technical@gmail.com');
console.log('🔐 App Password: dmhn lgqf yjvk sbge');
