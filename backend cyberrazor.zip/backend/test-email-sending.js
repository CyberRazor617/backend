#!/usr/bin/env node
/**
 * Test SMTP email sending configuration
 */

require('dotenv').config();
const nodemailer = require('nodemailer');

const testEmailSending = async () => {
  console.log('\n╔══════════════════════════════════════════════════════════════╗');
  console.log('║              TESTING SMTP EMAIL CONFIGURATION                ║');
  console.log('╚══════════════════════════════════════════════════════════════╝\n');

  console.log('📧 SMTP Configuration:');
  console.log(`   Server: ${process.env.SMTP_SERVER}`);
  console.log(`   Port: ${process.env.SMTP_PORT}`);
  console.log(`   Username: ${process.env.SMTP_USERNAME}`);
  console.log(`   Password: ${process.env.SMTP_PASSWORD ? '***configured***' : 'NOT SET'}\n`);

  // Create transporter
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_SERVER,
    port: parseInt(process.env.SMTP_PORT),
    secure: false,
    auth: {
      user: process.env.SMTP_USERNAME,
      pass: process.env.SMTP_PASSWORD
    },
    tls: {
      rejectUnauthorized: false
    }
  });

  try {
    // Verify connection
    console.log('🔍 Verifying SMTP connection...');
    await transporter.verify();
    console.log('✅ SMTP connection verified successfully!\n');

    // Send test email
    console.log('📨 Sending test email...');
    const testEmail = 'syedminhalrizvi9@gmail.com'; // Send to your email
    
    const mailOptions = {
      from: process.env.SMTP_USERNAME,
      to: testEmail,
      subject: '🎉 CyberRazor - Email Test Successful',
      html: `
        <html>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
            <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 style="color: #2563eb;">🛡️ CyberRazor</h1>
                    <h2 style="color: #10b981;">Email Configuration Test</h2>
                </div>
                
                <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981;">
                    <h3 style="color: #059669; margin-top: 0;">✅ Success!</h3>
                    <p>Your SMTP email configuration is working correctly.</p>
                    <p><strong>SMTP Server:</strong> ${process.env.SMTP_SERVER}</p>
                    <p><strong>Email:</strong> ${process.env.SMTP_USERNAME}</p>
                    <p><strong>Test Time:</strong> ${new Date().toLocaleString()}</p>
                </div>
                
                <div style="margin-top: 20px; padding: 15px; background: #dbeafe; border-radius: 8px;">
                    <p style="margin: 0;"><strong>Next Steps:</strong></p>
                    <ul style="margin: 10px 0;">
                        <li>Approval emails will be sent when admin approves users</li>
                        <li>Users will receive congratulations messages</li>
                        <li>Email notifications are fully functional</li>
                    </ul>
                </div>
                
                <div style="text-align: center; margin-top: 20px; color: #6b7280; font-size: 12px;">
                    <p>© 2024 CyberRazor. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
      `
    };

    const info = await transporter.sendMail(mailOptions);
    
    console.log('✅ Test email sent successfully!');
    console.log(`   Message ID: ${info.messageId}`);
    console.log(`   To: ${testEmail}`);
    console.log(`   Response: ${info.response}\n`);

    console.log('╔══════════════════════════════════════════════════════════════╗');
    console.log('║                    ✅ ALL TESTS PASSED                       ║');
    console.log('╚══════════════════════════════════════════════════════════════╝\n');
    console.log('📧 Check your email inbox: syedminhalrizvi9@gmail.com\n');

  } catch (error) {
    console.error('\n❌ Email test failed:');
    console.error(`   Error: ${error.message}`);
    console.error(`\n💡 Troubleshooting:`);
    console.error(`   1. Verify Gmail app password is correct (no spaces)`);
    console.error(`   2. Check if "Less secure app access" is enabled (if needed)`);
    console.error(`   3. Verify 2-factor authentication is enabled on Gmail`);
    console.error(`   4. Make sure the app password is generated correctly\n`);
    process.exit(1);
  }
};

testEmailSending();
