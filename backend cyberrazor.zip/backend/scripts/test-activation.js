#!/usr/bin/env node
/**
 * Test Activation Script
 * Tests the activation endpoint
 */

const https = require('https');

function testActivation() {
  const data = JSON.stringify({
    user_email: "test@example.com",
    hostname: "test-machine",
    os_info: "Windows 10",
    activation_key: "fd178064-d7ea-4eb3-bc9a-4e39c4a14d33"
  });

  const options = {
    hostname: 'cyberrazorbackend.vercel.app',
    port: 443,
    path: '/api/devices/activate-key',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  };

  console.log('🔑 Testing activation with key: fd178064-d7ea-4eb3-bc9a-4e39c4a14d33');
  console.log('📡 Sending request to backend...');

  const req = https.request(options, (res) => {
    console.log(`📊 Status Code: ${res.statusCode}`);
    
    let responseData = '';
    res.on('data', (chunk) => {
      responseData += chunk;
    });
    
    res.on('end', () => {
      console.log(`📄 Response: ${responseData}`);
      
      if (res.statusCode === 200) {
        console.log('✅ Activation successful!');
      } else {
        console.log('❌ Activation failed');
      }
    });
  });

  req.on('error', (error) => {
    console.error('❌ Error:', error);
  });

  req.write(data);
  req.end();
}

testActivation();
