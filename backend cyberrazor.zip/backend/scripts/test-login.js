#!/usr/bin/env node
/**
 * Test Login Script
 * Tests login for admin and superadmin users
 */

const mongoose = require('mongoose');
const User = require('../models/User');

// MongoDB connection string
const MONGODB_URL = 'mongodb+srv://digibryx:mesumzain786@cluster0.hlnj4ui.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

const testLogin = async () => {
  try {
    // Connect to MongoDB
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGODB_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ Connected to MongoDB\n');

    // Test credentials
    const testUsers = [
      {
        email: 'nisaiqbal000@gmail.com',
        password: '123456789',
        role: 'admin'
      },
      {
        email: 'superadmin@cyberrazor.com',
        password: 'superadmin123',
        role: 'superadmin'
      }
    ];

    for (const testUser of testUsers) {
      console.log(`\n📝 Testing login for ${testUser.role}: ${testUser.email}`);
      
      // Find user
      const user = await User.findOne({ email: testUser.email });
      
      if (!user) {
        console.log(`❌ User not found: ${testUser.email}`);
        continue;
      }

      console.log(`✅ User found in database`);
      console.log(`   - Username: ${user.username}`);
      console.log(`   - Email: ${user.email}`);
      console.log(`   - Role: ${user.role}`);
      console.log(`   - Status: ${user.status}`);
      console.log(`   - Is Active: ${user.is_active}`);
      console.log(`   - Is Admin: ${user.is_admin}`);
      console.log(`   - Has Password Hash: ${!!user.password_hash}`);
      console.log(`   - Activation Key: ${user.activation_key}`);

      // Test password
      try {
        const isPasswordValid = await user.comparePassword(testUser.password);
        if (isPasswordValid) {
          console.log(`✅ Password verification successful`);
          console.log(`🎉 ${testUser.role.toUpperCase()} can login successfully!`);
        } else {
          console.log(`❌ Password verification failed`);
        }
      } catch (error) {
        console.log(`❌ Error verifying password: ${error.message}`);
      }
    }

    console.log('\n\n📋 Summary:');
    console.log('Both users have been registered and can now login with their credentials.');
    console.log('\nAdmin Login:');
    console.log('  Email: nisaiqbal000@gmail.com');
    console.log('  Password: 123456789');
    console.log('\nSuperAdmin Login:');
    console.log('  Email: superadmin@cyberrazor.com');
    console.log('  Password: superadmin123');

  } catch (error) {
    console.error('❌ Error testing login:', error);
    console.error('Error details:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('\n🔌 Disconnected from MongoDB');
    process.exit(0);
  }
};

testLogin();
