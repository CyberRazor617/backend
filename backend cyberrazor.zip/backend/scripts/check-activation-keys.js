#!/usr/bin/env node
/**
 * Check Activation Keys Script
 * Lists all activation keys in the database
 */

const { MongoClient } = require('mongodb');
require('dotenv').config();

const MONGODB_URL = process.env.MONGODB_URL || 'mongodb+srv://rminhal783:Hhua6tUekZkGfBx0@cluster0.auuhgc5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
const DB_NAME = process.env.MONGODB_DB_NAME || 'cyberrazor_enterprise';

async function checkActivationKeys() {
  let client;
  
  try {
    console.log('🔗 Connecting to MongoDB...');
    client = new MongoClient(MONGODB_URL);
    await client.connect();
    
    const db = client.db(DB_NAME);
    console.log('✅ Connected to database');
    
    // List all activation keys
    const activationKeys = await db.collection('device_activations').find({}).toArray();
    
    console.log(`📱 Found ${activationKeys.length} activation keys:`);
    activationKeys.forEach((key, index) => {
      console.log(`   ${index + 1}. ${key.activation_key} (${key.status}) - Created: ${key.created_at}`);
    });
    
    // Test specific key
    const testKey = 'fd178064-d7ea-4eb3-bc9a-4e39c4a14d33';
    const specificKey = await db.collection('device_activations').findOne({
      activation_key: testKey
    });
    
    if (specificKey) {
      console.log(`\n✅ Test key found: ${testKey}`);
      console.log(`   Status: ${specificKey.status}`);
      console.log(`   Created: ${specificKey.created_at}`);
      console.log(`   Expires: ${specificKey.expires_at}`);
    } else {
      console.log(`\n❌ Test key not found: ${testKey}`);
    }
    
  } catch (error) {
    console.error('❌ Error checking activation keys:', error);
    process.exit(1);
  } finally {
    if (client) {
      await client.close();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the script
if (require.main === module) {
  checkActivationKeys()
    .then(() => {
      console.log('🎉 Check completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Failed to check activation keys:', error);
      process.exit(1);
    });
}

module.exports = { checkActivationKeys };
