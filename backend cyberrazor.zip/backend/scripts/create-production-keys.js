#!/usr/bin/env node
/**
 * Create Production Activation Keys Script
 * Creates activation keys in the production database
 */

const https = require('https');

function createProductionKeys() {
  console.log('🔑 Creating activation keys in production database...');
  
  // First, let's try to create keys using the admin endpoint
  const createKeysData = JSON.stringify({
    count: 10
  });

  const options = {
    hostname: 'cyberrazorbackend.vercel.app',
    port: 443,
    path: '/api/devices/create-keys',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': createKeysData.length,
      'Authorization': 'Bearer admin-token' // This might need to be updated
    }
  };

  console.log('📡 Sending request to create keys...');

  const req = https.request(options, (res) => {
    console.log(`📊 Status Code: ${res.statusCode}`);
    
    let responseData = '';
    res.on('data', (chunk) => {
      responseData += chunk;
    });
    
    res.on('end', () => {
      console.log(`📄 Response: ${responseData}`);
      
      if (res.status_code === 200) {
        console.log('✅ Activation keys created successfully!');
        const result = JSON.parse(responseData);
        console.log('🔑 Created keys:');
        result.keys.forEach((key, index) => {
          console.log(`   ${index + 1}. ${key}`);
        });
      } else {
        console.log('❌ Failed to create activation keys');
        console.log('💡 This might be because admin authentication is required');
        console.log('💡 Let\'s try creating a test key directly...');
        createTestKey();
      }
    });
  });

  req.on('error', (error) => {
    console.error('❌ Error:', error);
    console.log('💡 Let\'s try creating a test key directly...');
    createTestKey();
  });

  req.write(createKeysData);
  req.end();
}

function createTestKey() {
  console.log('\n🔧 Creating test activation key directly...');
  
  // Create a test key using the activation endpoint with a known key
  const testKey = 'fd178064-d7ea-4eb3-bc9a-4e39c4a14d33';
  
  const activationData = JSON.stringify({
    user_email: "test@cyberrazor.com",
    hostname: "test-machine",
    os_info: "Windows 10",
    activation_key: testKey
  });

  const options = {
    hostname: 'cyberrazorbackend.vercel.app',
    port: 443,
    path: '/api/devices/activate-key',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': activationData.length
    }
  };

  const req = https.request(options, (res) => {
    console.log(`📊 Activation Test Status: ${res.statusCode}`);
    
    let responseData = '';
    res.on('data', (chunk) => {
      responseData += chunk;
    });
    
    res.on('end', () => {
      console.log(`📄 Response: ${responseData}`);
      
      if (res.statusCode === 200) {
        console.log('✅ Test activation successful!');
        console.log('🎉 The activation key is working!');
      } else {
        console.log('❌ Test activation failed');
        console.log('💡 The key might not exist in the production database');
        console.log('💡 You may need to create it through the admin panel');
      }
    });
  });

  req.on('error', (error) => {
    console.error('❌ Error:', error);
  });

  req.write(activationData);
  req.end();
}

// Run the script
createProductionKeys();
