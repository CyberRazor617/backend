#!/usr/bin/env node
/**
 * Create Activation Keys Script
 * Generates activation keys for device activation
 */

const { MongoClient } = require('mongodb');
require('dotenv').config();

const MONGODB_URL = process.env.MONGODB_URL || 'mongodb+srv://rminhal783:Hhua6tUekZkGfBx0@cluster0.auuhgc5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
const DB_NAME = process.env.MONGODB_DB_NAME || 'cyberrazor_enterprise';

async function createActivationKeys() {
  let client;
  
  try {
    console.log('🔗 Connecting to MongoDB...');
    client = new MongoClient(MONGODB_URL);
    await client.connect();
    
    const db = client.db(DB_NAME);
    console.log('✅ Connected to database');
    
    // Create activation keys
    const activationKeys = [
      'fd178064-d7ea-4eb3-bc9a-4e39c4a14d33',
      'test-key-12345',
      'demo-activation-key',
      'cyberrazor-test-key'
    ];
    
    const activationDocs = activationKeys.map(key => ({
      activation_key: key,
      status: 'available',
      created_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours
      created_by: 'system'
    }));
    
    console.log('🔑 Creating activation keys...');
    
    // Insert activation keys
    const result = await db.collection('device_activations').insertMany(activationDocs);
    
    console.log(`✅ Created ${result.insertedCount} activation keys:`);
    activationKeys.forEach(key => {
      console.log(`   - ${key}`);
    });
    
    console.log('\n📱 Activation keys are now available for device activation');
    console.log('⏰ Keys expire in 24 hours');
    
  } catch (error) {
    console.error('❌ Error creating activation keys:', error);
    process.exit(1);
  } finally {
    if (client) {
      await client.close();
      console.log('🔌 Database connection closed');
    }
  }
}

// Run the script
if (require.main === module) {
  createActivationKeys()
    .then(() => {
      console.log('🎉 Activation keys created successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Failed to create activation keys:', error);
      process.exit(1);
    });
}

module.exports = { createActivationKeys };
