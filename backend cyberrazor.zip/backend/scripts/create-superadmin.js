#!/usr/bin/env node
/**
 * Create SuperAdmin User Script
 * Creates a superadmin user with hardcoded credentials
 */

const mongoose = require('mongoose');
const User = require('../models/User');
require('dotenv').config();

const createSuperAdmin = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URL || 'mongodb://localhost:27017/cyberrazor_enterprise');
    console.log('✅ Connected to MongoDB');

    // Check if superadmin already exists
    const existingSuperAdmin = await User.findOne({ email: 'superadmin@cyberrazor.com' });
    
    if (existingSuperAdmin) {
      console.log('⚠️  SuperAdmin already exists, updating credentials...');
      
      // Update existing superadmin
      existingSuperAdmin.password = 'superadmin123';
      existingSuperAdmin.role = 'superadmin';
      existingSuperAdmin.is_admin = true;
      existingSuperAdmin.is_active = true;
      existingSuperAdmin.status = 'approved';
      existingSuperAdmin.username = 'superadmin';
      
      await existingSuperAdmin.save();
      console.log('✅ SuperAdmin credentials updated successfully');
    } else {
      // Create new superadmin
      const superAdmin = new User({
        username: 'superadmin',
        email: 'superadmin@cyberrazor.com',
        password: 'superadmin123',
        role: 'superadmin',
        is_admin: true,
        is_active: true,
        status: 'approved',
        activation_key: require('crypto').randomBytes(32).toString('hex')
      });

      await superAdmin.save();
      console.log('✅ SuperAdmin created successfully');
    }

    console.log('🎉 SuperAdmin setup complete!');
    console.log('📧 Email: superadmin@cyberrazor.com');
    console.log('🔑 Password: superadmin123');
    console.log('👑 Role: superadmin');

  } catch (error) {
    console.error('❌ Error creating SuperAdmin:', error);
  } finally {
    await mongoose.disconnect();
    console.log('🔌 Disconnected from MongoDB');
    process.exit(0);
  }
};

createSuperAdmin();
