#!/usr/bin/env node
/**
 * Seed Admin and SuperAdmin Users Script
 * Creates admin and superadmin users with specified credentials
 */

const mongoose = require('mongoose');
const User = require('../models/User');
const crypto = require('crypto');

// MongoDB connection string
const MONGODB_URL = 'mongodb+srv://digibryx:mesumzain786@cluster0.hlnj4ui.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

const seedUsers = async () => {
  try {
    // Connect to MongoDB
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(MONGODB_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('✅ Connected to MongoDB');

    // SuperAdmin user data
    const superAdminData = {
      email: 'superadmin@cyberrazor.com',
      password: 'superadmin123',
      username: 'superadmin',
      role: 'superadmin'
    };

    // Admin user data
    const adminData = {
      email: 'nisaiqbal000@gmail.com',
      password: '123456789',
      username: 'admin',
      role: 'admin'
    };

    // Process SuperAdmin User FIRST (needed for admin's createdBy field)
    console.log('\n📝 Processing SuperAdmin user...');
    let superAdminUser;
    const existingSuperAdmin = await User.findOne({ email: superAdminData.email });
    
    if (existingSuperAdmin) {
      console.log('⚠️  SuperAdmin user already exists, updating credentials...');
      existingSuperAdmin.password = superAdminData.password;
      existingSuperAdmin.role = 'superadmin';
      existingSuperAdmin.is_admin = true;
      existingSuperAdmin.is_active = true;
      existingSuperAdmin.status = 'approved';
      existingSuperAdmin.username = superAdminData.username;
      
      await existingSuperAdmin.save();
      superAdminUser = existingSuperAdmin;
      console.log('✅ SuperAdmin user updated successfully');
    } else {
      const superAdmin = new User({
        username: superAdminData.username,
        email: superAdminData.email,
        password: superAdminData.password,
        role: 'superadmin',
        is_admin: true,
        is_active: true,
        status: 'approved',
        activation_key: crypto.randomBytes(32).toString('hex')
      });

      await superAdmin.save();
      superAdminUser = superAdmin;
      console.log('✅ SuperAdmin user created successfully');
    }

    // Process Admin User (using superadmin as creator)
    console.log('\n📝 Processing Admin user...');
    const existingAdmin = await User.findOne({ email: adminData.email });
    
    if (existingAdmin) {
      console.log('⚠️  Admin user already exists, updating credentials...');
      existingAdmin.password = adminData.password;
      existingAdmin.role = 'admin';
      existingAdmin.is_admin = true;
      existingAdmin.is_active = true;
      existingAdmin.status = 'approved';
      existingAdmin.username = adminData.username;
      existingAdmin.createdBy = superAdminUser._id;
      
      await existingAdmin.save();
      console.log('✅ Admin user updated successfully');
    } else {
      const admin = new User({
        username: adminData.username,
        email: adminData.email,
        password: adminData.password,
        role: 'admin',
        is_admin: true,
        is_active: true,
        status: 'approved',
        createdBy: superAdminUser._id,
        activation_key: crypto.randomBytes(32).toString('hex')
      });

      await admin.save();
      console.log('✅ Admin user created successfully');
    }

    // Summary
    console.log('\n🎉 User seeding complete!');
    console.log('\n📋 Admin User:');
    console.log('   📧 Email: nisaiqbal000@gmail.com');
    console.log('   🔑 Password: 123456789');
    console.log('   👤 Role: admin');
    
    console.log('\n📋 SuperAdmin User:');
    console.log('   📧 Email: superadmin@cyberrazor.com');
    console.log('   🔑 Password: superadmin123');
    console.log('   👑 Role: superadmin');

  } catch (error) {
    console.error('❌ Error seeding users:', error);
    console.error('Error details:', error.message);
  } finally {
    await mongoose.disconnect();
    console.log('\n🔌 Disconnected from MongoDB');
    process.exit(0);
  }
};

seedUsers();
