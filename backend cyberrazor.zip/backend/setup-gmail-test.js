#!/usr/bin/env node
/**
 * Quick Gmail Setup and Test Script
 */

const readline = require('readline');
const gmailService = require('./services/gmailService');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function askQuestion(question) {
  return new Promise((resolve) => {
    rl.question(question, resolve);
  });
}

async function setupAndTest() {
  console.log('╔══════════════════════════════════════════════════════════════╗');
  console.log('║                    🚀 GMAIL API QUICK SETUP                 ║');
  console.log('║                CyberRazor User Approval                     ║');
  console.log('╚══════════════════════════════════════════════════════════════╝');
  console.log();

  try {
    // Check if already authorized
    if (gmailService.isAuthorized()) {
      console.log('✅ Gmail service is already authorized!');
      console.log('📧 Testing approval email to rminhal783@gmail.com...');
      
      const result = await gmailService.sendApprovalEmail('rminhal783@gmail.com', 'Test User');
      
      if (result.success) {
        console.log('✅ Test approval email sent successfully!');
        console.log(`   Message ID: ${result.messageId}`);
      } else {
        console.log('❌ Test email failed:', result.error);
      }
      
      rl.close();
      return;
    }

    console.log('🔧 Gmail service requires OAuth2 authorization.');
    console.log('📋 Follow these steps:');
    console.log();
    console.log('1. Visit the authorization URL below');
    console.log('2. Sign in with cyberrazor0123@gmail.com');
    console.log('3. Grant permissions to the application');
    console.log('4. Copy the authorization code from the redirect URL');
    console.log();

    // Get authorization URL
    const authUrl = gmailService.getAuthUrl();
    console.log('🔗 Authorization URL:');
    console.log(authUrl);
    console.log();

    const code = await askQuestion('Enter the authorization code: ');

    if (!code.trim()) {
      console.log('❌ No authorization code provided. Setup cancelled.');
      rl.close();
      return;
    }

    console.log('🔄 Authorizing Gmail service...');
    const authResult = await gmailService.authorize(code.trim());

    if (authResult.success) {
      console.log('✅ Gmail service authorized successfully!');
      console.log('📧 Testing approval email to rminhal783@gmail.com...');
      
      const result = await gmailService.sendApprovalEmail('rminhal783@gmail.com', 'Test User');
      
      if (result.success) {
        console.log('✅ Test approval email sent successfully!');
        console.log(`   Message ID: ${result.messageId}`);
        console.log('🎉 Gmail API is working correctly!');
      } else {
        console.log('❌ Test email failed:', result.error);
      }
    } else {
      console.log('❌ Authorization failed:', authResult.error);
      console.log('💡 Please try again with a valid authorization code.');
    }

  } catch (error) {
    console.log('❌ Setup error:', error.message);
  }

  rl.close();
}

// Run setup
setupAndTest().then(() => {
  console.log();
  console.log('🏁 Gmail setup and test completed!');
  process.exit(0);
}).catch((error) => {
  console.log('❌ Setup failed:', error.message);
  process.exit(1);
});
