const mongoose = require('mongoose');
const { logger } = require('./logger');

let isConnected = false;

const connectDB = async () => {
  if (isConnected) {
    return true;
  }

  try {
    const mongoURL = process.env.MONGODB_URL;
    const dbName = process.env.MONGODB_DB_NAME || 'cyberrazor_enterprise';

    if (!mongoURL) {
      logger.error('MONGODB_URL not configured');
      return false;
    }

    logger.info(`🔗 Attempting to connect to MongoDB...`);
    logger.info(`📍 Database: ${dbName}`);
    logger.info(`🔐 URL: ${mongoURL.substring(0, 20)}...`);

    const options = {
      serverSelectionTimeoutMS: 10000,
      connectTimeoutMS: 10000,
      socketTimeoutMS: 10000,
      heartbeatFrequencyMS: 10000,
      maxPoolSize: 50,
      minPoolSize: 5,
      retryWrites: true,
      retryReads: true,
      bufferCommands: false
    };

    await mongoose.connect(mongoURL, options);

    // Test the connection
    await mongoose.connection.db.admin().ping();
    
    isConnected = true;
    logger.info('✅ Connected to MongoDB successfully!');
    logger.info('✅ Connection status: OPERATIONAL');
    logger.info(`✅ Database ready: ${dbName}`);

    // Initialize collections with indexes
    await initCollections();

    return true;

  } catch (error) {
    logger.error('❌ MongoDB connection error:', error);
    isConnected = false;
    return false;
  }
};

const initCollections = async () => {
  try {
    // Create indexes for better performance
    const db = mongoose.connection.db;
    
    // Helper function to create index safely
    const createIndexSafely = async (collectionName, indexSpec, options = {}) => {
      try {
        const collection = db.collection(collectionName);
        await collection.createIndex(indexSpec, options);
        logger.info(`✅ Index created for ${collectionName}: ${JSON.stringify(indexSpec)}`);
      } catch (error) {
        if (error.code === 86 || error.codeName === 'IndexKeySpecsConflict') {
          logger.warn(`⚠️ Index already exists for ${collectionName}: ${JSON.stringify(indexSpec)}`);
        } else {
          logger.error(`❌ Error creating index for ${collectionName}:`, error.message);
        }
      }
    };
    
    // Device activations index
    await createIndexSafely('device_activations', { activation_key: 1 }, { unique: true });
    
    // Threats index
    await createIndexSafely('threats', { device_id: 1 });
    
    // Agent logs index
    await createIndexSafely('agent_logs', { user_email: 1 });
    
    // Scan results index
    await createIndexSafely('scan_results', { user_email: 1 });
    
    // Scan sessions index
    await createIndexSafely('scan_sessions', { user_email: 1 });
    
    // Users index
    await createIndexSafely('users', { email: 1 }, { unique: true });
    
    // New log collections indexes
    await createIndexSafely('scanlogs', { user_email: 1, timestamp: -1 });
    await createIndexSafely('networklogs', { user_email: 1, timestamp: -1 });
    await createIndexSafely('ciaauditlogs', { user_email: 1, timestamp: -1 });
    await createIndexSafely('agentlogs', { user_email: 1, timestamp: -1 });
    
    logger.info('✅ Database indexes initialized successfully');
    
  } catch (error) {
    logger.error('❌ Error initializing collections:', error);
  }
};

const closeConnection = async () => {
  if (isConnected) {
    try {
      await mongoose.connection.close();
      isConnected = false;
      logger.info('✅ MongoDB connection closed');
    } catch (error) {
      logger.error('❌ Error closing MongoDB connection:', error);
    }
  }
};

// Handle connection events
mongoose.connection.on('connected', () => {
  logger.info('✅ MongoDB connected');
  isConnected = true;
});

mongoose.connection.on('error', (err) => {
  logger.error('❌ MongoDB connection error:', err);
  isConnected = false;
});

mongoose.connection.on('disconnected', () => {
  logger.warn('⚠️ MongoDB disconnected');
  isConnected = false;
});

// Graceful shutdown
process.on('SIGINT', async () => {
  await closeConnection();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await closeConnection();
  process.exit(0);
});

module.exports = {
  connectDB,
  closeConnection,
  isConnected: () => isConnected
};
