#!/usr/bin/env node
/**
 * Complete Production Flow Test
 * Tests the entire user approval workflow with deployed backend
 */

const axios = require('axios');

const BACKEND_URL = 'https://cyberrazorbackend.vercel.app';
const USER_PORTAL_URL = 'https://cyberrazoruser.vercel.app';

async function testCompleteProductionFlow() {
  console.log('🚀 COMPLETE PRODUCTION WORKFLOW TEST');
  console.log('=' * 60);
  console.log(`Backend: ${BACKEND_URL}`);
  console.log(`User Portal: ${USER_PORTAL_URL}`);
  console.log('=' * 60);
  
  const results = {
    backendHealth: false,
    emailService: false,
    userSignup: false,
    pendingLoginBlock: false,
    contactForm: false,
    userPortal: false
  };
  
  try {
    // Test 1: Backend Health
    console.log('\n1. 🏥 Testing Backend Health...');
    const healthResponse = await axios.get(`${BACKEND_URL}/api/health`);
    console.log('✅ Backend is healthy and responding');
    results.backendHealth = true;
    
    // Test 2: Email Service Status
    console.log('\n2. 📧 Testing Email Service...');
    try {
      const emailResponse = await axios.get(`${BACKEND_URL}/api/contact/status`);
      if (emailResponse.data.authorized) {
        console.log('✅ Email service is authorized and ready');
        results.emailService = true;
      } else {
        console.log('⚠️ Email service not authorized - Approval emails may not work');
        console.log('   This is expected if Gmail API setup is not complete');
      }
    } catch (error) {
      console.log('⚠️ Email service check failed (expected if not configured)');
    }
    
    // Test 3: User Signup (Pending Status)
    console.log('\n3. 👤 Testing User Signup...');
    const testUser = {
      username: `testuser_${Date.now()}`,
      email: `test_${Date.now()}@example.com`,
      password: 'TestPassword123!'
    };
    
    const signupResponse = await axios.post(`${BACKEND_URL}/api/auth/signup`, testUser);
    if (signupResponse.data.success) {
      console.log('✅ User signup successful');
      console.log(`   Status: ${signupResponse.data.user.status}`);
      console.log(`   Message: ${signupResponse.data.message}`);
      results.userSignup = true;
      
      // Test 4: Pending User Login (Should Fail)
      console.log('\n4. 🚫 Testing Pending User Login (should fail)...');
      try {
        await axios.post(`${BACKEND_URL}/api/auth/login`, {
          email: testUser.email,
          password: testUser.password
        });
        console.log('❌ Pending user login should have failed but succeeded');
      } catch (loginError) {
        if (loginError.response?.status === 403 && loginError.response?.data?.status === 'pending') {
          console.log('✅ Pending user login correctly blocked');
          console.log(`   Message: ${loginError.response.data.message}`);
          results.pendingLoginBlock = true;
        } else {
          console.log('❌ Unexpected login error:', loginError.response?.data?.message);
        }
      }
    } else {
      console.log('❌ User signup failed:', signupResponse.data.message);
    }
    
    // Test 5: Contact Form
    console.log('\n5. 📝 Testing Contact Form...');
    try {
      const contactResponse = await axios.post(`${BACKEND_URL}/api/contact/appointment`, {
        name: 'Test User',
        email: 'test@example.com',
        company: 'Test Company',
        phone: '+1234567890',
        message: 'This is a test message for custom pricing inquiry',
        service: 'Enterprise Security Package'
      });
      
      if (contactResponse.data.success) {
        console.log('✅ Contact form working');
        console.log(`   Message: ${contactResponse.data.message}`);
        results.contactForm = true;
      } else {
        console.log('⚠️ Contact form failed:', contactResponse.data.message);
      }
    } catch (error) {
      console.log('❌ Contact form error:', error.response?.data?.message || error.message);
    }
    
    // Test 6: User Portal Accessibility
    console.log('\n6. 🌐 Testing User Portal...');
    try {
      const portalResponse = await axios.get(USER_PORTAL_URL);
      console.log('✅ User portal is accessible');
      results.userPortal = true;
    } catch (error) {
      console.log('❌ User portal not accessible:', error.message);
    }
    
    // Generate Report
    console.log('\n' + '=' * 60);
    console.log('📊 PRODUCTION WORKFLOW TEST RESULTS');
    console.log('=' * 60);
    
    const tests = [
      { name: 'Backend Health', result: results.backendHealth },
      { name: 'User Signup (Pending)', result: results.userSignup },
      { name: 'Pending Login Block', result: results.pendingLoginBlock },
      { name: 'Contact Form', result: results.contactForm },
      { name: 'User Portal Access', result: results.userPortal }
    ];
    
    tests.forEach(test => {
      const status = test.result ? '✅ PASS' : '❌ FAIL';
      console.log(`${status} - ${test.name}`);
    });
    
    const passedTests = tests.filter(t => t.result).length;
    const totalTests = tests.length;
    
    console.log('=' * 60);
    console.log(`📈 RESULTS: ${passedTests}/${totalTests} tests passed`);
    
    if (passedTests === totalTests) {
      console.log('🎉 ALL CORE TESTS PASSED!');
      console.log('\n✅ PRODUCTION WORKFLOW STATUS: FULLY OPERATIONAL');
      console.log('\n📋 WORKFLOW SUMMARY:');
      console.log('1. ✅ Users can sign up and get pending status');
      console.log('2. ✅ Pending users cannot login (blocked correctly)');
      console.log('3. ✅ Contact form sends to cyberrazor0123@gmail.com');
      console.log('4. ✅ User portal is accessible');
      console.log('5. ✅ Backend API is fully functional');
      
      console.log('\n🔧 NEXT STEPS FOR COMPLETE SETUP:');
      console.log('1. Complete Gmail API authorization for approval emails');
      console.log('2. Test admin approval flow with admin credentials');
      console.log('3. Verify approval emails are sent to users');
      console.log('4. Test approved user login to user portal');
      
    } else {
      console.log('⚠️ Some tests failed - Please check the issues above');
    }
    
    console.log('\n🔗 PRODUCTION URLS:');
    console.log(`   Backend API: ${BACKEND_URL}`);
    console.log(`   User Portal: ${USER_PORTAL_URL}`);
    console.log(`   Admin Panel: [Your admin panel URL]`);
    console.log(`   Website: [Your website URL]`);
    
  } catch (error) {
    console.log('❌ Production test failed:', error.message);
    console.log('\n🔧 TROUBLESHOOTING:');
    console.log('1. Check if backend is deployed and accessible');
    console.log('2. Verify the BACKEND_URL is correct');
    console.log('3. Check if all environment variables are set in production');
  }
}

testCompleteProductionFlow();
