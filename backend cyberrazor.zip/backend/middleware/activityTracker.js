const Activity = require('../models/Activity');
const { logger } = require('../config/logger');

/**
 * Middleware to track system activities
 */
class ActivityTracker {
  /**
   * Broadcast activity update via WebSocket
   */
  static async broadcastActivity(activity, wsService) {
    if (wsService) {
      try {
        wsService.broadcastActivityUpdate(activity.formatForDisplay());
      } catch (error) {
        logger.error('Error broadcasting activity update:', error);
      }
    }
  }
  /**
   * Track admin creation activity
   */
  static async trackAdminCreated(admin, createdBy, req = null) {
    try {
      const activity = await Activity.createActivity({
        type: 'admin_created',
        action: `New admin account created: ${admin.username}`,
        description: `Admin account created for ${admin.email} with role ${admin.role}`,
        performedBy: createdBy._id,
        performedByEmail: createdBy.email,
        targetId: admin._id,
        targetType: 'admin',
        targetName: admin.username,
        category: 'user_management',
        severity: 'medium',
        metadata: {
          adminEmail: admin.email,
          adminRole: admin.role,
          adminStatus: admin.is_active ? 'active' : 'inactive'
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Admin created - ${admin.username} by ${createdBy.email}`);
      return activity;
    } catch (error) {
      logger.error('Error tracking admin creation activity:', error);
      return null;
    }
  }

  /**
   * Track admin update activity
   */
  static async trackAdminUpdated(admin, updatedBy, changes, req = null) {
    try {
      await Activity.createActivity({
        type: 'admin_updated',
        action: `Admin account updated: ${admin.username}`,
        description: `Admin account updated with changes: ${Object.keys(changes).join(', ')}`,
        performedBy: updatedBy._id,
        performedByEmail: updatedBy.email,
        targetId: admin._id,
        targetType: 'admin',
        targetName: admin.username,
        category: 'user_management',
        severity: 'low',
        metadata: {
          adminEmail: admin.email,
          changes: changes,
          updatedFields: Object.keys(changes)
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Admin updated - ${admin.username} by ${updatedBy.email}`);
    } catch (error) {
      logger.error('Error tracking admin update activity:', error);
    }
  }

  /**
   * Track admin deletion activity
   */
  static async trackAdminDeleted(admin, deletedBy, req = null) {
    try {
      await Activity.createActivity({
        type: 'admin_deleted',
        action: `Admin account deleted: ${admin.username}`,
        description: `Admin account permanently deleted for ${admin.email}`,
        performedBy: deletedBy._id,
        performedByEmail: deletedBy.email,
        targetId: admin._id,
        targetType: 'admin',
        targetName: admin.username,
        category: 'user_management',
        severity: 'high',
        metadata: {
          adminEmail: admin.email,
          adminRole: admin.role,
          deletionReason: 'Manual deletion by superadmin'
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Admin deleted - ${admin.username} by ${deletedBy.email}`);
    } catch (error) {
      logger.error('Error tracking admin deletion activity:', error);
    }
  }

  /**
   * Track admin status toggle activity
   */
  static async trackAdminStatusToggled(admin, toggledBy, newStatus, req = null) {
    try {
      await Activity.createActivity({
        type: 'admin_status_toggled',
        action: `Admin account ${newStatus ? 'activated' : 'deactivated'}: ${admin.username}`,
        description: `Admin account status changed to ${newStatus ? 'active' : 'inactive'}`,
        performedBy: toggledBy._id,
        performedByEmail: toggledBy.email,
        targetId: admin._id,
        targetType: 'admin',
        targetName: admin.username,
        category: 'user_management',
        severity: 'medium',
        metadata: {
          adminEmail: admin.email,
          previousStatus: !newStatus,
          newStatus: newStatus,
          action: newStatus ? 'activate' : 'deactivate'
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Admin status toggled - ${admin.username} by ${toggledBy.email}`);
    } catch (error) {
      logger.error('Error tracking admin status toggle activity:', error);
    }
  }

  /**
   * Track bug report creation activity
   */
  static async trackBugCreated(bug, reportedBy, req = null) {
    try {
      await Activity.createActivity({
        type: 'bug_created',
        action: `New bug report created: ${bug.title}`,
        description: `Bug report submitted with priority ${bug.priority}`,
        performedBy: reportedBy._id,
        performedByEmail: reportedBy.email,
        targetId: bug._id,
        targetType: 'bug',
        targetName: bug.title,
        category: 'bug_management',
        severity: bug.priority === 'critical' ? 'critical' : bug.priority === 'high' ? 'high' : 'medium',
        metadata: {
          bugTitle: bug.title,
          bugPriority: bug.priority,
          bugStatus: bug.status,
          bugTags: bug.tags
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Bug created - ${bug.title} by ${reportedBy.email}`);
    } catch (error) {
      logger.error('Error tracking bug creation activity:', error);
    }
  }

  /**
   * Track bug report update activity
   */
  static async trackBugUpdated(bug, updatedBy, changes, req = null) {
    try {
      await Activity.createActivity({
        type: 'bug_updated',
        action: `Bug report updated: ${bug.title}`,
        description: `Bug report updated with changes: ${Object.keys(changes).join(', ')}`,
        performedBy: updatedBy._id,
        performedByEmail: updatedBy.email,
        targetId: bug._id,
        targetType: 'bug',
        targetName: bug.title,
        category: 'bug_management',
        severity: bug.priority === 'critical' ? 'critical' : bug.priority === 'high' ? 'high' : 'medium',
        metadata: {
          bugTitle: bug.title,
          bugPriority: bug.priority,
          bugStatus: bug.status,
          changes: changes,
          updatedFields: Object.keys(changes)
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Bug updated - ${bug.title} by ${updatedBy.email}`);
    } catch (error) {
      logger.error('Error tracking bug update activity:', error);
    }
  }

  /**
   * Track bug report deletion activity
   */
  static async trackBugDeleted(bug, deletedBy, req = null) {
    try {
      await Activity.createActivity({
        type: 'bug_deleted',
        action: `Bug report deleted: ${bug.title}`,
        description: `Bug report permanently deleted`,
        performedBy: deletedBy._id,
        performedByEmail: deletedBy.email,
        targetId: bug._id,
        targetType: 'bug',
        targetName: bug.title,
        category: 'bug_management',
        severity: 'high',
        metadata: {
          bugTitle: bug.title,
          bugPriority: bug.priority,
          bugStatus: bug.status,
          deletionReason: 'Manual deletion by superadmin'
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Bug deleted - ${bug.title} by ${deletedBy.email}`);
    } catch (error) {
      logger.error('Error tracking bug deletion activity:', error);
    }
  }

  /**
   * Track bug assignment activity
   */
  static async trackBugAssigned(bug, assignedBy, assignedTo, req = null) {
    try {
      await Activity.createActivity({
        type: 'bug_assigned',
        action: `Bug report assigned: ${bug.title}`,
        description: `Bug report assigned to ${assignedTo.username || assignedTo.email}`,
        performedBy: assignedBy._id,
        performedByEmail: assignedBy.email,
        targetId: bug._id,
        targetType: 'bug',
        targetName: bug.title,
        category: 'bug_management',
        severity: 'medium',
        metadata: {
          bugTitle: bug.title,
          bugPriority: bug.priority,
          assignedTo: assignedTo.username || assignedTo.email,
          assignedToId: assignedTo._id
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Bug assigned - ${bug.title} by ${assignedBy.email}`);
    } catch (error) {
      logger.error('Error tracking bug assignment activity:', error);
    }
  }

  /**
   * Track bug resolution activity
   */
  static async trackBugResolved(bug, resolvedBy, req = null) {
    try {
      await Activity.createActivity({
        type: 'bug_resolved',
        action: `Bug report resolved: ${bug.title}`,
        description: `Bug report marked as resolved`,
        performedBy: resolvedBy._id,
        performedByEmail: resolvedBy.email,
        targetId: bug._id,
        targetType: 'bug',
        targetName: bug.title,
        category: 'bug_management',
        severity: 'medium',
        metadata: {
          bugTitle: bug.title,
          bugPriority: bug.priority,
          resolutionStatus: bug.status,
          resolutionTime: new Date().toISOString()
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: Bug resolved - ${bug.title} by ${resolvedBy.email}`);
    } catch (error) {
      logger.error('Error tracking bug resolution activity:', error);
    }
  }

  /**
   * Track user registration activity
   */
  static async trackUserRegistered(user, req = null) {
    try {
      await Activity.createActivity({
        type: 'user_registered',
        action: `New user registered: ${user.username}`,
        description: `User account created and pending approval`,
        performedBy: user._id,
        performedByEmail: user.email,
        targetId: user._id,
        targetType: 'user',
        targetName: user.username,
        category: 'user_management',
        severity: 'low',
        metadata: {
          userEmail: user.email,
          userRole: user.role,
          userStatus: user.status,
          activationKey: user.activation_key
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: User registered - ${user.username}`);
    } catch (error) {
      logger.error('Error tracking user registration activity:', error);
    }
  }

  /**
   * Track user approval activity
   */
  static async trackUserApproved(user, approvedBy, req = null) {
    try {
      await Activity.createActivity({
        type: 'user_approved',
        action: `User account approved: ${user.username}`,
        description: `User account approved and activated`,
        performedBy: approvedBy._id,
        performedByEmail: approvedBy.email,
        targetId: user._id,
        targetType: 'user',
        targetName: user.username,
        category: 'user_management',
        severity: 'medium',
        metadata: {
          userEmail: user.email,
          userRole: user.role,
          trialStartDate: user.trial_start_date,
          trialEndDate: user.trial_end_date
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: User approved - ${user.username} by ${approvedBy.email}`);
    } catch (error) {
      logger.error('Error tracking user approval activity:', error);
    }
  }

  /**
   * Track user rejection activity
   */
  static async trackUserRejected(user, rejectedBy, reason, req = null) {
    try {
      await Activity.createActivity({
        type: 'user_rejected',
        action: `User account rejected: ${user.username}`,
        description: `User account rejected with reason: ${reason}`,
        performedBy: rejectedBy._id,
        performedByEmail: rejectedBy.email,
        targetId: user._id,
        targetType: 'user',
        targetName: user.username,
        category: 'user_management',
        severity: 'medium',
        metadata: {
          userEmail: user.email,
          userRole: user.role,
          rejectionReason: reason
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: User rejected - ${user.username} by ${rejectedBy.email}`);
    } catch (error) {
      logger.error('Error tracking user rejection activity:', error);
    }
  }

  /**
   * Track login activity
   */
  static async trackLogin(user, success, req = null) {
    try {
      await Activity.createActivity({
        type: success ? 'login_success' : 'login_failed',
        action: success ? `Successful login: ${user.username}` : `Failed login attempt: ${user.email}`,
        description: success ? 'User successfully logged in' : 'Failed login attempt',
        performedBy: success ? user._id : null,
        performedByEmail: user.email,
        targetId: success ? user._id : null,
        targetType: 'user',
        targetName: user.username || user.email,
        category: 'authentication',
        severity: success ? 'low' : 'medium',
        metadata: {
          userEmail: user.email,
          success: success,
          loginAttempts: user.login_attempts || 0
        },
        ipAddress: req?.ip,
        userAgent: req?.get('User-Agent')
      });
      
      logger.info(`Activity tracked: ${success ? 'Login success' : 'Login failed'} - ${user.email}`);
    } catch (error) {
      logger.error('Error tracking login activity:', error);
    }
  }

  /**
   * Track system alert activity
   */
  static async trackSystemAlert(alertType, message, severity = 'medium', metadata = {}) {
    try {
      await Activity.createActivity({
        type: 'system_alert',
        action: `System alert: ${alertType}`,
        description: message,
        performedBy: null,
        performedByEmail: 'system',
        targetId: null,
        targetType: 'system',
        targetName: 'System',
        category: 'system',
        severity: severity,
        metadata: {
          alertType: alertType,
          ...metadata
        }
      });
      
      logger.info(`Activity tracked: System alert - ${alertType}`);
    } catch (error) {
      logger.error('Error tracking system alert activity:', error);
    }
  }
}

module.exports = ActivityTracker;
