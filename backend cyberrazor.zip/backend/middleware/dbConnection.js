const mongoose = require('mongoose');
const { connectDB, isConnected } = require('../config/database');

let connectionPromise = null;

const ensureDbConnection = async (req, res, next) => {
  if (isConnected()) {
    req.app.locals.db = mongoose.connection.db;
    return next();
  }

  if (connectionPromise) {
    await connectionPromise;
    req.app.locals.db = mongoose.connection.db;
    return next();
  }

  connectionPromise = connectDB();
  await connectionPromise;
  connectionPromise = null;
  req.app.locals.db = mongoose.connection.db;
  
  next();
};

module.exports = ensureDbConnection;
