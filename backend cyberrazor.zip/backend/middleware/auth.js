const jwt = require('jsonwebtoken');
const { logger } = require('../config/logger');
const User = require('../models/User');

const requireAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    // Log whether an Authorization header exists (do NOT log the token value)
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      logger.warn(`Unauthorized request - missing or malformed Authorization header for ${req.method} ${req.originalUrl}`);
      return res.status(401).json({
        error: 'Access denied',
        message: 'No token provided'
      });
    }

    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    if (!token) {
      logger.warn(`Unauthorized request - empty Bearer token for ${req.method} ${req.originalUrl}`);
      return res.status(401).json({
        error: 'Access denied',
        message: 'No token provided'
      });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    if (!decoded.sub) {
      return res.status(401).json({
        error: 'Invalid token',
        message: 'Token payload is invalid'
      });
    }

    // Get user from database
    const user = await User.findOne({ email: decoded.sub });
    
    if (!user) {
      return res.status(401).json({
        error: 'User not found',
        message: 'Token is valid but user no longer exists'
      });
    }

    // Add user to request object
    req.user = {
      _id: user._id,
      id: user._id.toString(),
      email: user.email,
      username: user.username,
      role: user.role,
      is_admin: user.is_admin,
      activation_key: user.activation_key
    };

    next();
    
  } catch (error) {
    logger.error('Authentication error:', error);
    
    if (error.name === 'JsonWebTokenError') {
      logger.warn(`JWT verification failed for ${req.method} ${req.originalUrl}: ${error.message}`);
      return res.status(401).json({
        error: 'Invalid token',
        message: 'Token is malformed or invalid'
      });
    }
    
    if (error.name === 'TokenExpiredError') {
      logger.warn(`JWT expired for ${req.method} ${req.originalUrl}`);
      return res.status(401).json({
        error: 'Token expired',
        message: 'Authentication token has expired'
      });
    }
    
    return res.status(500).json({
      error: 'Authentication failed',
      message: 'Internal server error during authentication'
    });
  }
};

const requireAdmin = async (req, res, next) => {
  try {
    // First check if user is authenticated
    await requireAuth(req, res, (err) => {
      if (err) return next(err);
    });

    // Then check if user is admin or superadmin
    if (!req.user.is_admin && req.user.role !== 'admin' && req.user.role !== 'superadmin') {
      return res.status(403).json({
        error: 'Access denied',
        message: 'Admin privileges required'
      });
    }

    next();
    
  } catch (error) {
    logger.error('Admin authentication error:', error);
    return res.status(500).json({
      error: 'Admin authentication failed',
      message: 'Internal server error during admin authentication'
    });
  }
};

const requireSuperAdmin = async (req, res, next) => {
  try {
    // First check if user is authenticated
    await requireAuth(req, res, (err) => {
      if (err) return next(err);
    });

    // Then check if user is superadmin
    if (req.user.role !== 'superadmin') {
      return res.status(403).json({
        error: 'Access denied',
        message: 'SuperAdmin privileges required'
      });
    }

    next();
    
  } catch (error) {
    logger.error('SuperAdmin authentication error:', error);
    return res.status(500).json({
      error: 'SuperAdmin authentication failed',
      message: 'Internal server error during superadmin authentication'
    });
  }
};

const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // No token provided, continue without authentication
      req.user = null;
      return next();
    }

    const token = authHeader.substring(7);
    
    if (!token) {
      req.user = null;
      return next();
    }

    // Try to verify token
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      if (decoded.sub) {
        const user = await User.findOne({ email: decoded.sub });
        
        if (user) {
          req.user = {
            _id: user._id,
            id: user._id.toString(),
            email: user.email,
            username: user.username,
            role: user.role,
            is_admin: user.is_admin,
            activation_key: user.activation_key
          };
        }
      }
    } catch (tokenError) {
      // Token is invalid, but we don't fail the request
      logger.warn('Invalid token in optional auth:', tokenError.message);
      req.user = null;
    }

    next();
    
  } catch (error) {
    logger.error('Optional authentication error:', error);
    req.user = null;
    next();
  }
};

module.exports = {
  requireAuth,
  requireAdmin,
  requireSuperAdmin,
  optionalAuth
};
