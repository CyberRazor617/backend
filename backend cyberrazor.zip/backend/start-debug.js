#!/usr/bin/env node
/**
 * Debug startup script for CyberRazor Backend
 */

console.log('🔍 Starting CyberRazor Backend in debug mode...');

// Check environment variables
console.log('\n📋 Environment Check:');
console.log('NODE_ENV:', process.env.NODE_ENV || 'development');
console.log('PORT:', process.env.PORT || '8000');
console.log('MONGODB_URI:', process.env.MONGODB_URI ? 'Set' : 'Not set');
console.log('JWT_SECRET:', process.env.JWT_SECRET ? 'Set' : 'Not set');
console.log('GEMINI_API_KEY:', process.env.GEMINI_API_KEY ? 'Set' : 'Not set');

// Check required packages
console.log('\n📦 Package Check:');
try {
  require('express');
  console.log('✅ express');
} catch (e) {
  console.log('❌ express:', e.message);
}

try {
  require('mongoose');
  console.log('✅ mongoose');
} catch (e) {
  console.log('❌ mongoose:', e.message);
}

try {
  require('ws');
  console.log('✅ ws');
} catch (e) {
  console.log('❌ ws:', e.message);
}

try {
  require('jsonwebtoken');
  console.log('✅ jsonwebtoken');
} catch (e) {
  console.log('❌ jsonwebtoken:', e.message);
}

// Try to start the server
console.log('\n🚀 Starting server...');
try {
  require('./server.js');
} catch (error) {
  console.error('❌ Server startup failed:', error.message);
  console.error('Stack trace:', error.stack);
  process.exit(1);
}
