# Admin User Credentials

## Successfully Registered Users

### Admin User
- **Email**: nisaiqbal000@gmail.com
- **Password**: 123456789
- **Role**: admin
- **Status**: approved
- **Active**: Yes

### SuperAdmin User
- **Email**: superadmin@cyberrazor.com
- **Password**: superadmin123
- **Role**: superadmin
- **Status**: approved
- **Active**: Yes

## Database Connection
- **MongoDB URL**: mongodb+srv://digibryx:mesumzain786@cluster0.hlnj4ui.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0

## Login Verification
Both users have been tested and verified to login successfully. Their passwords are properly hashed and stored in the database.

## Scripts Created
1. **seed-admin-users.js** - Script to create/update admin and superadmin users
2. **test-login.js** - Script to verify login credentials

## Usage
To re-run the seeding script if needed:
```bash
cd H:\Development\CyberRazor\frontend\backend
node scripts/seed-admin-users.js
```

To test login credentials:
```bash
cd H:\Development\CyberRazor\frontend\backend
node scripts/test-login.js
```

## Notes
- Both users have `status: 'approved'` and `is_active: true`
- Both users have `is_admin: true`
- Admin user was created with SuperAdmin as the creator (required by the User model)
- Passwords are hashed using bcrypt with 12 rounds (default)
- Each user has a unique activation key generated
