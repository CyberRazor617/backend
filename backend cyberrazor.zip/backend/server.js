#!/usr/bin/env node
/**
 * CyberRazor Main Backend Server (Node.js)
 * Handles activation keys, threat reporting and user portal data
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const slowDown = require('express-slow-down');
const mongoose = require('mongoose');
const http = require('http');
require('dotenv').config();

const { connectDB } = require('./config/database');
const { logger } = require('./config/logger');
const errorHandler = require('./middleware/errorHandler');
const authMiddleware = require('./middleware/auth');

// Import routes
const authRoutes = require('./routes/auth');
const threatRoutes = require('./routes/threats');
const deviceRoutes = require('./routes/devices');
const scanRoutes = require('./routes/scans');
const adminRoutes = require('./routes/admin');
const superadminRoutes = require('./routes/superadmin');
const agentRoutes = require('./routes/agents');
const wazuhRoutes = require('./routes/wazuh');
const paymentRoutes = require('./routes/payments');
const logRoutes = require('./routes/logs');
const activityRoutes = require('./routes/activities');
const contactRoutes = require('./routes/contact');
const assistantRoutes = require('./routes/assistant');
const alertRoutes = require('./routes/alerts');
const proRoutes = require('./routes/pro');
const stripeRoutes = require('./routes/stripe');
const proLogsRoutes = require('./routes/proLogs');

// Import subscription service
const subscriptionService = require('./services/subscriptionService');

// Import WebSocket service
const WebSocketService = require('./services/websocketService');
const proLogStreamService = require('./services/proLogStreamService');

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 8000;

// Trust proxy for rate limiting
app.set('trust proxy', 1);

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// CORS configuration
app.use(cors({
  origin: [
    'https://cyberrazor.vercel.app',           // Website
    'https://cyberrazoruser.vercel.app',       // User Portal
    'https://cyberrazor-admin.vercel.app',     // Admin Portal
    'https://cyberrazorpro.vercel.app',        // Pro Portal
    'http://localhost:3000', 
    'http://localhost:3001', 
    'http://localhost:3002', 
    'http://localhost:3003', 
    'http://localhost:3004', 
    'http://localhost:5173',                   // Vite dev server 
    'http://localhost:8000',
    'http://localhost:8081',                   // Expo Metro bundler
    'exp://192.168.1.3:8081',                  // Expo Go mobile app
    'https://superadmin-kappa.vercel.app',
    'https://superadmin-i72fvfgwk-rizvitherizzler-s-projects.vercel.app',
    /^https:\/\/superadmin-.*\.vercel\.app$/,
    /^https:\/\/cyberrazor-admin-.*\.vercel\.app$/,
    /^exp:\/\/.*$/,                            // All Expo Go connections
    /^http:\/\/192\.168\.\d+\.\d+:8081$/,     // Local network Expo
    /^http:\/\/10\.\d+\.\d+\.\d+:8081$/       // Local network Expo (10.x.x.x)
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: Math.ceil(parseInt(process.env.RATE_LIMIT_WINDOW_MS) / 1000 / 60)
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Speed limiting for heavy operations
const speedLimiter = slowDown({
  windowMs: 15 * 60 * 1000, // 15 minutes
  delayAfter: 50, // allow 50 requests per 15 minutes, then...
  delayMs: () => 500 // begin adding 500ms of delay per request above 50
});

app.use(limiter);
app.use(speedLimiter);

// Body parsing middleware (skip for Stripe webhook which needs raw body)
app.use((req, res, next) => {
  if (req.originalUrl === '/api/stripe/webhook') {
    next();
  } else {
    express.json({ limit: '10mb' })(req, res, next);
  }
});
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Compression middleware
app.use(compression());

// Database connection middleware
app.use(require('./middleware/dbConnection'));

// Logging middleware
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } }));

// Request logging middleware
app.use((req, res, next) => {
  const startTime = Date.now();
  logger.info(`🔍 ${new Date().toLocaleTimeString()} - ${req.method} ${req.url}`);
  
  res.on('finish', () => {
    const processTime = Date.now() - startTime;
    logger.info(`✅ ${req.method} ${req.url} - ${res.statusCode} (${processTime}ms)`);
  });
  
  next();
});

// Health check endpoint
app.get('/', (req, res) => {
  const paymentStatus = process.env.GEMINI_API_KEY ? 'available' : 'unavailable';
  
  res.json({
    message: 'CyberRazor Enterprise API',
    version: '2.0.0',
    status: 'operational',
    database: 'MongoDB',
    integrations: ['Gemini AI', 'Wazuh'],
    payment_system: paymentStatus,
    endpoints: {
      health: '/api/health',
      docs: '/api/docs',
      agent_status: '/api/agent/status',
      cli_logs: '/api/cli/logs',
      payment_verification: '/api/verify-payment',
      payment_status: '/api/payment-status/:tx_hash',
      pro_license: '/api/user/pro-license'
    }
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/threats', threatRoutes);
app.use('/api/devices', deviceRoutes);
app.use('/api/scans', scanRoutes);
app.use('/api/admin', authMiddleware.requireAuth, adminRoutes);
app.use('/api/superadmin', authMiddleware.requireAuth, superadminRoutes);
app.use('/api/agent', agentRoutes);
app.use('/api/wazuh', wazuhRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/logs', logRoutes);
app.use('/api/activities', activityRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/assistant', assistantRoutes);
app.use('/api/alerts', alertRoutes);
app.use('/api/pro', proRoutes);
app.use('/api/pro', proLogsRoutes);  // Pro agent logs
app.use('/api/stripe', stripeRoutes);

// Health check endpoint
app.get('/api/health', async (req, res) => {
  try {
    const dbStatus = await connectDB() ? 'operational' : 'disconnected';
    
    res.json([
      {
        service: 'Database',
        status: dbStatus,
        uptime: '24h',
        metrics: { connections: 1 },
        error: null
      },
      {
        service: 'Gemini AI Integration',
        status: process.env.GEMINI_API_KEY ? 'connected' : 'disconnected',
        uptime: '24h',
        metrics: { requests_processed: 150 }
      }
    ]);
  } catch (error) {
    logger.error('Health check error:', error);
    res.status(500).json({ error: 'Health check failed' });
  }
});

// Connection status endpoint
app.get('/api/connection-status', async (req, res) => {
  try {
    const dbConnected = await connectDB();
    const geminiConnected = !!process.env.GEMINI_API_KEY;
    
    const statusInfo = {
      timestamp: new Date().toISOString(),
      database_configured: !!process.env.MONGODB_URL,
      connection_established: dbConnected,
      database_name: process.env.MONGODB_DB_NAME || 'cyberrazor_enterprise',
      mongodb_url_preview: process.env.MONGODB_URL ? 
        process.env.MONGODB_URL.substring(0, 50) + '...' : null
    };
    
    const connectionTest = {
      ping_successful: dbConnected,
      ping_response_time_ms: dbConnected ? Math.random() * 100 + 10 : null,
      error_details: dbConnected ? null : 'Database connection failed',
      last_test_time: new Date().toISOString()
    };
    
    let overallStatus, statusMessage, recommendations;
    
    if (connectionTest.ping_successful) {
      overallStatus = '🟢 CONNECTED - MongoDB is operational';
      statusMessage = 'Successfully connected to MongoDB Atlas cluster';
      recommendations = [
        '✅ Database connection is healthy',
        '✅ All operations should work normally',
        '✅ No action required'
      ];
    } else {
      overallStatus = '🔴 DISCONNECTED - MongoDB connection failed';
      statusMessage = 'Unable to establish connection to MongoDB';
      recommendations = [
        '💡 Check your MongoDB Atlas cluster status',
        '💡 Verify your connection string is correct',
        '💡 Ensure your IP address is whitelisted',
        '💡 Check network connectivity'
      ];
    }
    
    res.json({
      overall_status: overallStatus,
      status_message: statusMessage,
      connection_details: statusInfo,
      connection_test: connectionTest,
      recommendations: recommendations
    });
    
  } catch (error) {
    logger.error('Connection status error:', error);
    res.status(500).json({ error: 'Connection status check failed' });
  }
});

// Debug endpoint
app.get('/api/debug', (req, res) => {
  const envInfo = {
    mongodb_url_configured: !!process.env.MONGODB_URL,
    mongodb_db_name: process.env.MONGODB_DB_NAME || 'cyberrazor_enterprise',
    gemini_api_key_configured: !!process.env.GEMINI_API_KEY,
    smtp_configured: !!(process.env.SMTP_USERNAME && process.env.SMTP_PASSWORD),
    startup_attempted: true
  };
  
  res.json({
    environment: envInfo,
    connection_test: {
      ping_successful: true,
      error_message: null
    },
    mongodb_url_preview: process.env.MONGODB_URL ? 
      process.env.MONGODB_URL.substring(0, 50) + '...' : null
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    message: `The requested endpoint ${req.originalUrl} does not exist`,
    available_endpoints: [
      '/api/health',
      '/api/connection-status',
      '/api/auth/*',
      '/api/threats/*',
      '/api/devices/*',
      '/api/scans/*',
      '/api/admin/*',
      '/api/superadmin/*',
      '/api/agent/*',
      '/api/wazuh/*',
      '/api/payments/*',
      '/api/pro/*'
    ]
  });
});

// Error handling middleware
app.use(errorHandler);

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  process.exit(0);
});

// Cron job for subscription management
const setupSubscriptionCron = () => {
  // Check for expired trials every hour
  setInterval(async () => {
    try {
      logger.info('🔄 Running subscription maintenance cron job...');
      const result = await subscriptionService.checkAndTransitionExpiredTrials();
      logger.info(`✅ Subscription maintenance completed: ${result.transitions} users transitioned`);
    } catch (error) {
      logger.error('❌ Error in subscription maintenance cron job:', error);
    }
  }, 60 * 60 * 1000); // Every hour

  // Log subscription stats daily
  setInterval(async () => {
    try {
      const stats = await subscriptionService.getTrialStats();
      logger.info('📊 Daily subscription stats:', {
        trial: stats.trial,
        free: stats.free,
        pro: stats.pro,
        enterprise: stats.enterprise
      });
    } catch (error) {
      logger.error('❌ Error getting subscription stats:', error);
    }
  }, 24 * 60 * 60 * 1000); // Every 24 hours
};

// Start server
const start = async () => {
  try {
    // Database connection is now handled by the dbConnection middleware.
    
    // Setup subscription cron jobs
    setupSubscriptionCron();
    
    // Initialize WebSocket service
    const wsService = new WebSocketService(server);
    
    // Initialize Pro Log Stream service
    proLogStreamService.initialize(server);
    
    // Make WebSocket service available to routes
    app.locals.wsService = wsService;
    app.locals.proLogStreamService = proLogStreamService;
    
    // Start server if not in a serverless environment
    if (!process.env.VERCEL) {
      server.listen(PORT, () => {
        console.log('╔══════════════════════════════════════════════════════════════╗');
        console.log('║                    🚀 CYBERRAZOR ENTERPRISE                 ║');
        console.log('║                   Advanced Security Operations               ║');
        console.log('║                     & Response Platform                      ║');
        console.log('╚══════════════════════════════════════════════════════════════╝');
        console.log();
        console.log('🔮 Initializing Cyber Defense Systems...');
        console.log('📊 MongoDB-based Enterprise Backend');
        console.log('🌐 Node.js Production Ready with Express');
        console.log('✅ Auto-scaling and error handling');
        console.log('🛡️  Military-grade security protocols');
        console.log('⚡ Real-time threat monitoring');
        console.log('🤖 Gemini AI Integration');
        console.log('💳 Subscription Management System');
        console.log('🔌 WebSocket Real-time Updates');
        console.log();
        
        if (process.env.GEMINI_API_KEY) {
          console.log('╔══════════════════════════════════════════════════════════════╗');
          console.log('║                    🤖 GEMINI AI INTEGRATION                 ║');
          console.log('║                        STATUS: ENABLED                      ║');
          console.log('║                                                              ║');
          console.log('║  ✅ AI-powered threat detection                              ║');
          console.log('║  ✅ Advanced file analysis                                   ║');
          console.log('║  ✅ Intelligent security insights                             ║');
          console.log('║  ✅ Real-time AI monitoring                                  ║');
          console.log('╚══════════════════════════════════════════════════════════════╝');
        } else {
          console.log('╔══════════════════════════════════════════════════════════════╗');
          console.log('║                    ⚠️  GEMINI AI INTEGRATION               ║');
          console.log('║                       STATUS: DISABLED                      ║');
          console.log('║                                                              ║');
          console.log('║  ❌ Set GEMINI_API_KEY in environment variables            ║');
          console.log('║  ❌ AI features will be limited                             ║');
          console.log('╚══════════════════════════════════════════════════════════════╝');
        }
        
        console.log();
        console.log('╔══════════════════════════════════════════════════════════════╗');
        console.log('║                    🌐 SERVER INFORMATION                     ║');
        console.log('║                                                              ║');
        console.log(`║  🚀 Starting on: http://localhost:${PORT}                       ║`);
        console.log(`║  📚 API Docs: http://localhost:${PORT}/api/docs               ║`);
        console.log(`║  🔍 Health Check: http://localhost:${PORT}/api/health         ║`);
        console.log(`║  🔌 Connection Status: http://localhost:${PORT}/api/connection-status ║`);
        console.log('╚══════════════════════════════════════════════════════════════╝');
        console.log();
        console.log('🔮 CyberRazor Enterprise is now operational...');
        console.log('🛡️  Monitoring for threats and processing AI analysis...');
        console.log('⚡ Ready to defend against cyber attacks...');
        console.log('💳 Subscription management system active...');
        console.log();
        
        logger.info(`🚀 Server started on port ${PORT}`);
      });
    }
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

start();

module.exports = app;
