#!/usr/bin/env node
/**
 * One-time Gmail API Setup Script
 * Run this once to authorize Gmail API, then it will work automatically
 */

const readline = require('readline');
const gmailService = require('./services/gmailService');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function askQuestion(question) {
  return new Promise((resolve) => {
    rl.question(question, resolve);
  });
}

async function oneTimeSetup() {
  console.log('╔══════════════════════════════════════════════════════════════╗');
  console.log('║                    🚀 GMAIL API ONE-TIME SETUP             ║');
  console.log('║                CyberRazor Automated Email System            ║');
  console.log('╚══════════════════════════════════════════════════════════════╝');
  console.log();
  console.log('📋 This is a ONE-TIME setup. After this, emails will work automatically!');
  console.log();

  try {
    // Check if already authorized
    if (gmailService.isAuthorized()) {
      console.log('✅ Gmail API is already configured and working!');
      console.log('📧 Testing email to rminhal783@gmail.com...');
      
      const result = await gmailService.sendApprovalEmail('rminhal783@gmail.com', 'Test User');
      
      if (result.success) {
        console.log('✅ Test email sent successfully!');
        console.log('🎉 Gmail API is working perfectly!');
      } else {
        console.log('❌ Test failed:', result.error);
      }
      
      rl.close();
      return;
    }

    console.log('🔧 Setting up Gmail API for automated email sending...');
    console.log();
    console.log('📋 Follow these steps:');
    console.log('1. Visit the authorization URL below');
    console.log('2. Sign in with cyberrazor0123@gmail.com');
    console.log('3. Grant permissions to send emails');
    console.log('4. Copy the authorization code from the redirect URL');
    console.log('5. The redirect URL will be: http://localhost:3000/oauth2callback?code=XXXXX');
    console.log();

    // Get authorization URL
    const authUrl = gmailService.getAuthUrl();
    console.log('🔗 Authorization URL:');
    console.log(authUrl);
    console.log();

    const code = await askQuestion('Enter the authorization code: ');

    if (!code.trim()) {
      console.log('❌ No authorization code provided. Setup cancelled.');
      rl.close();
      return;
    }

    console.log('🔄 Authorizing Gmail API...');
    const authResult = await gmailService.authorize(code.trim());

    if (authResult.success) {
      console.log('✅ Gmail API authorized successfully!');
      console.log('💾 Tokens saved for automatic use');
      console.log();
      console.log('📧 Testing approval email to rminhal783@gmail.com...');
      
      const result = await gmailService.sendApprovalEmail('rminhal783@gmail.com', 'Test User');
      
      if (result.success) {
        console.log('✅ Test approval email sent successfully!');
        console.log(`   Message ID: ${result.messageId}`);
        console.log();
        console.log('🎉 Gmail API is now fully configured!');
        console.log('📧 All future emails will be sent automatically');
        console.log('🔄 No more authorization needed!');
      } else {
        console.log('❌ Test email failed:', result.error);
      }
    } else {
      console.log('❌ Authorization failed:', authResult.error);
      console.log('💡 Please try again with a valid authorization code.');
    }

  } catch (error) {
    console.log('❌ Setup error:', error.message);
  }

  rl.close();
}

// Run setup
oneTimeSetup().then(() => {
  console.log();
  console.log('🏁 Gmail API setup completed!');
  console.log('📧 Your CyberRazor system can now send emails automatically!');
  process.exit(0);
}).catch((error) => {
  console.log('❌ Setup failed:', error.message);
  process.exit(1);
});
