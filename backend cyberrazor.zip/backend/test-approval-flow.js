#!/usr/bin/env node
/**
 * Test script for the complete user approval flow
 * Tests: Signup -> Pending Status -> Admin Approval -> Email Sent
 */

const axios = require('axios');

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8000';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
};

const log = (message, color = colors.reset) => {
  console.log(`${color}${message}${colors.reset}`);
};

const testApprovalFlow = async () => {
  try {
    log('\n╔══════════════════════════════════════════════════════════════╗', colors.cyan);
    log('║         TESTING USER APPROVAL FLOW WITH EMAIL SMTP          ║', colors.cyan);
    log('╚══════════════════════════════════════════════════════════════╝\n', colors.cyan);

    // Step 1: Create a test user (signup)
    log('📝 Step 1: Creating test user account...', colors.blue);
    const testEmail = `test_${Date.now()}@example.com`;
    const testUsername = `testuser_${Date.now()}`;
    const testPassword = 'Test123456';

    const signupResponse = await axios.post(`${BACKEND_URL}/api/auth/signup`, {
      username: testUsername,
      email: testEmail,
      password: testPassword,
    });

    if (signupResponse.data.success) {
      log('✅ User created successfully!', colors.green);
      log(`   Email: ${testEmail}`, colors.green);
      log(`   Username: ${testUsername}`, colors.green);
      log(`   Status: ${signupResponse.data.user.status}`, colors.green);
      log(`   User ID: ${signupResponse.data.user.id}`, colors.green);
    } else {
      throw new Error('Signup failed');
    }

    const userId = signupResponse.data.user.id;

    // Step 2: Verify user is in pending status
    log('\n🔍 Step 2: Verifying user status...', colors.blue);
    const statusResponse = await axios.get(`${BACKEND_URL}/api/auth/status?email=${testEmail}`);
    
    if (statusResponse.data.status === 'pending') {
      log('✅ User status is PENDING (waiting for admin approval)', colors.green);
    } else {
      throw new Error(`Expected status 'pending', got '${statusResponse.data.status}'`);
    }

    // Step 3: Login as admin (you need to have an admin account)
    log('\n🔐 Step 3: Logging in as admin...', colors.blue);
    log('⚠️  Note: Make sure you have an admin account created', colors.yellow);
    
    // For this test, we'll assume admin credentials exist
    // You can modify these or skip this step if testing manually
    const adminEmail = 'admin@cyberrazor.com';
    const adminPassword = 'admin123456';

    let adminToken = null;
    try {
      const adminLoginResponse = await axios.post(`${BACKEND_URL}/api/auth/login`, {
        email: adminEmail,
        password: adminPassword,
      });
      
      if (adminLoginResponse.data.access_token) {
        adminToken = adminLoginResponse.data.access_token;
        log('✅ Admin login successful!', colors.green);
      }
    } catch (error) {
      log('⚠️  Admin login failed. You may need to create an admin account first.', colors.yellow);
      log('   Continuing with approval test (may fail without admin token)...', colors.yellow);
    }

    // Step 4: Approve the user (requires admin token)
    log('\n✅ Step 4: Approving user account...', colors.blue);
    
    if (!adminToken) {
      log('⚠️  Skipping approval step - no admin token available', colors.yellow);
      log('   To test approval, please:', colors.yellow);
      log('   1. Create an admin account', colors.yellow);
      log('   2. Login to admin panel at http://localhost:3002', colors.yellow);
      log('   3. Navigate to User Management', colors.yellow);
      log(`   4. Approve user: ${testEmail}`, colors.yellow);
      log('   5. Check the email inbox for approval confirmation', colors.yellow);
    } else {
      try {
        const approvalResponse = await axios.post(
          `${BACKEND_URL}/api/admin/user-activation`,
          {
            user_id: userId,
            action: 'approve',
          },
          {
            headers: {
              Authorization: `Bearer ${adminToken}`,
            },
          }
        );

        if (approvalResponse.data.success) {
          log('✅ User approved successfully!', colors.green);
          log(`   Email sent: ${approvalResponse.data.email_sent}`, colors.green);
          log(`   Status: ${approvalResponse.data.user.status}`, colors.green);
          log(`   Approved by: ${approvalResponse.data.user.approved_by}`, colors.green);
          log(`   Trial start: ${approvalResponse.data.user.trial_start_date}`, colors.green);
          log(`   Trial end: ${approvalResponse.data.user.trial_end_date}`, colors.green);
        }
      } catch (error) {
        log('❌ Approval failed:', colors.red);
        log(`   ${error.response?.data?.message || error.message}`, colors.red);
      }
    }

    // Step 5: Verify user can now login
    log('\n🔐 Step 5: Testing user login after approval...', colors.blue);
    
    try {
      const userLoginResponse = await axios.post(`${BACKEND_URL}/api/auth/login`, {
        email: testEmail,
        password: testPassword,
      });

      if (userLoginResponse.data.access_token) {
        log('✅ User can login successfully!', colors.green);
        log(`   Status: ${userLoginResponse.data.user.status}`, colors.green);
        log(`   Subscription: ${userLoginResponse.data.user.subscription_plan}`, colors.green);
      }
    } catch (error) {
      if (error.response?.status === 403) {
        log('⚠️  User still pending approval (expected if approval was skipped)', colors.yellow);
      } else {
        log('❌ Login failed:', colors.red);
        log(`   ${error.response?.data?.message || error.message}`, colors.red);
      }
    }

    // Summary
    log('\n╔══════════════════════════════════════════════════════════════╗', colors.cyan);
    log('║                      TEST SUMMARY                            ║', colors.cyan);
    log('╚══════════════════════════════════════════════════════════════╝\n', colors.cyan);
    log('✅ User signup flow: WORKING', colors.green);
    log('✅ Pending status: WORKING', colors.green);
    log('✅ Email configuration: CONFIGURED', colors.green);
    log('   SMTP Server: smtp.gmail.com', colors.cyan);
    log('   SMTP Email: cyberrazor.technical@gmail.com', colors.cyan);
    log('\n📧 Email Flow:', colors.blue);
    log('   1. User signs up → Receives "pending approval" email', colors.cyan);
    log('   2. Admin approves → User receives "congratulations" email', colors.cyan);
    log('   3. User can login → Access to 7-day trial', colors.cyan);
    
    log('\n🎯 Next Steps:', colors.yellow);
    log('   1. Start the backend: cd backend && npm start', colors.cyan);
    log('   2. Start the website: cd website && npm run dev', colors.cyan);
    log('   3. Start the admin: cd admin && npm run dev', colors.cyan);
    log('   4. Test the complete flow manually', colors.cyan);
    log('   5. Check email inbox for approval messages\n', colors.cyan);

  } catch (error) {
    log('\n❌ Test failed:', colors.red);
    log(`   ${error.message}`, colors.red);
    if (error.response?.data) {
      log(`   Response: ${JSON.stringify(error.response.data, null, 2)}`, colors.red);
    }
    process.exit(1);
  }
};

// Run the test
testApprovalFlow().catch(error => {
  log(`\n❌ Unexpected error: ${error.message}`, colors.red);
  process.exit(1);
});
